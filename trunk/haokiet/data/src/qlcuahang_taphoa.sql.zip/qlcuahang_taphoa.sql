-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 27, 2014 at 07:57 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlcuahang_taphoa`
--

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_category`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=28 ;

--
-- Dumping data for table `taphoahaiau_category`
--

INSERT INTO `taphoahaiau_category` (`id`, `name`, `picture`, `enable`) VALUES
(3, 'Cafe ', NULL, 1),
(8, 'Sinh tố', NULL, 1),
(11, 'Nước ép', NULL, 1),
(13, 'Yaourt', NULL, 1),
(14, 'Nước giải khát', NULL, 1),
(15, 'Nước pha chế', NULL, 1),
(16, 'Lipton - Trà', NULL, 1),
(17, 'Sữa tươi', NULL, 1),
(21, 'Điểm tâm sáng', NULL, 1),
(23, 'Khác', NULL, 1),
(25, 'Thuốc lá', NULL, 1),
(26, 'cool air', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_collect_customer`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `taphoahaiau_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_collect_general`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `taphoahaiau_collect_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_config`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `taphoahaiau_config`
--

INSERT INTO `taphoahaiau_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'TẠP HÓA HẢI ÂU'),
(11, 'ADDRESS', 'Phú Quới Long Hồ Vĩnh Long'),
(12, 'PHONE', '0919 153 189'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'N_MONTH_LOG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_course`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_discount` int(11) NOT NULL DEFAULT '1',
  `enable` int(11) NOT NULL,
  `prepare` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=399 ;

--
-- Dumping data for table `taphoahaiau_course`
--

INSERT INTO `taphoahaiau_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `is_discount`, `enable`, `prepare`) VALUES
(53, 8, 'Sinh tố Bơ', 'Sinh tố Bơ', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(54, 8, 'Sinh tố Cà chua', 'Sinh tố Cà chua', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(55, 8, 'Sinh tố Cà rốt', 'Sinh tố Cà rốt', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(56, 8, 'Sinh tố cam', 'Sinh tố cam', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(126, 8, 'Sinh tố chanh', 'Sinh tố chanh', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(127, 8, 'Sinh tố dâu', 'Sinh tố dâu', 'Ly', 22000, 22000, 22000, 22000, '', 1, 1, 0),
(128, 8, 'Sinh tố Mãng cầu', 'Sinh tố Mãng cầu', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(129, 8, 'Sinh tố sapô', 'Sinh tố sapô', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(136, 8, 'Sinh tố thập cẩm', 'Sinh tố thập cẩm', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(149, 13, 'Yaourt cam tươi', 'Yaourt cam tươi', 'Ly', 17000, 17000, 17000, 17000, '', 1, 1, 0),
(161, 13, 'Yaourt dâu', 'Yaourt dâu', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(162, 13, 'Yaourt đá', 'Yaourt đá', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(174, 15, 'Dừa đá', 'Dừa đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(175, 15, 'Dừa trái', 'Dừa trái', 'Trái', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(176, 15, 'Đá me', 'Đá me', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(177, 15, 'Đá me sữa', 'Đá me sữa', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(178, 15, 'Rau má dừa', 'Rau má dừa', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(179, 15, 'Rau má sữa', 'Rau má sữa', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(180, 15, 'Rau má thường', 'Rau má thường', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(181, 15, 'Tắc xí muội nóng', 'Tắc xí muội nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1, 1, 0),
(182, 15, 'Chanh xí muội nóng', 'Chanh xí muội nóng', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(183, 15, 'Xí muội đá', 'Xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(184, 15, 'Sâm dứa', 'Sâm dứa', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(185, 15, 'Sâm dứa sữa', 'Sâm dứa sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(187, 11, 'Ép cà chua', 'Ép cà chua', 'Ly', 18000, 18000, 18000, 18000, '', 1, 1, 0),
(188, 11, 'Ép carrot', 'Ép carrot', 'Ly', 18000, 18000, 18000, 18000, '', 1, 1, 0),
(189, 11, 'Ép cam', 'Ép cam', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(190, 11, 'Ép dâu', 'Ép dâu', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(191, 11, 'Ép lê', 'Ép lê', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(192, 11, 'Ép táo', 'Ép táo', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(193, 11, 'Ép thơm', 'Ép thơm', 'Ly', 18000, 18000, 18000, 18000, '', 1, 1, 0),
(194, 14, '7 up', '7 up', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(196, 14, 'Cam Twister', 'Cam Twister', 'Chai', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(197, 14, 'Dr Thanh', 'Dr Thanh', 'Chai', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(198, 14, 'Đậu nành', 'Đậu nành', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(199, 14, 'Sting dâu sữa', 'Sting dâu sữa', 'Chai', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(201, 14, 'Nước suối', 'Nước suối', 'Chai', 7000, 7000, 7000, 7000, '', 1, 1, 0),
(202, 14, 'Pepsi', 'Pepsi', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(203, 14, 'Coca (chai nhựa)', 'Coca (chai nhựa)', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(204, 14, 'Sting dâu', 'Sting dâu', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(205, 14, 'Trà xanh 0 độ', 'Trà xanh 0 độ', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(208, 17, 'Sữa dâu tươi', 'Sữa dâu tươi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(209, 17, 'Sữa nóng', 'Sữa nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(210, 17, 'Sữa thêm', 'Sữa thêm', 'Ly', 5000, 5000, 5000, 5000, '', 1, 1, 0),
(211, 17, 'Sữa đá', 'Sữa đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(212, 17, 'Sữa tươi', 'Sữa tươi', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(218, 16, 'Lipton sữa đá', 'Lipton sữa đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(219, 16, 'Lipton sữa nóng', 'Lipton sữa nóng', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(220, 16, 'Trà sữa', 'Trà sữa', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(221, 16, 'Trà chanh đá', 'Trà chanh đá', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(222, 16, 'Trà đường đá', 'Trà đường đá', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(223, 16, 'Trà đường nóng', 'Trà đường nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(228, 13, 'Yaourt sữa đá', 'Yaourt sữa đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(229, 13, 'Yaourt trái cây', 'Yaourt trái cây', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(230, 21, 'Bò bít tết trứng', 'Bò bít tết trứng', 'Phần', 30000, 30000, 30000, 30000, '0', 0, 1, 0),
(231, 21, 'Bò bít tết ko trứng', 'Bò bít tết ko trứng', 'Phần', 25000, 25000, 25000, 25000, '0', 0, 1, 0),
(232, 21, 'Mì Ý', 'Mì Ý', 'Phần', 25000, 25000, 25000, 25000, '', 0, 1, 0),
(233, 21, 'Bánh mì ốp la chả', 'Bánh mì ốp la chả', 'Phần', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(234, 21, 'Bánh mì ốp la', 'Bánh mì ốp la', 'Phần', 10000, 10000, 10000, 10000, '', 0, 0, 0),
(235, 21, 'Mì gói xào bò', 'Mì gói xào bò', 'Phần', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(236, 21, 'Nui xào bò', 'Nui xào bò', 'Phần', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(237, 21, 'Mì gói nấu bò', 'Mì gói nấu bò', 'Phần', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(238, 21, 'Trứng thêm', 'Trứng thêm', 'Cái', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(239, 21, 'Mì gói thêm', 'Mì gói thêm', 'Gói', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(240, 21, 'Bánh mì thêm', 'Bánh mì thêm', 'Cái', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(260, 3, 'Cafe  đá ', 'Cafe  đá ', 'Ly', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(265, 15, 'Chanh nóng', 'Chanh nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(267, 15, 'Chanh muối nóng', 'Chanh muối nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(268, 15, 'Chanh muối đá', 'Chanh muối đá', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(269, 15, 'Chanh rhum', 'Chanh rhum', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(270, 15, 'Xí muội nóng', 'Xí muội nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1, 1, 0),
(271, 15, 'Chanh xí muội đá', 'Chanh xí muội đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(273, 15, 'Tắc xí muội đá', 'Tắc xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(274, 15, 'Bạc hà', 'Bạc hà', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(275, 15, 'Bạc hà sữa', 'Bạc hà sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(276, 15, 'Siro dâu', 'Siro dâu', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(277, 15, 'Đá me xí muội', 'Đá me xí muội', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(278, 15, 'Siro dâu sữa', 'Siro dâu sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(279, 8, 'Sinh tố chanh dây', 'Sinh tố chanh dây', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(280, 8, 'Sinh tố Thơm', 'Sinh tố Thơm', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(281, 8, 'Sinh tố Dừa', 'Sinh tố Dừa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(282, 8, 'Sinh tố Táo', 'Sinh tố Táo', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(283, 8, 'Sinh tố Lê', 'Sinh tố Lê', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(284, 8, 'ST rau má dừa', 'ST rau má dừa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(285, 8, 'Sinh tố Bưởi', 'Sinh tố Bưởi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(286, 8, 'Sinh tố Cafe', 'Sinh tố Cafe', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(287, 8, 'ST tự chọn 2 món', 'ST tự chọn 2 món', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(288, 8, 'ST tự chọn 3 món', 'ST tự chọn 3 món', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(289, 8, 'ST tự chọn 4 món', 'ST tự chọn 4 món', 'Ly', 28000, 28000, 28000, 28000, '', 1, 1, 0),
(290, 8, 'ST chanh muối', 'ST chanh muối', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(291, 8, 'Dâu dằm', 'Dâu dằm', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(292, 8, 'Mãng cầu dằm', 'Mãng cầu dằm', 'Ly', 17000, 17000, 17000, 17000, '', 1, 1, 0),
(293, 8, 'Bơ dầm', 'Bơ dầm', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(305, 11, 'Ép 4 mùa', 'Ép 4 mùa', 'Ly', 28000, 28000, 28000, 28000, '', 1, 1, 0),
(306, 11, 'Ép bưởi', 'Ép bưởi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(307, 11, 'Ép cam mật ong', 'Ép cam mật ong', 'Ly', 22000, 22000, 22000, 22000, '', 1, 1, 0),
(308, 11, 'Ép cam sữa', 'Ép cam sữa', 'Ly', 18000, 18000, 18000, 18000, '', 1, 1, 0),
(309, 11, 'Ép chanh dây', 'Ép chanh dây', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(310, 11, 'Ép dâu sữa', 'Ép dâu sữa', 'Ly', 26000, 26000, 26000, 26000, '', 1, 1, 0),
(311, 11, 'Ép tự chọn 2 món', 'Ép tự chọn 2 món', 'Ly', 22000, 22000, 22000, 22000, '', 1, 1, 0),
(312, 11, 'Ép tự chọn 3 món', 'Ép tự chọn 3 món', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(313, 13, 'Yaourt bạc hà', 'Yaourt bạc hà', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(314, 13, 'Yaourt bưởi', 'Yaourt bưởi', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(315, 13, 'Yaourt cafe đá', 'Yaourt cafe đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(316, 13, 'Yaourt chanh dây', 'Yaourt chanh dây', 'Ly', 17000, 17000, 17000, 17000, '', 1, 1, 0),
(318, 17, 'Đậu nành nấu', 'Đậu nành nấu', 'Ly', 7000, 7000, 7000, 7000, '', 1, 1, 0),
(320, 17, 'Sữa chanh xí muội', 'Sữa chanh xí muội', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(321, 17, 'Sữa tươi cacao đá', 'Sữa tươi cacao đá', 'Ly', 16000, 16000, 16000, 16000, '', 1, 1, 0),
(322, 17, 'Sữa tươi cafe', 'Sữa tươi cafe', 'Ly', 14000, 14000, 14000, 14000, '', 1, 1, 0),
(325, 23, 'Khăn lạnh', 'Khăn lạnh', 'Cái', 2000, 2000, 2000, 2000, '', 1, 1, 0),
(326, 23, 'Nước ép thêm', 'Nước ép thêm', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(327, 23, 'Phụ thu nhạc', 'Phụ thu nhạc', 'Bàn', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(328, 23, 'Phụ thu BĐ khuya/ người', 'Phụ thu BĐ khuya/ người', 'Phần', 2000, 2000, 2000, 2000, '', 0, 1, 0),
(329, 23, 'Rau má thêm', 'Rau má thêm', 'Ly', 5000, 5000, 5000, 5000, '', 1, 1, 0),
(330, 23, 'Trái cây dĩa lớn', 'Trái cây dĩa lớn', 'Dĩa', 35000, 35000, 35000, 35000, '', 1, 1, 0),
(331, 23, 'Trái cây dĩa nhỏ', 'Trái cây dĩa nhỏ', 'Dĩa', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(332, 14, 'Rivive', 'Rivive', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(333, 14, 'Mountain Dew', 'Mountain Dew', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(334, 14, 'Trà Ô Long', 'Trà Ô Long', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(335, 14, 'C2', 'C2', 'Chai', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(338, 21, 'Mì không', 'Mì không', 'Gói', 7000, 7000, 7000, 7000, '', 0, 1, 0),
(349, 14, 'Samurai dâu', 'Samurai', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(350, 14, 'Soda', 'Soda', 'Ly', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(351, 8, 'Sinh tố mít', 'Sinh tố mít', 'Ly', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(353, 14, 'Coca (chai thuỷ tinh)', 'Coca (chai thuỷ tinh)', 'Chai', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(355, 15, 'Cam sữa', 'Cam sữa', 'Ly', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(358, 15, 'Chanh đá', 'Chanh đá', 'Ly', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(360, 25, 'Hero (20điếu)', 'Hero (20điếu)', 'Gói', 18000, 18000, 18000, 18000, '', 0, 1, 0),
(361, 25, 'Hero 1/2gói (10điếu)', 'Hero 1/2gói (10điếu)', 'Gói', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(362, 25, 'Hero 1điếu', 'Hero 1điếu', 'Điếu', 1000, 1000, 1000, 1000, '', 0, 1, 0),
(363, 25, 'Jet (20điếu)', 'Jet (20điếu)', 'Gói', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(364, 25, 'Jet 1 điếu', 'Jet 1 điếu', 'Điếu', 1000, 1000, 1000, 1000, '', 0, 1, 0),
(365, 25, 'Jet 1/2 gói (10điếu)', 'Jet 1/2 gói (10điếu)', 'Gói', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(366, 25, 'Mèo lớn (20điếu)', 'Mèo lớn (20điếu)', 'Gói', 22000, 22000, 22000, 22000, '', 0, 1, 0),
(367, 25, 'Mèo trung (12điếu)', 'Mèo trung (12điếu)', 'Gói', 13000, 13000, 13000, 13000, '', 0, 1, 0),
(368, 25, 'Mèo tép (5điếu)', 'Mèo tép (5điếu)', 'Gói', 6000, 6000, 6000, 6000, '', 0, 1, 0),
(369, 25, 'Mèo (1điếu)', 'Mèo (1điếu)', 'Điếu', 1500, 1500, 1500, 1500, '', 0, 1, 0),
(370, 14, ' Tepy Cam', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(371, 14, 'Nutri cam', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(372, 15, 'Trà đường ca', 'Trà đường ca', 'Ly', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(373, 14, 'nước suoi Dasani', 'nước suoi mang ve', 'Chai', 7000, 7000, 7000, 7000, '', 0, 1, 0),
(374, 14, 'Cam Fanta (chai thuy tinh)', 'Cam Fanta', 'Chai', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(375, 14, 'Xá xị Fanta', '', 'Chai', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(376, 14, 'Sprite chai thuy tinh', 'Sprite', 'Chai', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(377, 14, 'Cam Fanta ( chai nhựa)', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(378, 14, 'Sprite chai nhựa', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(379, 14, 'Xá xị chai nhựa', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(380, 14, 'Nước suối AQuat', '', 'Chai', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(381, 14, 'Samurai tăng lực', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(382, 26, 'cool air', 'cool air', 'Ly', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(383, 3, 'cafe sữa đá', 'cafe sữa', 'Ly', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(384, 3, 'cafe sữa nóng', 'cfe sua nong', 'Ly', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(385, 3, 'cafe nóng (đen)', 'cafe nóng (đen)', 'Ly', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(387, 16, 'Lipton đá', 'Lipton đá', 'Ly', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(388, 16, 'Lipton nóng', 'Lipton nóng', 'Ly', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(389, 16, 'Trà chanh nóng', 'Trà chanh nóng', 'Ly', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(391, 8, 'Sinh tố đu đủ', 'Sinh tố đu đủ', 'Ly', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(392, 26, 'coolair một món', 'coolair một món', 'Ly', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(393, 14, 'nutri', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(395, 14, 'Number one', 'Number one', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(396, 16, 'Lipton Cam', 'Lipton cam', 'Ly', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(397, 13, 'yaourt hu', 'yaourt hu', 'Hủ', 7000, 7000, 7000, 7000, '', 0, 1, 1),
(398, 16, 'Tra duong ca', 'tra duong ca', 'Cái', 20000, 20000, 20000, 20000, '', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_customer`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `taphoahaiau_customer`
--

INSERT INTO `taphoahaiau_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_domain`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `taphoahaiau_domain`
--

INSERT INTO `taphoahaiau_domain` (`id`, `name`) VALUES
(1, 'Thu ngân');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_employee`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `taphoahaiau_employee`
--

INSERT INTO `taphoahaiau_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(2, 'Nhân viên', 'Bán hàng', 1, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_guest`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `taphoahaiau_guest`
--

INSERT INTO `taphoahaiau_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_order_import`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=362 ;

--
-- Dumping data for table `taphoahaiau_order_import`
--


-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_order_import_detail_1` (`idorder`),
  KEY `taphoahaiau_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=657 ;

--
-- Dumping data for table `taphoahaiau_order_import_detail`
--


-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_paid_customer`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `taphoahaiau_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_paid_employee`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `taphoahaiau_paid_employee`
--


-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_paid_general`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=175 ;

--
-- Dumping data for table `taphoahaiau_paid_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `taphoahaiau_paid_pay_roll`
--


-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `taphoahaiau_paid_supplier`
--


-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_pay_roll`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `session1` int(11) NOT NULL,
  `session2` int(11) NOT NULL,
  `session3` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=410 ;

--
-- Dumping data for table `taphoahaiau_pay_roll`
--

INSERT INTO `taphoahaiau_pay_roll` (`id`, `id_employee`, `date`, `session1`, `session2`, `session3`, `extra`, `late`) VALUES
(162, 2, '2014-01-01', 0, 0, 0, 0, 0),
(163, 2, '2014-01-02', 0, 0, 0, 0, 0),
(164, 2, '2014-01-03', 0, 0, 0, 0, 0),
(165, 2, '2014-01-04', 0, 0, 0, 0, 0),
(166, 2, '2014-01-05', 0, 0, 0, 0, 0),
(167, 2, '2014-01-06', 0, 0, 0, 0, 0),
(168, 2, '2014-01-07', 0, 0, 0, 0, 0),
(169, 2, '2014-01-08', 0, 0, 1, 0, 0),
(170, 2, '2014-01-09', 0, 0, 1, 0, 0),
(171, 2, '2014-01-10', 0, 0, 0, 0, 0),
(172, 2, '2014-01-11', 0, 0, 0, 0, 0),
(173, 2, '2014-01-12', 0, 0, 0, 0, 0),
(174, 2, '2014-01-13', 0, 0, 0, 0, 0),
(175, 2, '2014-01-14', 0, 0, 0, 0, 0),
(176, 2, '2014-01-15', 0, 0, 0, 0, 0),
(177, 2, '2014-01-16', 0, 0, 0, 0, 0),
(178, 2, '2014-01-17', 0, 0, 0, 0, 0),
(179, 2, '2014-01-18', 0, 0, 0, 0, 0),
(180, 2, '2014-01-19', 0, 0, 0, 0, 0),
(181, 2, '2014-01-20', 0, 0, 0, 0, 0),
(182, 2, '2014-01-21', 0, 0, 0, 0, 0),
(183, 2, '2014-01-22', 0, 0, 0, 0, 0),
(184, 2, '2014-01-23', 0, 0, 0, 0, 0),
(185, 2, '2014-01-24', 0, 0, 0, 0, 0),
(186, 2, '2014-01-25', 0, 0, 0, 0, 0),
(187, 2, '2014-01-26', 0, 0, 0, 0, 0),
(188, 2, '2014-01-27', 0, 0, 0, 0, 0),
(189, 2, '2014-01-28', 0, 0, 0, 0, 0),
(190, 2, '2014-01-29', 0, 0, 0, 0, 0),
(191, 2, '2014-01-30', 0, 0, 0, 0, 0),
(192, 2, '2014-01-31', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_r2c`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_r2c_1` (`id_course`),
  KEY `taphoahaiau_r2c_2` (`id_resource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=160 ;

--
-- Dumping data for table `taphoahaiau_r2c`
--


-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_resource`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=112 ;

--
-- Dumping data for table `taphoahaiau_resource`
--

INSERT INTO `taphoahaiau_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(2, 1, 'Đá viên nhỏ', 'Bao', 15000, 'Nước đá viên - Bao 25kg'),
(14, 1, 'Nước đá ướp', 'Cây', 10000, 'Đá cây ướp trái cây'),
(17, 6, 'Bánh', 'Gói', 5000, ''),
(19, 8, 'Hạt loại 1', 'Kg', 60000, ''),
(20, 8, 'Hạt loại 2', 'Kg', 80000, ''),
(27, 6, 'Xúc xích', 'Gói', 17000, ''),
(35, 9, 'Trà xanh 0 độ', 'Thùng', 160000, 'Thùng 24 chai 500ml'),
(36, 9, 'Dr Thanh', 'Thùng', 185000, 'Thùng 24 chai 370 ml'),
(39, 9, 'Pepsi', 'Thùng', 150000, 'Thùng 24 lon 330 ml'),
(40, 9, 'Mirinda Cam', 'Thùng', 120000, 'Thùng 24 lon 330ml'),
(43, 9, 'Sting dâu', 'Thùng', 170000, 'Thùng 24 chai 330ml'),
(47, 12, 'Ổi', 'Kg', 9000, ''),
(48, 12, 'Củ sắn', 'Kg', 15000, ''),
(49, 12, 'Mít', 'Kg', 18000, ''),
(50, 12, 'Chôm chôm', 'Kg', 10000, ''),
(51, 12, 'Xoài Thái', 'Kg', 15000, ''),
(52, 12, 'Xoài Đài Loan', 'Kg', 15000, ''),
(53, 12, 'Xoài chua', 'Kg', 15000, ''),
(54, 12, 'Mận', 'Kg', 10000, ''),
(55, 12, 'Sơ ri', 'Kg', 12000, ''),
(56, 12, 'Thơm', 'Kg', 12000, ''),
(57, 12, 'Khóm', 'Kg', 10000, ''),
(79, 12, 'Dưa hấu', 'Kg', 10000, ''),
(82, 12, 'Táo', 'Kg', 10000, ''),
(84, 12, 'Cóc', 'Kg', 6000, ''),
(91, 1, 'Đá ống viên lớn', 'Kg', 800, 'Bao 20kg'),
(99, 12, 'Bưởi', 'Kg', 10000, ''),
(101, 8, 'Hạt loại 3', 'Kg', 120000, ''),
(102, 13, 'Duong', 'Kg', 20000, ''),
(103, 9, 'C2', 'Thùng', 105000, '24 chai'),
(104, 9, 'Lipton', 'Hộp', 105000, '100 gói'),
(105, 9, 'Revive', 'Thùng', 174000, '24 chai'),
(106, 9, 'Ô Long', 'Thùng', 135000, '24 chai'),
(107, 12, 'Cà chua', 'Kg', 0, ''),
(108, 12, 'Cà rốt', 'Kg', 0, ''),
(109, 9, 'Mountain Dew', 'Thùng', 142000, '24 chai'),
(110, 12, 'Dừa', 'Trái', 7000, 'gọt sẵn'),
(111, 9, 'Tra xanh 0 do', 'Chai', 12000, '');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_session`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `taphoahaiau_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1758 ;

--
-- Dumping data for table `taphoahaiau_session`
--

INSERT INTO `taphoahaiau_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(1756, 1, 4, 1, 2, '2014-02-27 13:21:35', '2014-02-27 13:21:35', '', 1, 0, 0, 0, 0, 0),
(1757, 1, 4, 1, 2, '2014-02-27 13:25:31', '2014-02-27 13:25:31', '', 1, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_session_detail`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3617 ;

--
-- Dumping data for table `taphoahaiau_session_detail`
--

INSERT INTO `taphoahaiau_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`) VALUES
(3614, 1756, 260, 3, 8000),
(3615, 1756, 383, 2, 12000),
(3616, 1757, 325, 4, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_store`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `taphoahaiau_store`
--

INSERT INTO `taphoahaiau_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_supplier`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `taphoahaiau_supplier`
--

INSERT INTO `taphoahaiau_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(1, 'ĐL NƯỚC ĐÁ', '0913796043', 'Phường 8', 'Cung cấp nước đá', 0),
(6, 'Siêu thị COOP MART', 'chưa cập nhật', 'Vĩnh Long', '', 0),
(8, 'ĐL Cafe hạt', '0703 111 222', 'P4 Vĩnh Long', '', 0),
(9, 'ĐL Nước ngọt Thiên Tân', '', 'P1, TP Vĩnh Long', '', 0),
(12, 'VỰA TRÁI CÂY', '', '', '', 0),
(13, 'NCC A', '80830803', 'p5 tpvl', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_table`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=192 ;

--
-- Dumping data for table `taphoahaiau_table`
--

INSERT INTO `taphoahaiau_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, '01', 1, '0'),
(2, 1, '02', 1, '0'),
(3, 1, '03', 1, '0'),
(4, 1, '04', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_table_log`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6745 ;

--
-- Dumping data for table `taphoahaiau_table_log`
--

INSERT INTO `taphoahaiau_table_log` (`id`, `iduser`, `idtable`, `datetime`, `note`) VALUES
(6733, 4, 1, '2014-02-27 13:21:35', 'Tạo mới giao dịch'),
(6734, 4, 1, '2014-02-27 13:21:35', 'Cập nhật món Cafe  đá  1'),
(6735, 4, 1, '2014-02-27 13:21:37', 'Cập nhật món Cafe  đá  2'),
(6736, 4, 1, '2014-02-27 13:21:41', 'Cập nhật món Cafe  đá  3'),
(6737, 4, 1, '2014-02-27 13:23:40', 'Cập nhật món cafe sữa đá 1'),
(6738, 4, 1, '2014-02-27 13:23:41', 'Cập nhật món cafe sữa đá 2'),
(6739, 1, 1, '2014-02-27 13:23:58', 'tính tiền 48.000'),
(6740, 4, 1, '2014-02-27 13:25:31', 'Tạo mới giao dịch'),
(6741, 4, 1, '2014-02-27 13:25:31', 'Cập nhật món Khăn lạnh 1'),
(6742, 4, 1, '2014-02-27 13:25:32', 'Cập nhật món Khăn lạnh 2'),
(6743, 4, 1, '2014-02-27 13:25:33', 'Cập nhật món Khăn lạnh 3'),
(6744, 1, 1, '2014-02-27 13:26:24', 'tính tiền 8.000');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_term`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `taphoahaiau_term`
--

INSERT INTO `taphoahaiau_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_term_collect`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `taphoahaiau_term_collect`
--

INSERT INTO `taphoahaiau_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_tracking`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `taphoahaiau_tracking`
--

INSERT INTO `taphoahaiau_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(16, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_tracking_course`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_tracking_course` (
  `id` int(11) NOT NULL,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taphoahaiau_tracking_course`
--

INSERT INTO `taphoahaiau_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`) VALUES
(0, 16, 173, 260, 3, 0, 0),
(0, 16, 173, 383, 2, 0, 0),
(0, 16, 173, 325, 4, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `taphoahaiau_tracking_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=175 ;

--
-- Dumping data for table `taphoahaiau_tracking_daily`
--

INSERT INTO `taphoahaiau_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(147, 16, '2014-02-01', 0, 0, 0, 0, 0),
(148, 16, '2014-02-02', 0, 0, 0, 0, 0),
(149, 16, '2014-02-03', 0, 0, 0, 0, 0),
(150, 16, '2014-02-04', 0, 0, 0, 0, 0),
(151, 16, '2014-02-05', 0, 0, 0, 0, 0),
(152, 16, '2014-02-06', 0, 0, 0, 0, 0),
(153, 16, '2014-02-07', 0, 0, 0, 0, 0),
(154, 16, '2014-02-08', 0, 0, 0, 0, 0),
(155, 16, '2014-02-09', 0, 0, 0, 0, 0),
(156, 16, '2014-02-10', 0, 0, 0, 0, 0),
(157, 16, '2014-02-11', 0, 0, 0, 0, 0),
(158, 16, '2014-02-12', 0, 0, 0, 0, 0),
(159, 16, '2014-02-13', 0, 0, 0, 0, 0),
(160, 16, '2014-02-14', 0, 0, 0, 0, 0),
(161, 16, '2014-02-15', 0, 0, 0, 0, 0),
(162, 16, '2014-02-16', 0, 0, 0, 0, 0),
(163, 16, '2014-02-17', 0, 0, 0, 0, 0),
(164, 16, '2014-02-18', 0, 0, 0, 0, 0),
(165, 16, '2014-02-19', 0, 0, 0, 0, 0),
(166, 16, '2014-02-20', 0, 0, 0, 0, 0),
(167, 16, '2014-02-21', 0, 0, 0, 0, 0),
(168, 16, '2014-02-22', 0, 0, 0, 0, 0),
(169, 16, '2014-02-23', 0, 0, 0, 0, 0),
(170, 16, '2014-02-24', 0, 0, 0, 0, 0),
(171, 16, '2014-02-25', 0, 0, 0, 0, 0),
(172, 16, '2014-02-26', 0, 0, 0, 0, 0),
(173, 16, '2014-02-27', 56000, 0, 0, 0, 0),
(174, 16, '2014-02-28', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_tracking_store`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1822 ;

--
-- Dumping data for table `taphoahaiau_tracking_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_unit`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `taphoahaiau_unit`
--

INSERT INTO `taphoahaiau_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg'),
(24, 'Phần'),
(25, 'Bàn'),
(26, 'Hộp'),
(27, 'Bao'),
(28, 'Cây');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_user`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `taphoahaiau_user`
--

INSERT INTO `taphoahaiau_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `taphoahaiau_collect_customer`
--
ALTER TABLE `taphoahaiau_collect_customer`
  ADD CONSTRAINT `taphoahaiau_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `taphoahaiau_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_collect_general`
--
ALTER TABLE `taphoahaiau_collect_general`
  ADD CONSTRAINT `taphoahaiau_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `taphoahaiau_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_course`
--
ALTER TABLE `taphoahaiau_course`
  ADD CONSTRAINT `taphoahaiau_course_1` FOREIGN KEY (`idcategory`) REFERENCES `taphoahaiau_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_order_import`
--
ALTER TABLE `taphoahaiau_order_import`
  ADD CONSTRAINT `taphoahaiau_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `taphoahaiau_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_order_import_detail`
--
ALTER TABLE `taphoahaiau_order_import_detail`
  ADD CONSTRAINT `taphoahaiau_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `taphoahaiau_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `taphoahaiau_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `taphoahaiau_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_paid_customer`
--
ALTER TABLE `taphoahaiau_paid_customer`
  ADD CONSTRAINT `taphoahaiau_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `taphoahaiau_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_paid_employee`
--
ALTER TABLE `taphoahaiau_paid_employee`
  ADD CONSTRAINT `taphoahaiau_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `taphoahaiau_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_paid_general`
--
ALTER TABLE `taphoahaiau_paid_general`
  ADD CONSTRAINT `taphoahaiau_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `taphoahaiau_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_paid_pay_roll`
--
ALTER TABLE `taphoahaiau_paid_pay_roll`
  ADD CONSTRAINT `taphoahaiau_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `taphoahaiau_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_paid_supplier`
--
ALTER TABLE `taphoahaiau_paid_supplier`
  ADD CONSTRAINT `taphoahaiau_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `taphoahaiau_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_pay_roll`
--
ALTER TABLE `taphoahaiau_pay_roll`
  ADD CONSTRAINT `taphoahaiau_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `taphoahaiau_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_r2c`
--
ALTER TABLE `taphoahaiau_r2c`
  ADD CONSTRAINT `taphoahaiau_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `taphoahaiau_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `taphoahaiau_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `taphoahaiau_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_resource`
--
ALTER TABLE `taphoahaiau_resource`
  ADD CONSTRAINT `taphoahaiau_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `taphoahaiau_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_session`
--
ALTER TABLE `taphoahaiau_session`
  ADD CONSTRAINT `taphoahaiau_session_1` FOREIGN KEY (`idtable`) REFERENCES `taphoahaiau_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `taphoahaiau_session_2` FOREIGN KEY (`iduser`) REFERENCES `taphoahaiau_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `taphoahaiau_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `taphoahaiau_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_session_detail`
--
ALTER TABLE `taphoahaiau_session_detail`
  ADD CONSTRAINT `taphoahaiau_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `taphoahaiau_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `taphoahaiau_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `taphoahaiau_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_table`
--
ALTER TABLE `taphoahaiau_table`
  ADD CONSTRAINT `taphoahaiau_table_1` FOREIGN KEY (`iddomain`) REFERENCES `taphoahaiau_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
