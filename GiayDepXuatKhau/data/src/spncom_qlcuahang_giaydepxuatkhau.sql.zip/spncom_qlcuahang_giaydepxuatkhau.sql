-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 09, 2014 at 06:03 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_qlcuahang_giaydepxuatkhau`
--

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_collect_customer`
--

CREATE TABLE IF NOT EXISTS `giaydep_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_collect_general`
--

CREATE TABLE IF NOT EXISTS `giaydep_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_collect_1` (`id_term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_collect_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_config`
--

CREATE TABLE IF NOT EXISTS `giaydep_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `giaydep_config`
--

INSERT INTO `giaydep_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '1'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'GIÀY DÉP XUẤT KHẨU'),
(11, 'ADDRESS', 'Phó Cơ Điều, F3, TP Vĩnh Long'),
(12, 'PHONE', '0919.153.189'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'N_MONTH_LOG', '1'),
(17, 'PHONE', '9000'),
(18, 'PHONE', '8700'),
(19, 'PRICE1', '9000'),
(20, 'PRICE2', '8700');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_customer`
--

CREATE TABLE IF NOT EXISTS `giaydep_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=262 ;

--
-- Dumping data for table `giaydep_customer`
--

INSERT INTO `giaydep_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '', 'không có', '', '', 0),
(2, 'Bùi Thanh Tuấn', 0, '', '0919 153 189', 'Đồng Tháp', '', 0),
(261, 'Nguyễn Văn A', 0, '', '0996355368', 'Vinh Long', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_employee`
--

CREATE TABLE IF NOT EXISTS `giaydep_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `giaydep_employee`
--

INSERT INTO `giaydep_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(2, 'Nhân viên', 'Bán hàng', 1, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_guest`
--

CREATE TABLE IF NOT EXISTS `giaydep_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `giaydep_guest`
--

INSERT INTO `giaydep_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_export`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_export` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `state` int(11) NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `giaydep_order_export`
--

INSERT INTO `giaydep_order_export` (`id`, `iduser`, `idcustomer`, `date`, `state`, `description`) VALUES
(1, 4, 2, '2014-08-09 00:00:00', 1, 'ABC'),
(2, 4, 2, '2014-08-09 00:00:00', 3, 'của tui nè'),
(3, 4, 1, '2014-11-09 00:00:00', 1, 'Đơn hàng'),
(11, 4, 1, '2014-11-09 13:25:40', 3, 'abc'),
(12, 4, 261, '2014-11-09 19:49:31', 2, 'Đơn hàng'),
(13, 4, 1, '2014-11-09 20:28:32', 0, 'Đơn hàng');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_export_detail`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_export_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `count1` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `giaydep_order_export_detail`
--

INSERT INTO `giaydep_order_export_detail` (`id`, `idorder`, `idresource`, `count`, `count1`, `price`) VALUES
(1, 1, 22, 20, 1, 30000),
(2, 1, 19, 5, 0, 25000),
(3, 2, 19, 200, 0, 45000),
(4, 3, 19, 3, 1, 38000),
(5, 3, 23, 11, 1, 50000),
(6, 3, 21, 2, 1, 250000),
(7, 3, 22, 1, 1, 235000),
(8, 10, 19, 1, 1, 38000),
(9, 11, 19, 1, 1, 38000),
(10, 11, 24, 1, 1, 65000),
(11, 11, 21, 2, 1, 250000),
(12, 12, 19, 2, 1, 68000),
(13, 13, 22, 1, 1, 335000);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_import`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=369 ;

--
-- Dumping data for table `giaydep_order_import`
--

INSERT INTO `giaydep_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(366, 10, '2014-08-09', ''),
(367, 8, '2014-08-08', ''),
(368, 9, '2014-08-09', '');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `count1` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_order_import_detail_1` (`idorder`),
  KEY `giaydep_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=663 ;

--
-- Dumping data for table `giaydep_order_import_detail`
--

INSERT INTO `giaydep_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `count1`, `price`) VALUES
(658, 366, 21, 200, 100, 250000),
(659, 367, 19, 100, 2, 35000),
(660, 368, 20, 150, 0, 350000),
(661, 366, 22, 100, 0, 235000),
(662, 367, 23, 10, 0, 50000);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_customer`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_employee`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_employee`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_general`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_paid_1` (`id_term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_supplier`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_resource`
--

CREATE TABLE IF NOT EXISTS `giaydep_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price_import` int(10) NOT NULL,
  `price_export` int(11) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `giaydep_resource`
--

INSERT INTO `giaydep_resource` (`id`, `idsupplier`, `name`, `unit`, `price_import`, `price_export`, `description`, `image`) VALUES
(19, 8, 'GTE001', 'Đôi', 38000, 68000, 'Giày Trẻ Em', 'https://lh3.googleusercontent.com/-VWfv12Vr8s0/VF9gRejiZqI/AAAAAAAABR0/VWYVTNulmt4/s800/GiayTreEm001.jpg'),
(20, 9, 'GTR001', 'Đôi', 340000, 440000, 'Giày thời trang 001', 'https://lh3.googleusercontent.com/-6RMXsRdA35Q/VF9gQTfKY9I/AAAAAAAABRg/p41_Wpzb4JU/s400/GiayThoiTrang001.JPG'),
(21, 10, 'GTT001', 'Đôi', 250000, 350000, 'Giày Thể Thao 001', 'https://lh5.googleusercontent.com/-Qiei0hFA-yw/VF9gPKoJuRI/AAAAAAAABRU/MKdKXz4z3Qo/s400/GiayTheThao001.JPG'),
(22, 10, 'GTT002', 'Đôi', 235000, 335000, 'Giày Thể Thao 001', 'https://lh3.googleusercontent.com/-st-MsPiNPk4/VF9gOzR8QjI/AAAAAAAABRM/r11PO9LrULI/s400/GiayTheThao002.jpg'),
(23, 8, 'GTE002', 'Đôi', 50000, 80000, '', 'https://lh4.googleusercontent.com/-g9RVRmVaVIc/VF9gSP0UbfI/AAAAAAAABSE/0ZtTPjgTyRY/s288/GiayTreEm002.jpg'),
(24, 8, 'GTE003', 'Đôi', 65000, 85000, '', 'https://lh3.googleusercontent.com/-e9YZ9x4nrn4/VF9gSu_tBOI/AAAAAAAABSI/RogJK-5E3_0/s288/GiayTreEm003.jpg'),
(25, 10, 'GTT003', 'Đôi', 270000, 370000, 'Giày thể thao Bitis mẫu 003', 'https://lh5.googleusercontent.com/-Pc8ijUwhv_E/VF9gO6GGvwI/AAAAAAAABRI/fs-i8G6umRo/s400/GiayTheThao003.jpg'),
(26, 10, 'GTT004', 'Đôi', 265000, 365000, 'Giày thể thao mẫu 004', 'https://lh5.googleusercontent.com/-vJlhbEdE7B8/VF9gP62mILI/AAAAAAAABRc/cwAdgPvXNbo/s400/GiayTheThao004.jpg'),
(27, 9, 'GTR002', 'Đôi', 320000, 420000, '', 'https://lh4.googleusercontent.com/-rjgiECoIMjg/VF9gRAD8UbI/AAAAAAAABRw/beuNyJyP_Yc/s400/GiayThoiTrang002.png'),
(28, 9, 'GTR003', 'Đôi', 320000, 480000, '', 'https://lh6.googleusercontent.com/-JazWRiklQY4/VF9gReyVoAI/AAAAAAAABR4/bxXfCHOFTFY/s400/GiayThoiTrang003.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_supplier`
--

CREATE TABLE IF NOT EXISTS `giaydep_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `giaydep_supplier`
--

INSERT INTO `giaydep_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(8, 'Giày Trẻ Em', '111111111', 'P4 Vĩnh Long', '', 0),
(9, 'Giày Thời Trang', '222222222', 'Vĩnh Long', '', 0),
(10, 'Giày Thể Thao', '333333333', 'Vĩnh Long', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_term`
--

CREATE TABLE IF NOT EXISTS `giaydep_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `giaydep_term`
--

INSERT INTO `giaydep_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_term_collect`
--

CREATE TABLE IF NOT EXISTS `giaydep_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `giaydep_term_collect`
--

INSERT INTO `giaydep_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `giaydep_tracking`
--

INSERT INTO `giaydep_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(18, '2014-08-01', '2014-08-31', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `import` bigint(20) NOT NULL,
  `export` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=297 ;

--
-- Dumping data for table `giaydep_tracking_daily`
--

INSERT INTO `giaydep_tracking_daily` (`id`, `id_tracking`, `date`, `import`, `export`) VALUES
(266, 18, '2014-08-01', 0, 0),
(267, 18, '2014-08-02', 0, 0),
(268, 18, '2014-08-03', 0, 0),
(269, 18, '2014-08-04', 0, 0),
(270, 18, '2014-08-05', 0, 0),
(271, 18, '2014-08-06', 0, 0),
(272, 18, '2014-08-07', 0, 0),
(273, 18, '2014-08-08', 0, 0),
(274, 18, '2014-08-09', 126000000, 9550000),
(275, 18, '2014-08-10', 0, 0),
(276, 18, '2014-08-11', 0, 0),
(277, 18, '2014-08-12', 0, 0),
(278, 18, '2014-08-13', 0, 0),
(279, 18, '2014-08-14', 0, 0),
(280, 18, '2014-08-15', 0, 0),
(281, 18, '2014-08-16', 0, 0),
(282, 18, '2014-08-17', 0, 0),
(283, 18, '2014-08-18', 0, 0),
(284, 18, '2014-08-19', 0, 0),
(285, 18, '2014-08-20', 0, 0),
(286, 18, '2014-08-21', 0, 0),
(287, 18, '2014-08-22', 0, 0),
(288, 18, '2014-08-23', 0, 0),
(289, 18, '2014-08-24', 0, 0),
(290, 18, '2014-08-25', 0, 0),
(291, 18, '2014-08-26', 0, 0),
(292, 18, '2014-08-27', 0, 0),
(293, 18, '2014-08-28', 0, 0),
(294, 18, '2014-08-29', 0, 0),
(295, 18, '2014-08-30', 0, 0),
(296, 18, '2014-08-31', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_domain_daily`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_domain_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_domain` int(11) NOT NULL,
  `date` date NOT NULL,
  `ticket_selling` bigint(20) NOT NULL,
  `ticket_selling_back` bigint(20) NOT NULL,
  `ticket_value` bigint(20) NOT NULL,
  `debt` bigint(20) NOT NULL,
  `paid_ticket` bigint(11) NOT NULL,
  `paid_debt` bigint(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_tracking_domain_daily`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_supplier_daily`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_supplier_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_supplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `ticket_import` bigint(20) NOT NULL,
  `ticket_import_back` bigint(20) NOT NULL,
  `value_import` bigint(20) NOT NULL,
  `value_import_back` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=208 ;

--
-- Dumping data for table `giaydep_tracking_supplier_daily`
--

INSERT INTO `giaydep_tracking_supplier_daily` (`id`, `id_supplier`, `date`, `ticket_import`, `ticket_import_back`, `value_import`, `value_import_back`) VALUES
(205, 10, '2014-08-09', 300, 100, 73500000, 25000000),
(206, 9, '2014-08-09', 150, 0, 52500000, 0),
(207, 8, '2014-08-09', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_user`
--

CREATE TABLE IF NOT EXISTS `giaydep_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `giaydep_user`
--

INSERT INTO `giaydep_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `giaydep_collect_customer`
--
ALTER TABLE `giaydep_collect_customer`
  ADD CONSTRAINT `giaydep_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `giaydep_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_collect_general`
--
ALTER TABLE `giaydep_collect_general`
  ADD CONSTRAINT `giaydep_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `giaydep_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_order_import`
--
ALTER TABLE `giaydep_order_import`
  ADD CONSTRAINT `giaydep_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `giaydep_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_order_import_detail`
--
ALTER TABLE `giaydep_order_import_detail`
  ADD CONSTRAINT `giaydep_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `giaydep_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `giaydep_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `giaydep_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_customer`
--
ALTER TABLE `giaydep_paid_customer`
  ADD CONSTRAINT `giaydep_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `giaydep_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_employee`
--
ALTER TABLE `giaydep_paid_employee`
  ADD CONSTRAINT `giaydep_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `giaydep_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_general`
--
ALTER TABLE `giaydep_paid_general`
  ADD CONSTRAINT `giaydep_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `giaydep_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_supplier`
--
ALTER TABLE `giaydep_paid_supplier`
  ADD CONSTRAINT `giaydep_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `giaydep_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_resource`
--
ALTER TABLE `giaydep_resource`
  ADD CONSTRAINT `giaydep_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `giaydep_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
