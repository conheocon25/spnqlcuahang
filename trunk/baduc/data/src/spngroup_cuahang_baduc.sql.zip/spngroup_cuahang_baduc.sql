-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 22, 2013 at 06:18 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spngroup_cuahang_baduc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `picture`) VALUES
(1, 'Linh Tinh', NULL),
(2, 'Mỹ Phẩm', NULL),
(3, 'KEM', NULL),
(4, 'NƯỚC GIẢI KHÁT', NULL),
(5, 'THUỐC HÚT', NULL),
(6, 'THỨC ĂN', NULL),
(7, 'KHÁC', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tracking` (`id_tracking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_general`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_collect_general`
--

INSERT INTO `tbl_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(1, 2, '2013-10-01', 11, 'a1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'GUEST_VISIT', '13'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'THEME', 'red-green'),
(8, 'EVERY_5_MINUTES', '2000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_course`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(2, 'LÊ HỒNG ĐỨC', 0, '', '0918585203', 'Tân Hòa - An Nhơn - Châu Thành - Đồng Tháp', '', 0),
(3, 'NGUYỄN THÀNH TÀI', 0, '', '01636472769', 'Tân Hòa - An Nhơn - Châu Thành - Đồng Tháp', '', 0),
(4, 'CHUNG HOÀNG HÀ', 0, '', '', 'Tân Hòa - An Nhơn - Châu Thành - Đồng Tháp', '', 0),
(5, 'NGUYỄN VĂN BẢY', 0, '', '', 'Tân Hòa - An Nhơn - Châu Thành - Đồng Tháp', '', 0),
(6, 'Lê Nguyễn Đông Khoa', 1, '', '0945 030709', '', '', 0),
(7, 'PHẠM VĂN GIÚP', 0, '', '0918074988', '', '', 0),
(8, 'NGUYỄN THANH VŨ', 0, '', '01297909609', 'Tân Hòa - An Nhơn - Châu Thành - Đồng Tháp', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_customer_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_customer` int(11) NOT NULL,
  `id_domain` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_customer` (`id_customer`),
  KEY `id_domain` (`id_domain`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_customer_domain`
--

INSERT INTO `tbl_customer_domain` (`id`, `id_customer`, `id_domain`) VALUES
(3, 2, 1),
(4, 2, 2),
(6, 4, 1),
(7, 6, 2),
(8, 6, 1),
(9, 7, 1),
(10, 3, 1),
(11, 5, 1),
(12, 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_customer_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_customer` int(11) NOT NULL,
  `id_domain` int(11) NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_customer` (`id_customer`),
  KEY `id_domain` (`id_domain`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_customer_tracking`
--

INSERT INTO `tbl_customer_tracking` (`id`, `id_customer`, `id_domain`, `date_start`, `date_end`, `note`) VALUES
(1, 2, 1, '2012-06-01', '2013-04-30', 'AO 07 - AO 3 LƯỢM (Hùn với 5 Tại - 6 Dễ)'),
(2, 2, 1, '2013-10-01', '2013-10-31', 'AO SỐ 2 - Hùn với ? ? ?'),
(4, 2, 1, '2013-07-01', '2013-11-11', 'AO SỐ 3 - Hùn với  ? ? ?'),
(5, 3, 1, '2013-11-11', '2013-11-11', 'Hùn với ? ? ?');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(1, 'THỦY SẢN'),
(2, 'THÚ Y');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`) VALUES
(1, 'Lý Văn Thạnh', 'Bán hàng', 0, '0989 111 2221', 'TP HCM', 2000000),
(2, 'Bùi Thanh Tuấn', 'Bán hàng', 0, '0996 333 444', 'Đồng Tháp', 2000000),
(3, 'Nguyễn Thanh Bảo', 'Bảo vệ', 0, '', 'Vĩnh Long', 1800000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(2, '192.168.1.3', '1382425867', '1382429467', '192.168.1.3');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_export`
--

CREATE TABLE IF NOT EXISTS `tbl_order_export` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tag` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tracking` (`id_tracking`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=140 ;

--
-- Dumping data for table `tbl_order_export`
--

INSERT INTO `tbl_order_export` (`id`, `id_tracking`, `id_user`, `tag`, `date`, `note`) VALUES
(13, 1, 2, 2, '2012-07-02 19:10:00', 'Nhập hàng từ ghe giao'),
(14, 4, 1, 0, '2013-11-10 13:00:00', 'Thử nghiệm lần đầu'),
(18, 4, 1, 0, '2013-11-14 17:50:00', 'Thử nghiệm'),
(19, 1, 1, 2, '2012-07-06 00:00:00', 'Nhập hàng từ ghe giao'),
(20, 1, 2, 2, '2012-07-17 09:30:00', 'Nhập hàng từ ghe giao'),
(21, 1, 2, 2, '2012-07-28 09:00:00', 'Nhập hàng từ ghe giao'),
(22, 1, 2, 2, '2012-08-08 10:05:00', 'Nhập hàng từ ghe giao'),
(23, 1, 2, 2, '2012-08-13 09:55:00', 'Nhập hàng từ ghe giao'),
(24, 1, 2, 2, '2012-08-18 14:05:00', 'Nhập hàng từ ghe Mừng'),
(25, 1, 2, 2, '2012-08-20 13:00:00', 'Nhập hàng từ ghe Mừng'),
(26, 1, 2, 2, '2012-08-25 15:00:00', 'Nhập hàng từ ghe Mừng giao'),
(29, 1, 2, 2, '2012-08-30 09:30:00', 'Nhập hàng từ ghe Mừng giao'),
(30, 1, 2, 2, '2012-09-01 08:25:00', 'Nhập hàng từ ghe Mừng giao'),
(31, 1, 2, 2, '2012-09-05 09:05:00', 'Nhập hàng từ ghe giao'),
(32, 1, 2, 2, '2012-09-08 11:10:00', 'Nhập hàng từ ghe giao'),
(33, 1, 2, 2, '2012-09-13 10:10:00', 'Nhập hàng từ ghe giao'),
(34, 1, 2, 2, '2012-09-18 08:50:00', 'Nhập hàng từ ghe giao'),
(35, 1, 2, 2, '2012-09-19 08:30:00', 'Nhập hàng từ ghe giao'),
(36, 1, 2, 2, '2012-09-21 09:55:00', 'Nhập hàng từ ghe giao'),
(37, 1, 2, 2, '2012-09-22 09:35:00', 'Nhập hàng từ ghe giao'),
(38, 1, 2, 2, '2012-09-24 08:50:00', 'Nhập hàng từ ghe giao'),
(39, 1, 2, 2, '2012-10-01 11:30:00', 'Nhập hàng từ ghe giao'),
(40, 1, 2, 2, '2012-10-02 10:25:00', 'Nhập hàng từ ghe giao'),
(41, 1, 2, 2, '2012-10-03 11:25:00', 'Nhập hàng từ ghe giao'),
(42, 1, 2, 2, '2012-10-05 08:30:00', 'Nhập hàng từ ghe giao'),
(43, 1, 2, 2, '2012-10-17 09:25:00', 'Nhập hàng từ ghe giao'),
(44, 1, 2, 2, '2012-10-19 09:25:00', 'Nhập hàng từ ghe giao'),
(45, 1, 2, 2, '2012-10-20 09:30:00', 'Nhập hàng từ ghe giao'),
(46, 1, 2, 2, '2012-10-22 08:55:00', 'Nhập hàng từ ghe giao'),
(47, 1, 2, 2, '2012-10-27 10:25:00', 'Nhập hàng từ ghe giao'),
(48, 1, 2, 2, '2012-10-30 08:30:00', 'Nhập hàng từ ghe giao'),
(49, 1, 2, 2, '2012-10-31 08:35:00', 'Nhập hàng từ ghe giao'),
(50, 1, 2, 2, '2012-11-02 09:35:00', 'Nhập hàng từ ghe giao'),
(51, 1, 2, 2, '2012-11-07 08:30:00', 'Nhập hàng từ ghe giao'),
(52, 1, 2, 2, '2012-11-08 09:35:00', 'Nhập hàng từ ghe giao'),
(53, 1, 2, 2, '2012-11-12 08:55:00', 'Nhập hàng từ ghe giao'),
(54, 1, 2, 2, '2012-11-14 09:50:00', 'Nhập hàng từ ghe giao'),
(55, 1, 2, 2, '2012-11-15 09:50:00', 'Nhập hàng từ ghe giao'),
(56, 1, 2, 2, '2012-11-17 10:30:00', 'Nhập hàng từ ghe giao'),
(57, 1, 2, 2, '2012-11-19 10:30:00', 'Nhập hàng từ ghe giao'),
(58, 1, 2, 2, '2012-11-20 09:45:00', 'Nhập hàng từ ghe giao'),
(59, 1, 2, 2, '2012-11-22 15:25:00', 'Nhập hàng từ ghe giao'),
(60, 1, 2, 2, '2012-11-26 14:30:00', 'Nhập hàng từ ghe giao'),
(61, 1, 2, 2, '2012-11-28 08:30:00', 'Nhập hàng từ ghe giao'),
(62, 1, 2, 2, '2012-12-01 10:30:00', 'Nhập hàng từ ghe giao'),
(63, 1, 2, 2, '2012-12-03 08:50:00', 'Nhập hàng từ ghe giao'),
(64, 1, 2, 2, '2012-12-06 15:30:00', 'Nhập hàng từ ghe giao'),
(65, 1, 2, 2, '2012-12-12 09:25:00', 'Nhập hàng từ ghe giao'),
(66, 1, 2, 2, '2012-12-14 10:25:00', 'Nhập hàng từ ghe giao'),
(67, 1, 2, 2, '2012-12-17 09:30:00', 'Nhập hàng từ ghe giao'),
(68, 1, 2, 2, '2012-12-19 09:45:00', 'Nhập hàng từ ghe giao'),
(69, 1, 2, 2, '2012-12-20 09:45:00', 'Nhập hàng từ ghe giao'),
(70, 1, 2, 2, '2012-12-24 09:50:00', 'Nhập hàng từ ghe giao'),
(71, 1, 2, 2, '2012-12-29 10:30:00', 'Nhập hàng từ ghe giao'),
(72, 1, 2, 2, '2013-01-02 11:25:00', 'Nhập hàng từ ghe giao'),
(73, 1, 2, 2, '2013-01-03 10:20:00', 'Nhập hàng từ ghe giao'),
(74, 1, 2, 2, '2013-01-05 09:45:00', 'Nhập hàng từ ghe giao'),
(75, 1, 2, 2, '2013-01-07 21:30:00', 'Nhập hàng từ ghe giao'),
(76, 1, 2, 2, '2013-01-08 14:25:00', 'Nhập hàng từ ghe giao'),
(77, 1, 2, 2, '2013-01-09 08:55:00', 'Nhập hàng từ ghe giao'),
(78, 1, 2, 2, '2013-01-14 09:30:00', 'Nhập hàng từ ghe giao'),
(79, 1, 2, 2, '2013-01-15 11:25:00', 'Nhập hàng từ ghe giao'),
(80, 1, 2, 2, '2013-01-16 09:25:00', 'Nhập hàng từ ghe giao'),
(81, 1, 2, 2, '2013-01-18 09:25:00', 'Nhập hàng từ ghe giao'),
(82, 1, 2, 2, '2013-01-23 10:25:00', 'Nhập hàng từ ghe giao'),
(83, 1, 2, 2, '2013-01-26 09:20:00', 'Nhập hàng từ ghe giao'),
(84, 1, 2, 2, '2013-01-30 09:45:00', 'Nhập hàng từ ghe giao'),
(85, 1, 2, 2, '2013-02-01 09:20:00', 'Nhập hàng từ ghe giao'),
(86, 1, 2, 2, '2013-02-04 06:55:00', 'Nhập hàng từ ghe giao'),
(87, 1, 2, 2, '2013-02-06 11:00:00', 'Nhập hàng từ ghe giao'),
(88, 1, 2, 2, '2013-02-18 10:20:00', 'Nhập hàng từ ghe giao'),
(89, 1, 2, 2, '2013-02-20 10:25:00', 'Nhập hàng từ ghe giao'),
(90, 1, 2, 2, '2013-02-23 10:55:00', 'Nhập hàng từ ghe giao'),
(91, 1, 2, 2, '2013-02-25 09:20:00', 'Nhập hàng từ ghe giao'),
(92, 1, 2, 2, '2013-02-27 11:05:00', 'Nhập hàng từ ghe giao'),
(93, 1, 2, 2, '2013-03-01 21:25:00', 'Nhập hàng từ ghe giao'),
(94, 1, 2, 2, '2013-03-02 20:00:00', 'Nhập hàng từ ghe giao'),
(95, 1, 2, 2, '2013-03-04 14:20:00', 'Nhập hàng từ ghe giao'),
(96, 1, 2, 2, '2013-03-05 14:05:00', 'Nhập hàng từ ghe giao'),
(99, 1, 2, 2, '2013-03-06 09:00:00', 'Nhập hàng từ ghe giao'),
(100, 1, 2, 2, '2013-03-07 09:35:00', 'Nhập hàng từ ghe giao'),
(101, 1, 2, 2, '2013-03-09 11:05:00', 'Nhập hàng từ ghe giao'),
(102, 1, 2, 2, '2013-03-11 15:25:00', 'Nhập hàng từ ghe giao'),
(103, 1, 2, 2, '2013-03-12 14:05:00', 'Nhập hàng từ ghe giao'),
(104, 1, 2, 2, '2013-03-13 09:50:00', 'Nhập hàng từ ghe giao'),
(105, 1, 2, 2, '2013-03-14 14:05:00', 'Nhập hàng từ ghe giao'),
(106, 1, 2, 2, '2013-03-16 09:25:00', 'Nhập hàng từ ghe giao'),
(107, 1, 2, 2, '2013-03-18 13:20:00', 'Nhập hàng từ ghe giao'),
(108, 1, 2, 2, '2013-03-19 08:30:00', 'Nhập hàng từ ghe giao'),
(109, 1, 2, 2, '2013-03-20 10:30:00', 'Nhập hàng từ ghe giao'),
(110, 1, 2, 2, '2013-03-21 14:05:00', 'Nhập hàng từ ghe giao'),
(111, 1, 2, 2, '2013-03-22 09:10:00', 'Nhập hàng từ ghe giao'),
(112, 1, 2, 2, '2013-03-23 16:10:00', 'Nhập hàng từ ghe giao'),
(113, 1, 2, 2, '2013-03-25 09:55:00', 'Nhập hàng từ ghe giao'),
(114, 1, 2, 2, '2013-03-26 10:30:00', 'Nhập hàng từ ghe giao'),
(115, 1, 2, 2, '2013-03-28 14:20:00', 'Nhập hàng từ ghe giao'),
(116, 1, 2, 2, '2013-03-30 09:50:00', 'Nhập hàng từ ghe giao'),
(117, 1, 2, 2, '2013-04-01 08:50:00', 'Nhập hàng từ ghe giao'),
(118, 1, 2, 2, '2013-04-03 14:45:00', 'Nhập hàng từ ghe giao'),
(119, 1, 2, 2, '2013-04-05 14:00:00', 'Nhập hàng từ ghe giao'),
(120, 1, 2, 2, '2013-04-06 11:35:00', 'Nhập hàng từ ghe giao'),
(121, 1, 2, 2, '2013-04-08 13:05:00', 'Nhập hàng từ ghe giao'),
(122, 1, 2, 2, '2013-04-09 14:20:00', 'Nhập hàng từ ghe giao'),
(123, 1, 2, 2, '2013-04-10 10:10:00', 'Nhập hàng từ ghe giao'),
(124, 1, 2, 2, '2013-04-12 10:05:00', 'Nhập hàng từ ghe giao'),
(125, 1, 2, 2, '2013-04-13 11:05:00', 'Nhập hàng từ ghe giao'),
(126, 1, 2, 2, '2013-04-15 14:05:00', 'Nhập hàng từ ghe giao'),
(127, 1, 2, 2, '2013-04-17 14:05:00', 'Nhập hàng từ ghe giao'),
(128, 1, 2, 2, '2013-04-19 09:25:00', 'Nhập hàng từ ghe giao'),
(129, 1, 2, 2, '2013-04-20 16:25:00', 'Nhập hàng từ ghe giao'),
(130, 1, 2, 2, '2013-04-22 15:05:00', 'Nhập hàng từ ghe giao'),
(131, 1, 2, 2, '2013-04-24 14:00:00', 'Nhập hàng từ ghe giao'),
(132, 1, 2, 2, '2013-04-27 10:35:00', 'Nhập hàng từ ghe giao'),
(133, 1, 2, 2, '2013-04-30 08:55:00', 'Nhập hàng từ ghe giao'),
(134, 1, 2, 1, '2012-06-24 09:30:00', ''),
(135, 1, 2, 1, '2012-06-26 09:25:00', ''),
(136, 1, 2, 1, '2012-06-27 15:05:00', ''),
(137, 1, 2, 1, '2012-06-28 14:10:00', ''),
(138, 1, 2, 1, '2012-06-30 10:10:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_export_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_export_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_order` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_order` (`id_order`),
  KEY `id_resource` (`id_resource`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=178 ;

--
-- Dumping data for table `tbl_order_export_detail`
--

INSERT INTO `tbl_order_export_detail` (`id`, `id_order`, `id_resource`, `count`, `price`) VALUES
(39, 14, 90, 12000, 15850),
(40, 14, 95, 1200, 13270),
(41, 14, 99, 1000, 12330),
(42, 14, 112, 600, 11000),
(43, 14, 106, 3000, 11745),
(44, 13, 121, 2000, 11220),
(45, 19, 121, 2000, 11220),
(46, 20, 121, 2000, 11220),
(47, 21, 121, 4000, 11220),
(48, 22, 121, 2000, 11520),
(49, 23, 121, 3000, 11520),
(50, 24, 121, 3000, 11520),
(51, 25, 121, 6000, 11520),
(52, 26, 121, 2000, 11820),
(53, 29, 121, 6000, 11820),
(54, 30, 121, 2000, 11820),
(55, 31, 121, 3000, 11820),
(56, 32, 121, 3000, 11820),
(57, 33, 121, 3000, 12120),
(58, 34, 121, 2000, 12120),
(59, 35, 121, 2000, 12120),
(60, 36, 121, 2000, 12120),
(61, 36, 122, 2000, 12020),
(62, 37, 121, 2000, 12120),
(63, 37, 122, 2000, 12020),
(64, 38, 122, 2000, 12020),
(65, 39, 122, 3000, 12020),
(66, 40, 122, 3000, 12020),
(67, 41, 122, 5000, 12020),
(68, 42, 122, 7000, 12020),
(69, 43, 121, 2000, 12120),
(70, 43, 122, 1000, 12020),
(71, 44, 122, 2000, 12320),
(72, 45, 122, 5000, 12320),
(73, 46, 122, 2000, 12320),
(74, 47, 123, 6000, 12270),
(75, 48, 123, 4000, 12270),
(76, 49, 123, 4000, 12270),
(77, 50, 123, 3000, 12270),
(78, 51, 123, 4000, 12270),
(79, 52, 123, 3000, 12270),
(80, 53, 123, 3000, 12270),
(81, 54, 123, 3000, 12270),
(82, 55, 130, 3000, 12270),
(83, 56, 130, 3000, 12270),
(84, 57, 130, 3000, 12270),
(85, 58, 123, 6000, 12270),
(86, 59, 130, 3000, 12270),
(87, 60, 123, 3000, 12270),
(88, 61, 123, 5000, 12270),
(89, 62, 123, 4000, 12270),
(90, 63, 123, 7000, 12270),
(91, 64, 123, 2000, 12270),
(92, 65, 123, 5000, 12270),
(93, 66, 123, 6000, 12270),
(94, 67, 130, 6000, 12270),
(95, 68, 130, 4000, 12270),
(96, 69, 130, 6000, 12270),
(97, 70, 130, 12000, 12270),
(98, 71, 130, 7000, 12270),
(99, 72, 123, 2000, 12270),
(100, 73, 123, 2000, 12270),
(101, 74, 130, 4000, 12270),
(102, 75, 123, 2000, 12270),
(103, 76, 123, 2000, 12270),
(104, 77, 130, 6000, 12270),
(105, 78, 130, 3000, 12270),
(106, 79, 130, 2000, 12270),
(107, 80, 123, 3000, 12270),
(108, 81, 130, 3000, 12270),
(109, 82, 130, 4000, 12270),
(110, 83, 130, 6000, 12270),
(111, 84, 130, 4000, 12270),
(112, 85, 130, 3000, 12270),
(113, 86, 123, 4000, 12270),
(114, 87, 123, 12000, 12270),
(115, 88, 123, 3000, 12270),
(116, 89, 123, 3000, 12070),
(117, 90, 130, 3000, 12070),
(118, 91, 123, 6000, 12070),
(119, 92, 123, 3000, 12070),
(120, 93, 123, 4000, 12070),
(121, 94, 130, 2000, 12070),
(122, 95, 123, 4000, 12070),
(123, 96, 123, 4000, 12070),
(124, 99, 130, 3000, 12070),
(125, 100, 123, 3000, 12070),
(126, 100, 130, 2000, 12070),
(127, 101, 130, 2000, 12070),
(128, 102, 130, 2000, 12070),
(129, 103, 123, 3000, 12070),
(130, 103, 130, 3000, 12070),
(131, 104, 130, 6000, 12070),
(132, 105, 123, 3000, 12070),
(133, 105, 130, 3000, 12070),
(134, 106, 123, 3000, 12070),
(135, 106, 130, 3000, 12070),
(136, 107, 130, 3000, 12070),
(137, 108, 130, 3000, 12070),
(138, 109, 130, 4000, 12070),
(139, 110, 130, 2000, 12070),
(140, 111, 130, 3000, 12070),
(141, 112, 123, 3000, 12070),
(142, 113, 130, 2000, 12070),
(143, 114, 123, 4000, 12070),
(144, 115, 123, 4000, 12070),
(145, 116, 130, 3000, 12070),
(146, 117, 123, 4000, 12070),
(147, 118, 123, 3000, 12070),
(148, 119, 123, 4000, 12070),
(149, 120, 123, 3000, 12070),
(150, 121, 123, 4000, 12070),
(151, 122, 123, 3000, 12070),
(152, 123, 123, 4000, 12070),
(153, 124, 123, 3000, 12070),
(154, 125, 123, 5000, 12070),
(155, 126, 123, 3000, 12070),
(156, 127, 123, 3000, 12070),
(157, 128, 123, 4000, 12070),
(158, 129, 123, 3000, 12070),
(159, 130, 123, 4000, 12070),
(160, 131, 123, 4000, 12070),
(161, 132, 123, 4000, 12070),
(162, 133, 123, 1000, 12070),
(163, 134, 142, 25, 80000),
(164, 134, 143, 10, 60000),
(165, 135, 26, 2, 565000),
(166, 136, 2, 12, 175000),
(167, 136, 18, 6, 400000),
(168, 136, 17, 1, 160000),
(169, 137, 23, 5, 150000),
(170, 137, 17, 4, 160000),
(172, 137, 50, 2, 142000),
(173, 137, 31, 2, 110000),
(174, 137, 147, 8, 50000),
(175, 138, 64, 6, 160000),
(176, 138, 18, 3, 400000),
(177, 138, 82, 10, 340000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_order_import`
--

INSERT INTO `tbl_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(1, 9, '2013-11-15', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_detail_1` (`idorder`),
  KEY `tbl_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_order_import_detail`
--

INSERT INTO `tbl_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(1, 1, 90, 20000, 15058),
(2, 1, 93, 10000, 12635),
(3, 1, 97, 3000, 12607);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tracking` (`id_tracking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_general`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_paid_general`
--

INSERT INTO `tbl_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(1, 6, '2013-08-07', 1000000, 'Tiền điện'),
(2, 6, '2013-08-15', 200000, 'Tiền nước');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idemployee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_pay_roll_1` (`idemployee`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_paid_pay_roll`
--

INSERT INTO `tbl_paid_pay_roll` (`id`, `idemployee`, `date`, `value_base`, `value_sub`, `value_pre`, `note`) VALUES
(1, 1, '2013-04-30', 2500000, 500000, 1000000, ''),
(2, 2, '2013-05-31', 2500000, 0, 3000000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_supplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_supplier` (`id_supplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_paid_supplier`
--

INSERT INTO `tbl_paid_supplier` (`id`, `id_supplier`, `date`, `value`, `note`) VALUES
(4, 6, '2012-09-19', 1000000, 'Thử nè được không đó !'),
(7, 6, '2013-11-15', 2, NULL),
(8, 9, '2013-11-15', 2000000, 'Ứng tiền xăng');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_r2t`
--

CREATE TABLE IF NOT EXISTS `tbl_r2t` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_resource` int(11) NOT NULL,
  `id_tag` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_resource` (`id_resource`),
  KEY `id_tag` (`id_tag`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=318 ;

--
-- Dumping data for table `tbl_r2t`
--

INSERT INTO `tbl_r2t` (`id`, `id_resource`, `id_tag`) VALUES
(3, 90, 11),
(4, 90, 49),
(5, 90, 2),
(6, 90, 59),
(7, 90, 64),
(8, 90, 61),
(9, 91, 11),
(10, 91, 51),
(11, 91, 2),
(12, 91, 59),
(13, 91, 64),
(14, 91, 61),
(15, 92, 11),
(16, 92, 49),
(17, 92, 2),
(18, 92, 12),
(19, 92, 64),
(20, 92, 61),
(21, 93, 11),
(22, 93, 51),
(23, 93, 2),
(24, 93, 12),
(25, 93, 64),
(26, 93, 47),
(27, 93, 61),
(28, 94, 11),
(29, 94, 48),
(30, 94, 2),
(31, 94, 12),
(32, 94, 64),
(33, 94, 61),
(34, 95, 11),
(35, 95, 52),
(36, 95, 2),
(37, 95, 12),
(38, 95, 64),
(39, 95, 61),
(40, 96, 11),
(41, 96, 38),
(42, 96, 2),
(43, 96, 12),
(44, 96, 64),
(45, 96, 61),
(46, 97, 11),
(47, 97, 53),
(48, 97, 2),
(49, 97, 12),
(50, 97, 64),
(51, 97, 61),
(52, 98, 11),
(53, 98, 49),
(54, 98, 2),
(55, 98, 58),
(56, 98, 64),
(57, 98, 61),
(58, 99, 11),
(59, 99, 51),
(60, 99, 2),
(61, 99, 58),
(62, 99, 64),
(63, 99, 61),
(64, 100, 11),
(65, 100, 48),
(66, 100, 2),
(67, 100, 58),
(68, 100, 64),
(69, 100, 61),
(70, 101, 11),
(71, 101, 52),
(72, 101, 2),
(73, 101, 58),
(74, 101, 64),
(75, 101, 61),
(76, 102, 11),
(77, 102, 38),
(78, 102, 2),
(79, 102, 58),
(80, 102, 64),
(81, 102, 61),
(82, 103, 11),
(83, 103, 48),
(84, 103, 2),
(85, 103, 47),
(86, 103, 64),
(87, 103, 61),
(88, 104, 11),
(89, 104, 52),
(90, 104, 2),
(91, 104, 47),
(92, 104, 64),
(93, 104, 61),
(94, 105, 11),
(95, 105, 38),
(96, 105, 2),
(97, 105, 47),
(98, 105, 64),
(99, 105, 61),
(100, 106, 11),
(101, 106, 53),
(102, 106, 2),
(103, 106, 47),
(104, 106, 64),
(105, 106, 61),
(106, 107, 11),
(107, 107, 54),
(108, 107, 2),
(109, 107, 47),
(110, 107, 64),
(111, 107, 61),
(112, 108, 11),
(113, 108, 55),
(114, 108, 2),
(115, 108, 47),
(116, 108, 64),
(117, 108, 61),
(118, 109, 11),
(119, 109, 56),
(120, 109, 2),
(121, 109, 47),
(122, 109, 64),
(123, 109, 61),
(124, 110, 11),
(125, 110, 53),
(126, 110, 2),
(127, 110, 5),
(128, 110, 64),
(129, 110, 61),
(130, 111, 11),
(131, 111, 54),
(132, 111, 2),
(133, 111, 5),
(134, 111, 64),
(135, 111, 61),
(136, 112, 11),
(137, 112, 55),
(138, 112, 2),
(139, 112, 5),
(140, 112, 64),
(141, 112, 61),
(142, 113, 11),
(143, 113, 56),
(144, 113, 2),
(145, 113, 5),
(146, 113, 64),
(147, 113, 61),
(148, 114, 11),
(149, 114, 55),
(150, 114, 2),
(151, 114, 57),
(152, 114, 64),
(153, 114, 61),
(154, 115, 11),
(155, 115, 56),
(156, 115, 2),
(157, 115, 57),
(158, 115, 64),
(159, 115, 61),
(160, 138, 11),
(161, 138, 67),
(162, 138, 2),
(163, 138, 59),
(164, 138, 64),
(165, 138, 61),
(166, 139, 11),
(167, 139, 67),
(168, 139, 2),
(169, 139, 12),
(170, 139, 64),
(171, 139, 61),
(172, 140, 11),
(173, 140, 67),
(174, 140, 2),
(175, 140, 58),
(176, 140, 64),
(177, 140, 61),
(178, 141, 11),
(179, 141, 53),
(180, 141, 2),
(181, 141, 58),
(182, 141, 64),
(183, 141, 61),
(184, 116, 11),
(185, 116, 49),
(186, 116, 2),
(187, 116, 12),
(188, 116, 64),
(189, 116, 61),
(190, 117, 11),
(191, 117, 50),
(192, 117, 2),
(193, 117, 12),
(194, 117, 64),
(195, 117, 61),
(196, 118, 11),
(197, 118, 48),
(198, 118, 2),
(199, 118, 12),
(200, 118, 64),
(201, 118, 61),
(202, 119, 11),
(204, 119, 52),
(205, 119, 2),
(206, 119, 12),
(207, 119, 64),
(208, 119, 61),
(209, 120, 11),
(210, 120, 50),
(211, 120, 2),
(212, 120, 47),
(213, 120, 64),
(214, 120, 61),
(215, 121, 11),
(216, 121, 48),
(217, 121, 2),
(218, 121, 47),
(219, 121, 64),
(220, 121, 61),
(221, 122, 11),
(222, 122, 52),
(223, 122, 2),
(224, 122, 47),
(225, 122, 64),
(226, 122, 61),
(227, 123, 11),
(228, 123, 53),
(229, 123, 2),
(230, 123, 47),
(231, 123, 64),
(232, 123, 61),
(233, 124, 11),
(234, 124, 52),
(235, 124, 2),
(236, 124, 5),
(237, 124, 64),
(238, 124, 61),
(239, 125, 11),
(240, 125, 53),
(241, 125, 2),
(242, 125, 5),
(243, 125, 64),
(244, 125, 59),
(245, 125, 61),
(246, 126, 11),
(247, 126, 52),
(248, 126, 2),
(249, 126, 3),
(250, 126, 64),
(251, 126, 61),
(252, 127, 11),
(253, 127, 53),
(254, 127, 2),
(255, 127, 3),
(256, 127, 64),
(257, 127, 61),
(258, 128, 11),
(259, 128, 38),
(260, 128, 2),
(261, 128, 12),
(262, 128, 64),
(263, 128, 61),
(264, 129, 11),
(265, 129, 38),
(266, 129, 2),
(267, 129, 47),
(268, 129, 64),
(269, 129, 61),
(270, 130, 11),
(271, 130, 54),
(272, 130, 2),
(273, 130, 47),
(274, 130, 64),
(275, 130, 61),
(276, 131, 11),
(277, 131, 55),
(278, 131, 2),
(279, 131, 47),
(280, 131, 64),
(281, 131, 61),
(282, 132, 11),
(283, 132, 38),
(284, 132, 2),
(285, 132, 5),
(286, 132, 64),
(287, 132, 61),
(288, 133, 11),
(289, 133, 54),
(290, 133, 2),
(291, 133, 5),
(292, 133, 64),
(293, 133, 61),
(294, 134, 11),
(295, 134, 55),
(296, 134, 2),
(297, 134, 5),
(298, 134, 64),
(299, 134, 61),
(300, 135, 11),
(301, 135, 38),
(302, 135, 2),
(303, 135, 3),
(304, 135, 64),
(305, 135, 61),
(306, 136, 11),
(307, 136, 54),
(308, 136, 2),
(309, 136, 3),
(310, 136, 64),
(311, 136, 61),
(312, 137, 11),
(313, 137, 55),
(314, 137, 2),
(315, 137, 3),
(316, 137, 64),
(317, 137, 61);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE IF NOT EXISTS `tbl_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `name_short` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `price_import` int(11) NOT NULL,
  `price_export` int(11) NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `barcode` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=148 ;

--
-- Dumping data for table `tbl_resource`
--

INSERT INTO `tbl_resource` (`id`, `idsupplier`, `name`, `name_short`, `unit`, `price_import`, `price_export`, `description`, `barcode`) VALUES
(2, 4, 'Pro Iodine', 'PRO IODINE', 'Lít', 140000, 175000, '', ''),
(3, 4, 'NT BKC', 'NT BKC', 'Lít', 75200, 94000, '', ''),
(4, 4, 'Yuccanic', 'YUCCANIC', 'Lít', 232000, 290000, '', ''),
(5, 4, 'Yuccanic', 'YUCCANIC', 'Bao 10Kg', 280000, 350000, '', ''),
(6, 4, 'NT Gano', 'NT GANO', 'Kg', 416000, 520000, '', ''),
(7, 4, 'NT FA', 'NT FA', 'Kg', 350400, 438000, '', ''),
(8, 4, 'NT Dio', 'NT DIO', 'Kg', 368000, 460000, '', ''),
(9, 4, 'NT AA', 'NT AA', 'Kg', 294400, 368000, '', ''),
(10, 4, 'NT FR7000', 'NT FR7000', 'Lít', 180000, 225000, '', ''),
(11, 4, 'Vitamin C', 'VITAMIN C', 'Kg', 84000, 105000, '', ''),
(12, 4, 'Vitalec Fish', 'VITALEC FISH', 'Kg', 57600, 72000, '', ''),
(13, 4, 'Pro Men', 'PRO MEN', 'Kg', 40000, 50000, '', ''),
(14, 4, 'Pro Best', 'PRO BEST', 'Kg', 73600, 92000, '', ''),
(15, 4, 'Fendory', 'FENDORY', 'Kg', 68800, 86000, '', ''),
(16, 4, 'Praziquantel', 'PRAZIQUANTEL', 'Kg', 128000, 160000, '', ''),
(17, 4, 'Sulfatrime', 'SULFATRIME', 'Kg', 120000, 150000, '', ''),
(18, 4, 'Moxine', 'MOXINE', 'Kg', 249600, 312000, '', ''),
(19, 4, 'Facine', 'FACINE', 'Kg', 268000, 335000, '', ''),
(20, 4, 'Gencine', 'GENCINE', 'Kg', 204000, 255000, '', ''),
(21, 4, 'C-E-N', 'C-E-N', 'Kg', 312000, 390000, '', ''),
(22, 4, 'Flodo', 'FLODO', 'Kg', 400000, 500000, '', ''),
(23, 5, 'Protex', 'PROTEX', 'Lít', 120000, 150000, '', ''),
(24, 5, 'Water', 'WATER', 'Kg', 138400, 173000, '', ''),
(25, 5, 'BKC', 'BKC', 'Lít', 92000, 115000, '', ''),
(26, 5, 'BKC', 'BKC', 'Can 5Lít', 452000, 565000, '', ''),
(27, 5, 'Solco', 'SOLCO', 'Lít', 138400, 173000, '', ''),
(28, 5, 'Yucca', 'YUCCA', 'Xô 21Kg', 261600, 327000, '', ''),
(29, 5, 'C-A-P', 'CAP', 'Gói 2Kg', 68000, 85000, '', ''),
(30, 5, 'Vitamin C', 'VITAMIN C', 'Kg', 60000, 75000, '', ''),
(31, 5, 'Glucamin', 'GLUCAMIN', 'Kg', 88000, 110000, '', ''),
(32, 5, 'Grown', 'GROWN', 'Kg', 64800, 81000, '', ''),
(33, 5, 'C - tạt', 'C - TẠT', 'Xô 7Kg', 232800, 291000, '', ''),
(34, 5, 'Vitamin', 'VITAMIN', 'Kg', 60000, 75000, '', ''),
(35, 5, 'Sotol', 'SOTOL', 'Kg', 180000, 225000, '', ''),
(36, 5, 'Giải độc gan', 'GIẢI ĐỘC GAN', 'Kg', 96800, 121000, '', ''),
(37, 6, 'Mebi Prazi - One', 'MEBI PRAZI - ONE', 'Kg', 224000, 280000, '', ''),
(38, 6, 'Aqua Clean', 'AQUA CLEAN', 'Kg', 96000, 120000, '', ''),
(39, 6, 'Cắt tảo', 'CẮT TẢO', 'Kg', 124000, 155000, '', ''),
(40, 6, 'Mebi - BKC 80', 'MEBI - BKC 80', 'Lít', 92000, 115000, '', ''),
(41, 6, 'Mebi - BKC 80', 'MEBI - BKC 80', 'Can 5Lít', 440000, 550000, '', ''),
(42, 6, 'Mebi - Allcide', 'MEBI - ALLCIDE', 'Lít', 92000, 115000, '', ''),
(43, 6, 'Mebi - BZ', 'MEBI - BZ', 'Kg', 264000, 330000, '', ''),
(44, 6, 'Mebi Yuca Zeo', 'MEBI YUCA ZEO', 'Xô 5Kg', 108000, 135000, '', ''),
(45, 6, 'Mebi - Grown one', 'MEBI - GROWN ONE', 'Kg', 108000, 135000, '', ''),
(46, 6, 'Mebivita', 'MEBIVITA', 'Kg', 48000, 60000, '', ''),
(47, 6, 'Mebi - Obimin', 'MEBI - OBIMIN', 'Kg', 76000, 95000, '', ''),
(48, 6, 'β - Glucan', 'β - GLUCAN', 'Kg', 96000, 120000, '', ''),
(49, 6, 'Mebi Aqua C 15%', 'MEBI AQUA C 15%', 'Kg', 64000, 80000, '', ''),
(50, 6, 'Hepasol - B12', 'HEPASOL - B12', 'Lít', 136000, 142000, '', ''),
(51, 7, 'Pro Iodine', 'PRO IODINE', 'Lít', 145000, 175000, '', ''),
(52, 7, 'Yuccanic', 'YUCCANIC', 'Lít', 232000, 290000, '', ''),
(53, 7, 'Yuccanic', 'YUCCANIC', 'Bao 10Kg', 280000, 350000, '', ''),
(54, 7, 'NT Gano', 'NT GANO', 'Kg', 416000, 520000, '', ''),
(55, 7, 'NT Dio', 'NT DIO', 'Kg', 368000, 460000, '', ''),
(56, 7, 'NT AA', 'NT AA', 'Kg', 294400, 368000, '', ''),
(57, 7, 'NT FR7000', 'NT FR7000', 'Lít', 180000, 225000, '', ''),
(58, 7, 'Vitamin C', 'VITAMIN C', 'Kg', 84000, 105000, '', ''),
(59, 7, 'Vitamin C', 'VITAMIN C', 'Xô 5Kg', 420000, 525000, '', ''),
(60, 7, 'Pro Men', 'PRO MEN', 'Kg', 40000, 50000, '', ''),
(61, 7, 'Pro Best', 'PRO BEST', 'Kg', 73600, 92000, '', ''),
(62, 7, 'Fendory', 'FENDORY', 'Kg', 128000, 160000, '', ''),
(63, 7, 'Praziquantel', 'PRAZIQUANTEL', 'Kg', 212000, 265000, '', ''),
(64, 7, 'Sulfatrime', 'SULFATRIME', 'Kg', 120000, 150000, '', ''),
(65, 7, 'Moxine', 'MOXINE', 'Kg', 249600, 312000, '', ''),
(66, 7, 'Facine', 'FACINE', 'Kg', 268000, 335000, '', ''),
(67, 7, 'Gencine', 'GENCINE', 'Kg', 204000, 255000, '', ''),
(68, 7, 'C-E-N', 'C-E-N', 'Kg', 312000, 390000, '', ''),
(69, 7, 'Flodo', 'FLODO', 'Kg', 400000, 500000, '', ''),
(70, 8, 'BKS - 80 florline', 'BKS - 80 FLORLINE', 'Lít', 92000, 115000, '', ''),
(71, 8, 'GLU - RV', 'GLU - RV', 'Kg', 201600, 252000, '', ''),
(72, 8, 'Tomi copper', 'TOMI COPPER', 'Can 5Lít', 232000, 290000, '', ''),
(73, 8, 'Goal', 'GOAL', 'Gói 500Gr', 128800, 161000, '', ''),
(74, 8, 'Goal', 'GOAL', 'Kg', 252800, 316000, '', ''),
(75, 8, 'Extra', 'EXTRA', 'Can 5Lít', 344000, 430000, '', ''),
(76, 8, 'UV 200', 'UV 200', 'Can 5Lít', 404800, 506000, '', ''),
(77, 8, 'Hepatic', 'HEPATIC', 'Lít', 112000, 140000, '', ''),
(78, 8, 'C-S', 'C-S', 'Xô 10Kg', 616800, 771000, '', ''),
(79, 8, 'Folic', 'FOLIC', 'Kg', 86400, 108000, '', ''),
(80, 8, 'Vitaglucan - B12', 'VITAGLUCAN - B12', 'Kg', 89600, 112000, '', ''),
(81, 8, 'Vicin', 'VICIN', 'Kg', 298400, 373000, '', ''),
(82, 8, 'A-C', 'A-C', 'Kg', 272000, 340000, '', ''),
(83, 8, 'Sulfa', 'SULFA', 'Kg', 160000, 200000, '', ''),
(84, 8, 'Lofe', 'LOFE', 'Kg', 332000, 415000, '', ''),
(85, 8, 'Thiam', 'THIAM', 'Kg', 317600, 397000, '', ''),
(86, 8, 'Thidolin', 'THIDOLIN', 'Kg', 364800, 456000, '', ''),
(87, 8, 'Omicin', 'OMICIN', 'Kg', 144800, 181000, '', ''),
(88, 8, 'Ridoxyne', 'RIDOXYNE', 'Kg', 547200, 684000, '', ''),
(89, 8, 'Thidomethey', 'THIDOMETHEY', 'Kg', 476800, 596000, '', ''),
(90, 9, 'DMF - 02 - 35 (1.5)', 'DMF - 02 - 35 (1.5)', 'Kg', 15058, 15850, '', ''),
(91, 9, 'DMF - 02 - 35 (2,2)', 'DMF - 02 - 35 (2,2)', 'Kg', 14260, 15010, '', ''),
(92, 9, 'DMF - 03 - 30 (1.5)', 'DMF - 03 - 30 (1.5)', 'Kg', 13538, 14250, '', ''),
(93, 9, 'DMF - 03 - 30 (2,2)', 'DMF - 03 - 30 (2,2)', 'Kg', 12635, 13300, '', ''),
(94, 9, 'DMF - 03 - 30 (3)', 'DMF - 03 - 30 (3)', 'Kg', 12616, 13280, '', ''),
(95, 9, 'DMF - 03 - 30 (4)', 'DMF - 03 - 30 (4)', 'Kg', 12607, 13270, '', ''),
(96, 9, 'DMF - 03 - 30 (5)', 'DMF - 03 - 30 (5)', 'Kg', 12607, 13270, '', ''),
(97, 9, 'DMF - 03 - 30 (6)', 'DMF - 03 - 30 (6)', 'Kg', 12607, 13270, '', ''),
(98, 9, 'DMF - 04 - 28 (1.5)', 'DMF - 04 - 28 (1.5)', 'Kg', 12730, 13400, '', ''),
(99, 9, 'DMF - 04 - 28 (2,2)', 'DMF - 04 - 28 (2,2)', 'Kg', 11714, 12330, '', ''),
(100, 9, 'DMF - 04 - 28 (3)', 'DMF - 04 - 28 (3)', 'Kg', 11695, 12310, '', ''),
(101, 9, 'DMF - 04 - 28 (4)', 'DMF - 04 - 28 (4)', 'Kg', 11685, 12300, '', ''),
(102, 9, 'DMF - 04 - 28 (5)', 'DMF - 04 - 28 (5)', 'Kg', 11680, 12295, '', ''),
(103, 9, 'DMF - 05 - 26 (3)', 'DMF - 05 - 26 (3)', 'Kg', 11172, 11760, '', ''),
(104, 9, 'DMF - 05 - 26 (4)', 'DMF - 05 - 26 (4)', 'Kg', 11163, 11750, '', ''),
(105, 9, 'DMF - 05 - 26 (5)', 'DMF - 05 - 26 (5)', 'Kg', 11158, 11745, '', ''),
(106, 9, 'DMF - 05 - 26 (6)', 'DMF - 05 - 26 (6)', 'Kg', 11158, 11745, '', ''),
(107, 9, 'DMF - 05 - 26 (8)', 'DMF - 05 - 26 (8)', 'Kg', 11153, 11740, '', ''),
(108, 9, 'DMF - 05 - 26 (10)', 'DMF - 05 - 26 (10)', 'Kg', 11153, 11740, '', ''),
(109, 9, 'DMF - 05 - 26 (12)', 'DMF - 05 - 26 (12)', 'Kg', 11153, 11740, '', ''),
(110, 9, 'DMF - 06 - 22 (6)', 'DMF - 06 - 22 (6)', 'Kg', 10460, 11010, '', ''),
(111, 9, 'DMF - 06 - 22 (8)', 'DMF - 06 - 22 (8)', 'Kg', 10450, 11000, '', ''),
(112, 9, 'DMF - 06 - 22 (10)', 'DMF - 06 - 22 (10)', 'Kg', 10450, 11000, '', ''),
(113, 9, 'DMF - 06 - 22 (12)', 'DMF - 06 - 22 (12)', 'Kg', 10450, 11000, '', ''),
(114, 9, 'DMF - 07 - 20 (10)', 'DMF - 07 - 20 (10)', 'Kg', 10070, 10600, '', ''),
(115, 9, 'DMF - 07 - 20 (12)', 'DMF - 07 - 20 (12)', 'Kg', 10070, 10600, '', ''),
(116, 10, 'MK 203 - 30 (1.5)', '203 - 30 (1.5)', 'Kg', 13652, 14370, '', ''),
(117, 10, 'MK 203 - 30 (2)', '203 - 30 (2)', 'Kg', 13082, 13770, '', ''),
(118, 10, 'MK 203 - 30 (3)', '203 - 30 (3)', 'Kg', 12844, 13520, '', ''),
(119, 10, 'MK 203 - 30 (4)', '203 - 30 (4)', 'Kg', 12749, 13420, '', ''),
(120, 10, 'MK 204 - 26 (2)', '204 - 26 (2)', 'Kg', 11704, 12320, '', ''),
(121, 10, 'MK 204 - 26 (3)', '204 - 26 (3)', 'Kg', 11609, 12220, '', ''),
(122, 10, 'MK 204 - 26 (4)', '204 - 26 (4)', 'Kg', 11514, 12120, '', ''),
(123, 10, 'MK 204 - 26 (6)', '204 - 26 (6)', 'Kg', 11467, 12070, '', ''),
(124, 10, 'MK 205 - 22 (4)', '205 - 22 (4)', 'Kg', 11039, 11620, '', ''),
(125, 10, 'MK 205 - 22 (6)', '205 - 22 (6)', 'Kg', 10992, 11570, '', ''),
(126, 10, 'MK 206 - 18 (4)', '206 - 18 (4)', 'Kg', 10707, 11270, '', ''),
(127, 10, 'MK 206 - 18 (6)', '206 - 18 (6)', 'Kg', 10659, 11220, '', ''),
(128, 10, 'MK 203 - 30 (5)', '203 - 30 (5)', 'Kg', 12749, 13420, '', ''),
(129, 10, 'MK 204 - 26 (5)', '204 - 26 (5)', 'Kg', 11514, 12120, '', ''),
(130, 10, 'MK 204 - 26 (8)', '204 - 26 (8)', 'Kg', 11467, 12070, '', ''),
(131, 10, 'MK 204 - 26 (10)', '204 - 26 (10)', 'Kg', 11467, 12070, '', ''),
(132, 10, 'MK 205 - 22 (5)', '205 - 22 (5)', '5 Lít', 11039, 11620, '', ''),
(133, 10, 'MK 205 - 22 (8)', '205 - 22 (8)', 'Kg', 10992, 11570, '', ''),
(134, 10, 'MK 205 - 22 (10)', '205 - 22 (10)', 'Kg', 10992, 11570, '', ''),
(135, 10, 'MK 206 - 18 (5)', '206 - 18 (5)', 'Kg', 10707, 11270, '', ''),
(136, 10, 'MK 206 - 18 (8)', '206 - 18 (8)', 'Kg', 10659, 11220, '', ''),
(137, 10, 'MK 206 - 18 (10)', '206 - 18 (10)', 'Kg', 10659, 11220, '', ''),
(138, 9, 'DMF - 02 - 35 (2,5)', 'DMF - 02 - 35 (2,5)', 'Kg', 14260, 15010, '', ''),
(139, 9, 'DMF - 03 - 30 (2,5)', 'DMF 30 - 2,5', 'Kg', 12635, 13300, '', ''),
(140, 9, 'DMF - 04 - 28 (2,5)', 'DMF 28 - 2,5', 'Kg', 11714, 12330, '', ''),
(141, 9, 'DMF - 04 - 28 (6)', 'DMF 28 - 6', 'Kg', 11680, 12295, '', ''),
(142, 11, 'Đồng CuSO4', 'CuSO4', 'Kg', 64000, 80000, '', ''),
(143, 11, 'Chlorine', 'Chlorine', 'Kg', 44000, 60000, '', ''),
(144, 11, 'Enro', 'Enro', 'Kg', 696000, 870000, '', ''),
(145, 11, 'Methyl', '', 'Kg', 160000, 200000, '', ''),
(146, 11, 'Vitamin C', '', 'Kg', 160000, 200000, '', ''),
(147, 5, 'C-A-P', '', 'Kg', 40000, 50000, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(4, 'THUỐC TS ĐÌNH HƯNG', '', '', 'BÀ CON NAM THÁI', 0),
(5, 'THUỐC TS LVS', '', '', 'Cung cấp thuốc', 0),
(6, 'THUỐC TS MEBIPHA', '', '', '', 0),
(7, 'THUỐC TS NAM THÁI', '', '', '', 0),
(8, 'THUỐC TS UYÊN VI', '', '', '', 0),
(9, 'THỨC ĂN TS DOMYFEED', '', '', '', 0),
(10, 'THỨC ĂN TS MEKONG', '', '', '', 0),
(11, 'THUỐC NGUYÊN LIỆU', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_supplier` int(11) NOT NULL,
  `id_domain` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_supplier` (`id_supplier`),
  KEY `id_domain` (`id_domain`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_supplier_domain`
--

INSERT INTO `tbl_supplier_domain` (`id`, `id_supplier`, `id_domain`) VALUES
(1, 4, 2),
(2, 4, 1),
(3, 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tag`
--

CREATE TABLE IF NOT EXISTS `tbl_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=68 ;

--
-- Dumping data for table `tbl_tag`
--

INSERT INTO `tbl_tag` (`id`, `name`) VALUES
(1, 'Protein 25%'),
(2, 'Dạng viên nổi'),
(3, 'Protein 18% '),
(5, 'Protein 22% '),
(6, 'Nhóm kháng sinh'),
(7, 'Dạng bột'),
(8, 'mức nguy hiểm - có độc'),
(9, 'Nhóm dinh dưỡng'),
(10, 'Dạng nước'),
(11, 'Bao bì mới'),
(12, 'Protein 30%'),
(13, 'mức nguy hiểm - cực độc'),
(14, 'Bao bì cũ'),
(38, 'Cỡ viên - 5.0mm'),
(39, 'mức nguy hiểm - không độc'),
(47, 'Protein 26%'),
(48, 'Cỡ viên - 3.0mm'),
(49, 'Cỡ viên - 1.5mm'),
(50, 'Cỡ viên - 2.0mm'),
(51, 'Cỡ viên - 2.2mm'),
(52, 'Cỡ viên - 4.0mm'),
(53, 'Cỡ viên - 6.0mm'),
(54, 'Cỡ viên - 8.0mm'),
(55, 'Cỡ viên - 10.0mm'),
(56, 'Cỡ viên 12mm'),
(57, 'Protein 20%'),
(58, 'Protein 28%'),
(59, 'Protein 35%'),
(60, 'Protein 40%'),
(61, 'Thủy sản'),
(62, 'Thú y'),
(63, 'Thuốc'),
(64, 'Thức ăn'),
(65, 'Nhóm xử lý'),
(66, 'Nhóm thảo dược'),
(67, 'Cỡ viên - 2.5mm');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tag_selected`
--

CREATE TABLE IF NOT EXISTS `tbl_tag_selected` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtag` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_tag_selected`
--

INSERT INTO `tbl_tag_selected` (`id`, `idtag`) VALUES
(1, 21),
(2, 18),
(3, 43),
(4, 25),
(5, 17),
(6, 42);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_collect`
--

CREATE TABLE IF NOT EXISTS `tbl_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_term_collect`
--

INSERT INTO `tbl_term_collect` (`id`, `name`) VALUES
(1, 'Phụ Phẩm'),
(2, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_paid`
--

CREATE TABLE IF NOT EXISTS `tbl_term_paid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_term_paid`
--

INSERT INTO `tbl_term_paid` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(4, 'Lương Nhân Viên', 0),
(5, 'Tiền Ăn Nhân Viên', 0),
(6, 'CP Khác', 0),
(7, 'Tiền Phụ Cấp Nhân viên', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `estate_rate` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`, `estate_rate`) VALUES
(3, '2013-09-01', '2013-09-30', 0),
(5, '2013-08-01', '2013-08-31', 0),
(6, '2013-10-01', '2013-10-31', 0),
(7, '2012-06-01', '2012-06-30', 0),
(8, '2012-07-01', '2012-07-31', 0),
(9, '2012-08-01', '2012-08-31', 0),
(10, '2012-09-01', '2012-09-30', 0),
(11, '2012-10-01', '2012-10-31', 0),
(12, '2012-11-01', '2012-11-30', 0),
(13, '2012-12-01', '2012-12-31', 0),
(14, '2013-01-01', '2013-01-31', 0),
(15, '2013-02-01', '2013-02-28', 0),
(16, '2013-03-01', '2013-03-31', 0),
(17, '2013-04-01', '2013-04-30', 0),
(18, '2013-05-01', '2013-05-31', 0),
(19, '2013-06-01', '2013-06-30', 0),
(20, '2013-07-01', '2013-07-31', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_ct`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_ct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_ct` int(11) NOT NULL,
  `date` date NOT NULL,
  `oe_value` int(11) NOT NULL,
  `pc_value` int(11) NOT NULL,
  `cc_value` int(11) NOT NULL,
  `debt_value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ct` (`id_ct`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_tracking_ct`
--

INSERT INTO `tbl_tracking_ct` (`id`, `id_ct`, `date`, `oe_value`, `pc_value`, `cc_value`, `debt_value`) VALUES
(1, 1, '2012-06-24', 2600000, 0, 0, 2600000),
(2, 1, '2012-06-26', 1130000, 0, 0, 3730000),
(3, 1, '2012-06-27', 4660000, 0, 0, 8390000),
(4, 1, '2012-06-28', 2294000, 0, 0, 10684000),
(5, 1, '2012-06-30', 5560000, 0, 0, 16244000),
(6, 1, '2012-07-02', 22440000, 0, 0, 38684000),
(7, 1, '2012-07-06', 22440000, 0, 0, 61124000),
(8, 1, '2012-07-17', 22440000, 0, 0, 83564000),
(9, 1, '2012-07-28', 44880000, 0, 0, 128444000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_store`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_tracking_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=28 ;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`id`, `name`) VALUES
(1, 'Lít'),
(2, 'Xô 21Kg'),
(4, 'Xô 7Kg'),
(5, 'Xô 5Kg'),
(6, 'Can 5Lít'),
(7, 'Xô 10Kg'),
(9, 'Gói 5Kg'),
(12, 'Gói 500Gr'),
(14, 'Bao 20Kg'),
(18, 'Bao 25Kg'),
(25, 'Bao 10Kg'),
(26, 'Gói 2Kg'),
(27, 'Kg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'Tuấn - QT001', 'tuanbuithanh@gmail.com', 'admin123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(2, 'Khoa - QT002', 'lekhoa.bdc@gmail.com', 'lenguyen0945030709...', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '1'),
(3, 'Khoa - NV001', 'lenguyen.bdc@gmail.com', 'admin123987', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_collect_customer`
--
ALTER TABLE `tbl_collect_customer`
  ADD CONSTRAINT `tbl_collect_customer_ibfk_1` FOREIGN KEY (`id_tracking`) REFERENCES `tbl_customer_tracking` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_collect_general`
--
ALTER TABLE `tbl_collect_general`
  ADD CONSTRAINT `tbl_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD CONSTRAINT `tbl_course_1` FOREIGN KEY (`idcategory`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_customer_domain`
--
ALTER TABLE `tbl_customer_domain`
  ADD CONSTRAINT `tbl_customer_domain_ibfk_1` FOREIGN KEY (`id_customer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_customer_domain_ibfk_2` FOREIGN KEY (`id_domain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_customer_tracking`
--
ALTER TABLE `tbl_customer_tracking`
  ADD CONSTRAINT `tbl_customer_tracking_ibfk_1` FOREIGN KEY (`id_customer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_customer_tracking_ibfk_2` FOREIGN KEY (`id_domain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_export`
--
ALTER TABLE `tbl_order_export`
  ADD CONSTRAINT `tbl_order_export_ibfk_1` FOREIGN KEY (`id_tracking`) REFERENCES `tbl_customer_tracking` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_export_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_export_detail`
--
ALTER TABLE `tbl_order_export_detail`
  ADD CONSTRAINT `tbl_order_export_detail_ibfk_2` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_export_detail_ibfk_1` FOREIGN KEY (`id_order`) REFERENCES `tbl_order_export` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import`
--
ALTER TABLE `tbl_order_import`
  ADD CONSTRAINT `tbl_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import_detail`
--
ALTER TABLE `tbl_order_import_detail`
  ADD CONSTRAINT `tbl_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_customer`
--
ALTER TABLE `tbl_paid_customer`
  ADD CONSTRAINT `tbl_paid_customer_ibfk_1` FOREIGN KEY (`id_tracking`) REFERENCES `tbl_customer_tracking` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_general`
--
ALTER TABLE `tbl_paid_general`
  ADD CONSTRAINT `tbl_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_paid` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_pay_roll`
--
ALTER TABLE `tbl_paid_pay_roll`
  ADD CONSTRAINT `tbl_paid_pay_roll_1` FOREIGN KEY (`idemployee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_supplier`
--
ALTER TABLE `tbl_paid_supplier`
  ADD CONSTRAINT `tbl_paid_supplier_ibfk_1` FOREIGN KEY (`id_supplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_r2t`
--
ALTER TABLE `tbl_r2t`
  ADD CONSTRAINT `tbl_r2t_ibfk_1` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_r2t_ibfk_2` FOREIGN KEY (`id_tag`) REFERENCES `tbl_tag` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD CONSTRAINT `tbl_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_supplier_domain`
--
ALTER TABLE `tbl_supplier_domain`
  ADD CONSTRAINT `tbl_supplier_domain_ibfk_1` FOREIGN KEY (`id_supplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_supplier_domain_ibfk_2` FOREIGN KEY (`id_domain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_tracking_ct`
--
ALTER TABLE `tbl_tracking_ct`
  ADD CONSTRAINT `tbl_tracking_ct_ibfk_1` FOREIGN KEY (`id_ct`) REFERENCES `tbl_customer_tracking` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
