-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 08, 2014 at 09:50 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_qlcuahang_giaydepxuatkhau`
--

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_collect_customer`
--

CREATE TABLE IF NOT EXISTS `giaydep_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_collect_general`
--

CREATE TABLE IF NOT EXISTS `giaydep_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_collect_1` (`id_term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_collect_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_config`
--

CREATE TABLE IF NOT EXISTS `giaydep_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `giaydep_config`
--

INSERT INTO `giaydep_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '1'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'GIÀY DÉP XUẤT KHẨU'),
(11, 'ADDRESS', 'Phó Cơ Điều, F3, TP Vĩnh Long'),
(12, 'PHONE', '0918 555 343'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'N_MONTH_LOG', '1'),
(17, 'PRICE1', '9000'),
(18, 'PRICE2', '8700');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_customer`
--

CREATE TABLE IF NOT EXISTS `giaydep_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  `id_domain` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_domain` (`id_domain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=260 ;

--
-- Dumping data for table `giaydep_customer`
--

INSERT INTO `giaydep_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`, `id_domain`) VALUES
(75, 'Chú Tư', 0, '', '', '', '', 0, 1),
(76, 'Chú Hai', 0, '', '', '', '', 0, 1),
(77, 'Dì Hồng', 0, '', '', '', '', 0, 1),
(78, 'Dì Thoa', 0, '', '', '', '', 0, 1),
(79, 'Dì Đẹp', 0, '', '', '', '', 0, 1),
(80, 'Chị Muối', 0, '', '', '', '', 0, 1),
(81, 'Dì Bé', 0, '', '', '', '', 0, 1),
(82, 'Dì Út', 0, '', '', '', '', 0, 1),
(83, 'Chị Mai', 0, '', '', '', '', 0, 1),
(84, 'Chị Thảo', 0, '', '', '', '', 0, 1),
(85, 'Chị Thảo Lùn', 0, '', '', '', '', 0, 1),
(86, 'Chị Thanh', 0, '', '', '', '', 0, 1),
(87, 'Chị Thủy', 0, '', '', '', '', 0, 1),
(88, 'Dì Vân', 0, '', '', '', '', 0, 1),
(89, 'Dì Hà', 0, '', '', '', '', 0, 1),
(91, 'Dì Mỹ', 0, '', '', '', '', 0, 1),
(92, 'Dì Chín', 0, '', '', '', '', 0, 1),
(93, 'Chú Hiếu', 0, '', '', '', '', 0, 1),
(94, 'Dì Bông', 0, '', '', '', '', 0, 1),
(95, 'Chị Gái', 0, '', '', '', '', 0, 1),
(96, 'Dì Út Cái Gia', 0, '', '', '', '', 0, 1),
(97, 'Dì Hoa', 0, '', '', '', '', 0, 1),
(98, 'Dì Liên', 0, '', '', '', '', 0, 1),
(100, 'Chị Cẩm', 0, '', '', '', '', 0, 1),
(103, 'Chị Hiền', 0, '', '', '', '', 0, 1),
(104, 'Chị Vân', 0, '', '', '', '', 0, 1),
(105, 'Chú Thắng', 0, '', '', '', '', 0, 2),
(106, 'Chú Tâm', 0, '', '', '', '', 0, 2),
(107, 'Dũng', 0, '', '', '', '', 0, 2),
(108, 'Chú Bảy', 0, '', '', '', '', 0, 2),
(109, 'Anh Hùng', 0, '', '', '', '', 0, 2),
(110, 'Dì Bảy Sông Dưa', 0, '', '', '', '', 0, 2),
(111, 'Dung', 0, '', '', '', '', 0, 2),
(114, 'Dì Thủy Sông Dưa', 0, '', '', '', '', 0, 2),
(115, 'Chị Hạnh', 0, '', '', '', '', 0, 2),
(116, 'Chị Ánh', 0, '', '', '', '', 0, 2),
(117, 'Dì Hợp', 0, '', '', '', '', 0, 2),
(118, 'Dì Sáu Dân', 0, '', '', '', '', 0, 2),
(119, 'Anh Hiển', 0, '', '', '', '', 0, 2),
(120, 'Anh Hiều', 0, '', '', '', '', 0, 2),
(121, 'Anh Tí', 0, '', '', '', '', 0, 2),
(122, 'Chị Phươc', 0, '', '', '', '', 0, 2),
(123, 'Chú Hiếu', 0, '', '', '', '', 0, 2),
(124, 'Anh Út Mù U', 0, '', '', '', '', 0, 2),
(125, 'Bé Hai', 0, '', '', '', '', 0, 2),
(126, 'Nguyên', 0, '', '', '', '', 0, 2),
(127, 'Chị Hoa Bến Đò Tứ Phước	', 0, '', '', '', '', 0, 2),
(128, 'Dì Sáu Lực', 0, '', '', '', '', 0, 2),
(129, 'Dì Dung', 0, '', '', '', '', 0, 2),
(130, 'Chị Thư', 0, '', '', '', '', 0, 2),
(131, 'Dì Lợi', 0, '', '', '', '', 0, 2),
(132, 'Dì Hương', 0, '', '', '', '', 0, 2),
(133, 'Dì Thoa', 0, '', '', '', '', 0, 2),
(134, 'Sĩ', 0, '', '', '', '', 0, 2),
(136, 'Chị Nu', 0, '', '', '', '', 0, 2),
(137, 'Phượng', 0, '', '', '', '', 0, 2),
(138, 'Má Phượng', 0, '', '', '', '', 0, 2),
(139, 'Dì Hiền', 0, '', '', '', '', 0, 2),
(140, 'Thúy Việt', 0, '', '', '', '', 0, 2),
(141, 'Anh Tuấn', 0, '', '', '', '', 0, 2),
(142, 'Dì Hai Bán Bông', 0, '', '', '', '', 0, 2),
(144, 'Dì Hai Tân Xuân	', 0, '', '', '', '', 0, 2),
(147, 'Dì Ba Hồng', 0, '', '', '', '', 0, 2),
(148, 'Loan Đại', 0, '', '', '', '', 0, 2),
(149, 'Chú Hai Tèo', 0, '', '', '', '', 0, 2),
(150, 'Dì Mum', 0, '', '', '', '', 0, 2),
(151, 'Dì Mận', 0, '', '', '', '', 0, 2),
(152, 'Dì Sáu Hang Mai', 0, '', '', '', '', 0, 2),
(154, 'Cúc', 0, '', '', '', '', 0, 2),
(155, 'Chị Chín Mổ', 0, '', '', '', '', 0, 2),
(156, 'Dì Thủy Đại', 0, '', '', '', '', 0, 2),
(157, 'Chị Giao', 0, '', '', '', '', 0, 2),
(158, 'Chú Lắm', 0, '', '', '', '', 0, 2),
(159, 'Dì Vân', 0, '', '', '', '', 0, 2),
(160, 'Chị Nhiều', 0, '', '', '', '', 0, 2),
(161, 'Chú Hai Đường', 0, '', '', '', '', 0, 2),
(163, 'Anh Tâm', 0, '', '', '', '', 0, 2),
(164, 'Dì Năm Cá', 0, '', '', '', '', 0, 2),
(165, 'Chị Hạnh Tân Xuân', 0, '', '', '', '', 0, 2),
(166, 'Chị Thúy Tân Xuân', 0, '', '', '', '', 0, 2),
(168, 'Lâu', 0, '', '', '', '', 0, 2),
(169, 'Chị Thu', 0, '', '', '', '', 0, 2),
(170, 'Chị Hồng Sáu Tước', 0, '', '', '', '', 0, 2),
(171, 'Chị Dung Ba Mun', 0, '', '', '', '', 0, 2),
(172, 'Chị Đào', 0, '', '', '', '', 0, 2),
(173, 'Dì Sáu Hỉ', 0, '', '', '', '', 0, 2),
(174, 'Chú Quí', 0, '', '', '', '', 0, 2),
(175, 'Chị Sương', 0, '', '', '', '', 0, 2),
(177, 'Chị Bé Ba', 0, '', '', '', '', 0, 2),
(217, 'Chi Hồ', 0, '', '', '', '', 0, 1),
(218, 'Anh Tấn', 0, '', '', '', '', 0, 1),
(219, 'Di 7', 0, '', '', '', '', 0, 1),
(220, 'Di 8', 0, '', '', '', '', 0, 1),
(221, 'Ut lun', 0, '', '', '', '', 0, 1),
(223, 'Di 3 loi', 0, '', '', '', '', 0, 1),
(224, 'Chi tien', 0, '', '', '', '', 0, 1),
(225, 'Ca rang', 0, '', '', '', '', 0, 1),
(233, 'Chu phuoc', 0, '', '', '', '', 0, 2),
(234, 'Di Chi', 0, '', '', '', '', 0, 2),
(238, 'Mai Mì', 0, '', '', '', '', 0, 2),
(244, 'Thảo', 0, '', '', '', '', 0, 2),
(245, 'Dì Mai', 0, '', '', '', '', 0, 2),
(246, 'Dì Bé', 0, '', '', '', '', 0, 2),
(247, 'Dì 10 đò', 0, '', '', '', '', 0, 2),
(248, 'Chú Út Cá', 0, '', '', '', '', 0, 2),
(249, 'Chị Liễu', 0, '', '', '', '', 0, 2),
(250, 'Chị Bé 2 Bcồn', 0, '', '', '', '', 0, 2),
(251, 'Dì 3 Bcồn', 0, '', '', '', '', 0, 2),
(252, 'Dì 5 Bcồn', 0, '', '', '', '', 0, 2),
(253, 'Chị Đào', 0, '', '', '', '', 0, 1),
(254, 'Chị Trân', 0, '', '', '', '', 0, 1),
(255, 'Chị Hồng', 0, '', '', '', '', 0, 1),
(257, 'Chị Thùy', 0, '', '', '', '', 0, 1),
(259, 'Dì Nho', 0, '', '', '', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_customer_log`
--

CREATE TABLE IF NOT EXISTS `giaydep_customer_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_customer` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `ticket1` int(11) NOT NULL,
  `ticket2` int(11) NOT NULL,
  `paid1` int(11) NOT NULL,
  `paid2` int(11) NOT NULL,
  `debt` int(11) NOT NULL,
  `paid1_remain` int(11) NOT NULL,
  `paid2_remain` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_customer` (`id_customer`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6348 ;

--
-- Dumping data for table `giaydep_customer_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_domain`
--

CREATE TABLE IF NOT EXISTS `giaydep_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `giaydep_domain`
--

INSERT INTO `giaydep_domain` (`id`, `name`) VALUES
(1, 'Khu vực 1'),
(2, 'Khu vực 2');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_employee`
--

CREATE TABLE IF NOT EXISTS `giaydep_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `giaydep_employee`
--

INSERT INTO `giaydep_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(2, 'Nhân viên', 'Bán hàng', 1, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_guest`
--

CREATE TABLE IF NOT EXISTS `giaydep_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `giaydep_guest`
--

INSERT INTO `giaydep_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_loto`
--

CREATE TABLE IF NOT EXISTS `giaydep_loto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_td` int(11) NOT NULL,
  `name` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `g81` varchar(12) NOT NULL,
  `g71` varchar(12) NOT NULL,
  `g61` varchar(12) NOT NULL,
  `g62` varchar(12) NOT NULL,
  `g63` varchar(12) NOT NULL,
  `g51` varchar(12) NOT NULL,
  `g41` varchar(12) NOT NULL,
  `g42` varchar(12) NOT NULL,
  `g43` varchar(12) NOT NULL,
  `g44` varchar(12) NOT NULL,
  `g45` varchar(12) NOT NULL,
  `g46` varchar(12) NOT NULL,
  `g47` varchar(12) NOT NULL,
  `g31` varchar(12) NOT NULL,
  `g32` varchar(12) NOT NULL,
  `g21` varchar(12) NOT NULL,
  `g11` varchar(12) NOT NULL,
  `g00` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `giaydep_loto`
--

INSERT INTO `giaydep_loto` (`id`, `id_td`, `name`, `location`, `g81`, `g71`, `g61`, `g62`, `g63`, `g51`, `g41`, `g42`, `g43`, `g44`, `g45`, `g46`, `g47`, `g31`, `g32`, `g21`, `g11`, `g00`) VALUES
(3, 190, 'TG3C', 'Tiền Giang', '18', '401', '8549', '2003', '2212', '1390', '08062', '90737', '25520', '81329', '59907', '25924', '45459', '30531', '84243', '08758', '88746', '052931'),
(4, 190, '3K3', 'Kiên Giang', '84', '430', '8484', '1017', '9529', '6394', '81456', '40093', '47342', '56318', '52763', '96262', '86820', '34256', '79377', '04123', '59940', '634872'),
(5, 190, 'ĐL3K3', 'Đà Lạt', '58', '833', '6148', '0156', '4560', '3422', '23798', '20369', '01167', '46723', '85565', '72850', '03773', '05221', '31947', '52519', '04794', '622482'),
(6, 191, '3D2', 'TP. HCM', '34', '739', '7612', '5953', '1080', '3452', '38457', '99027', '13805', '14597', '44394', '65207', '32327', '86024', '11819', '26415', '16357', '485273'),
(7, 191, 'N12', 'Đồng Tháp', '39', '557', '0562', '3453', '4490', '1905', '74225', '81509', '97474', '69239', '82634', '61789', '68710', '27750', '95637', '66937', '33304', '697488'),
(8, 191, 'T03K3', 'Cà Mau', '46', '523', '4168', '0346', '3043', '5506', '22499', '94697', '91741', '14811', '15240', '82685', '72166', '76558', '54505', '79781', '65700', '059171'),
(9, 192, 'K11T03', 'Bến Tre', '19', '457', '3806', '7097', '0889', '4771', '32549', '49667', '23036', '43390', '94070', '76875', '34489', '54188', '52400', '46458', '07259', '040178'),
(10, 192, '3C', 'Vũng Tàu', '49', '276', '7606', '8370', '5914', '6432', '46201', '32298', '20101', '58819', '35929', '98592', '26033', '51962', '48954', '71421', '57916', '572462'),
(11, 192, 'T03K3', 'Bạc Liêu', '50', '218', '5133', '1930', '2649', '0998', '21118', '00767', '81242', '01174', '78225', '98050', '74991', '67366', '98610', '85020', '45810', '587729');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_import`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=369 ;

--
-- Dumping data for table `giaydep_order_import`
--

INSERT INTO `giaydep_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(366, 10, '2014-08-09', ''),
(367, 8, '2014-08-08', ''),
(368, 9, '2014-08-08', '');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `count1` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_order_import_detail_1` (`idorder`),
  KEY `giaydep_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=663 ;

--
-- Dumping data for table `giaydep_order_import_detail`
--

INSERT INTO `giaydep_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `count1`, `price`) VALUES
(658, 366, 21, 200, 100, 250000),
(659, 367, 19, 100, 2, 35000),
(660, 368, 20, 150, 0, 350000),
(661, 366, 22, 100, 0, 235000),
(662, 367, 23, 10, 0, 50000);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_customer`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_employee`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_employee`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_general`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_paid_1` (`id_term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_supplier`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_resource`
--

CREATE TABLE IF NOT EXISTS `giaydep_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `giaydep_resource`
--

INSERT INTO `giaydep_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(19, 8, 'Giày Trẻ Em 001', 'Đôi', 38000, ''),
(20, 9, 'Giày Thời Trang 001', 'Đôi', 340000, 'Giày thời trang 001'),
(21, 10, 'Giày Thể Thao 001', 'Đôi', 250000, 'Giày Thể Thao 001'),
(22, 10, 'Giày Thể Thao 002', 'Đôi', 235000, 'Giày Thể Thao 001'),
(23, 8, 'Giày Trẻ Em 002', 'Đôi', 50000, ''),
(24, 8, 'Giày Trẻ Em 003', 'Đôi', 65000, '');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_supplier`
--

CREATE TABLE IF NOT EXISTS `giaydep_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `giaydep_supplier`
--

INSERT INTO `giaydep_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(8, 'Giày Trẻ Em', '111111111', 'P4 Vĩnh Long', '', 0),
(9, 'Giày Thời Trang', '222222222', 'Vĩnh Long', '', 0),
(10, 'Giày Thể Thao', '333333333', 'Vĩnh Long', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_term`
--

CREATE TABLE IF NOT EXISTS `giaydep_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `giaydep_term`
--

INSERT INTO `giaydep_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_term_collect`
--

CREATE TABLE IF NOT EXISTS `giaydep_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `giaydep_term_collect`
--

INSERT INTO `giaydep_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `giaydep_tracking`
--

INSERT INTO `giaydep_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(18, '2014-08-01', '2014-08-31', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `ticket_import` bigint(20) NOT NULL,
  `ticket_import_back` bigint(20) NOT NULL,
  `ticket_selling` bigint(20) NOT NULL,
  `ticket_selling_back` bigint(20) NOT NULL,
  `ticket_selling_value` bigint(20) NOT NULL,
  `value_import` bigint(20) NOT NULL,
  `value_import_back` bigint(20) NOT NULL,
  `paid_ticket` bigint(20) NOT NULL,
  `paid_debt` bigint(20) NOT NULL,
  `debt` bigint(20) NOT NULL,
  `paid_ticket_remain` bigint(20) NOT NULL,
  `paid_debt_remain` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=266 ;

--
-- Dumping data for table `giaydep_tracking_daily`
--

INSERT INTO `giaydep_tracking_daily` (`id`, `id_tracking`, `date`, `ticket_import`, `ticket_import_back`, `ticket_selling`, `ticket_selling_back`, `ticket_selling_value`, `value_import`, `value_import_back`, `paid_ticket`, `paid_debt`, `debt`, `paid_ticket_remain`, `paid_debt_remain`) VALUES
(236, 18, '2014-07-01', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(237, 18, '2014-07-02', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(238, 18, '2014-07-03', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(239, 18, '2014-07-04', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(240, 18, '2014-07-05', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(241, 18, '2014-07-06', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(242, 18, '2014-07-07', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(243, 18, '2014-07-08', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(244, 18, '2014-07-09', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(245, 18, '2014-07-10', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(246, 18, '2014-07-11', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(247, 18, '2014-07-12', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(248, 18, '2014-07-13', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(249, 18, '2014-07-14', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(250, 18, '2014-07-15', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(251, 18, '2014-07-16', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(252, 18, '2014-07-17', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(253, 18, '2014-07-18', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(254, 18, '2014-07-19', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(255, 18, '2014-07-20', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(256, 18, '2014-07-21', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(257, 18, '2014-07-22', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(258, 18, '2014-07-23', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(259, 18, '2014-07-24', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(260, 18, '2014-07-25', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(261, 18, '2014-07-26', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(262, 18, '2014-07-27', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(263, 18, '2014-07-28', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(264, 18, '2014-07-29', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(265, 18, '2014-07-30', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_domain_daily`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_domain_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_domain` int(11) NOT NULL,
  `date` date NOT NULL,
  `ticket_selling` bigint(20) NOT NULL,
  `ticket_selling_back` bigint(20) NOT NULL,
  `ticket_value` bigint(20) NOT NULL,
  `debt` bigint(20) NOT NULL,
  `paid_ticket` bigint(11) NOT NULL,
  `paid_debt` bigint(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=577 ;

--
-- Dumping data for table `giaydep_tracking_domain_daily`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_supplier_daily`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_supplier_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_supplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `ticket_import` bigint(20) NOT NULL,
  `ticket_import_back` bigint(20) NOT NULL,
  `value_import` bigint(20) NOT NULL,
  `value_import_back` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=190 ;

--
-- Dumping data for table `giaydep_tracking_supplier_daily`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_user`
--

CREATE TABLE IF NOT EXISTS `giaydep_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `giaydep_user`
--

INSERT INTO `giaydep_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `giaydep_collect_customer`
--
ALTER TABLE `giaydep_collect_customer`
  ADD CONSTRAINT `giaydep_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `giaydep_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_collect_general`
--
ALTER TABLE `giaydep_collect_general`
  ADD CONSTRAINT `giaydep_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `giaydep_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_customer`
--
ALTER TABLE `giaydep_customer`
  ADD CONSTRAINT `giaydep_customer_ibfk_1` FOREIGN KEY (`id_domain`) REFERENCES `giaydep_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_customer_log`
--
ALTER TABLE `giaydep_customer_log`
  ADD CONSTRAINT `giaydep_customer_log_ibfk_1` FOREIGN KEY (`id_customer`) REFERENCES `giaydep_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_order_import`
--
ALTER TABLE `giaydep_order_import`
  ADD CONSTRAINT `giaydep_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `giaydep_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_order_import_detail`
--
ALTER TABLE `giaydep_order_import_detail`
  ADD CONSTRAINT `giaydep_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `giaydep_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `giaydep_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `giaydep_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_customer`
--
ALTER TABLE `giaydep_paid_customer`
  ADD CONSTRAINT `giaydep_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `giaydep_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_employee`
--
ALTER TABLE `giaydep_paid_employee`
  ADD CONSTRAINT `giaydep_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `giaydep_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_general`
--
ALTER TABLE `giaydep_paid_general`
  ADD CONSTRAINT `giaydep_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `giaydep_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_supplier`
--
ALTER TABLE `giaydep_paid_supplier`
  ADD CONSTRAINT `giaydep_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `giaydep_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_resource`
--
ALTER TABLE `giaydep_resource`
  ADD CONSTRAINT `giaydep_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `giaydep_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
