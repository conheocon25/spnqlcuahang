<?php
	require("mvc/base/controller/Controller.php");
	\MVC\Controller\Controller::run();	
?>