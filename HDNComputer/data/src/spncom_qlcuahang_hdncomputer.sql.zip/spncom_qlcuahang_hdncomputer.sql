-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 18, 2014 at 01:28 PM
-- Server version: 5.5.33-31.1
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_qlcuahang_hdncomputer`
--

-- --------------------------------------------------------

--
-- Table structure for table `shopc_category`
--

CREATE TABLE IF NOT EXISTS `shopc_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `shopc_category`
--

INSERT INTO `shopc_category` (`id`, `name`, `key`, `order`) VALUES
(1, 'Linh kiện và Phụ kiện', 'linh-kien-va-phu-kien', 1),
(14, 'Dịch vụ', 'dich-vu', 3),
(15, 'Camera quan sát', 'camera-quan-sat', 0),
(16, 'Dịch vụ Mạng', 'dich-vu-mang', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_category1`
--

CREATE TABLE IF NOT EXISTS `shopc_category1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_category` (`id_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `shopc_category1`
--

INSERT INTO `shopc_category1` (`id`, `id_category`, `name`, `key`, `order`) VALUES
(12, 1, 'Linh kiện', 'linh-kien', 0),
(13, 1, 'Phụ kiện', 'phu-kien', 0),
(14, 14, 'Bảo dưỡng máy tính', 'bao-duong-may-tinh', 0),
(15, 14, 'Sửa chữa, bảo trì máy tính', 'sua-chua-bao-tri-may-tinh', 0),
(18, 15, 'Lắp đặt Camera', 'lap-dat-camera', 0),
(19, 16, 'Tư vấn lắp đặt internet', 'tu-van-lap-dat-internet', 0),
(20, 16, 'Lắp đặt hệ thống mạng LAN', 'lap-dat-he-thong-mang-lan', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_config`
--

CREATE TABLE IF NOT EXISTS `shopc_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=35 ;

--
-- Dumping data for table `shopc_config`
--

INSERT INTO `shopc_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '50'),
(7, 'GUEST_VISIT', '717'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'HDN COMPUTER'),
(11, 'ADDRESS', '399D/31 Ấp Phước Yên A, Phú Quới, Long Hồ, Vĩnh Long'),
(12, 'PHONE', '094 490 6467'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'POST_POLICY', '5'),
(19, 'EVERY_5_MINUTES', '2000'),
(22, 'SLOGAN', 'Uy Tin - Chất Lượng - Nhiệt Tình'),
(23, 'POST_INTRODUCTION', '6'),
(24, 'POST_FAQ', '4'),
(28, 'POST_POLICY', '5'),
(29, 'N_MONTH_LOG', '1'),
(30, 'PRESENTATION_HOME', '2'),
(31, 'CONTACT_NAME', 'A.Hữu'),
(32, 'CONTACT_YAHOOMESSENGER', 'abc@yahoo.com'),
(33, 'CONTACT_SKYPE', 'abc@skype.com'),
(34, 'CONTACT_GTALK', 'abc@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_customer`
--

CREATE TABLE IF NOT EXISTS `shopc_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `shopc_customer`
--

INSERT INTO `shopc_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_employee`
--

CREATE TABLE IF NOT EXISTS `shopc_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `shopc_employee`
--

INSERT INTO `shopc_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(2, 'Nhân viên', 'Bán hàng', 1, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_guest`
--

CREATE TABLE IF NOT EXISTS `shopc_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=208 ;

--
-- Dumping data for table `shopc_guest`
--

INSERT INTO `shopc_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(207, '198.143.44.1', '1397843505', '1397847105', '198.143.44.1');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_image`
--

CREATE TABLE IF NOT EXISTS `shopc_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idresource` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `url` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idresource` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `shopc_image`
--

INSERT INTO `shopc_image` (`id`, `idresource`, `name`, `date`, `url`) VALUES
(16, 32, 'Bộ vệ sinh', '2014-04-14 00:00:00', 'https://lh3.googleusercontent.com/-4XCX5BrLesw/U0tbhLH7CoI/AAAAAAAAAds/cyFE32P4kPc/s800/bo%2520ve%2520sinh%2520laptop.png'),
(17, 33, 'mitsumi lớn', '2014-04-14 00:00:00', 'https://lh6.googleusercontent.com/-4bpospcUCps/U0tbgjgAILI/AAAAAAAAAdg/kWwED0JW-9k/s800/chuot%2520mitsumi%2520lon.png'),
(18, 33, 'mitsumi lớn', '2014-04-14 00:00:00', 'https://lh6.googleusercontent.com/-4bpospcUCps/U0tbgjgAILI/AAAAAAAAAdg/kWwED0JW-9k/s800/chuot%2520mitsumi%2520lon.png'),
(19, 34, 'Philips', '2014-04-14 00:00:00', 'https://lh6.googleusercontent.com/-LVK1r_gLpJI/U0tbhHtSBeI/AAAAAAAAAd0/U2rwNJX34wU/s800/chuot%2520philips.png'),
(20, 35, 'đầu đọc thẻ', '2014-04-14 00:00:00', 'https://lh5.googleusercontent.com/-z8NOrEaqQno/U0tbhfS822I/AAAAAAAAAd4/HXUi91c3v7w/s800/dau%2520doc%2520the.png'),
(21, 36, 'dây mạng thường', '2014-04-15 00:00:00', 'https://lh3.googleusercontent.com/-KIyLyxjaUPc/U0tbia6azrI/AAAAAAAAAeA/t5x8_9E3w54/s800/day%2520mang%2520thuong.png'),
(22, 37, 'dây mạng tốt', '2014-04-15 00:00:00', 'https://lh4.googleusercontent.com/-18HY5btoTnk/U0tbjv-OHDI/AAAAAAAAAeI/ZQHiI6r5UxM/s800/day%2520mang%2520tot.png'),
(23, 38, 'đế tản nhiệt xếp 2 quạt', '2014-04-15 00:00:00', 'https://lh3.googleusercontent.com/-OIUdmS0Ixrg/U0tbkb9KAQI/AAAAAAAAAec/2qoa7RXai7U/s800/de%2520tan%2520nhiet%2520dang%2520xep.png'),
(24, 39, 'đế tản nhiệt loại tốt', '2014-04-15 00:00:00', 'https://lh6.googleusercontent.com/-FbTNp-2usbM/U0tbkYn5vXI/AAAAAAAAAeY/JhsnSgM5sSs/s800/de%2520tan%2520nhiet%2520loai%2520tot.png'),
(25, 41, 'đế tản nhiệt xếp hình bướm', '2014-04-15 00:00:00', 'https://lh4.googleusercontent.com/-uV3au_Dp-ic/U0tblQOH0rI/AAAAAAAAAew/d2Wf8yZ56rQ/s800/de%2520tan%2520nhiet%2520xep.png'),
(26, 42, 'đèn led laptop', '2014-04-15 00:00:00', 'https://lh6.googleusercontent.com/-rROZQmpitMo/U0tblTUZJYI/AAAAAAAAAe0/Acg6XpjlZUE/s800/den%2520led%2520laptop.png'),
(27, 43, 'headphone somic', '2014-04-15 00:00:00', 'https://lh4.googleusercontent.com/-Zj4MnbxiLVA/U0tbl_sRuVI/AAAAAAAAAe4/NthvZzgY5hs/s800/headphone.png'),
(28, 44, 'keo giải nhiệt CPU', '2014-04-15 00:00:00', 'https://lh3.googleusercontent.com/-ynBS9ha_LXQ/U0tbmcsKQDI/AAAAAAAAAfE/FvJxULaa-gU/s800/keo%2520giai%2520nhiet%2520dang%2520hu.png'),
(29, 45, 'Loa 2.0', '2014-04-15 00:00:00', 'https://lh6.googleusercontent.com/-aR0_lhLN5uI/U0tbnOK6fLI/AAAAAAAAAfQ/Yj245UWiNTk/s800/loa%252020.png'),
(30, 46, 'Loa 2.1 soundmax', '2014-04-15 00:00:00', 'https://lh3.googleusercontent.com/-T3u7NpMU3wY/U0tbnoQRSxI/AAAAAAAAAfc/JkZ4YGcp634/s800/loa%252021.png'),
(31, 48, 'phím mitsumi', '2014-04-15 00:00:00', 'https://lh6.googleusercontent.com/-45qZ6GflOSg/U0tboaT1UMI/AAAAAAAAAfo/0jJL4WQ1Eh8/s800/phim.png'),
(32, 49, 'Ram DDR2 2GB PC', '2014-04-15 00:00:00', 'https://lh6.googleusercontent.com/-5ecOO2uHr8Q/U0tbpfiJj7I/AAAAAAAAAf0/YA8ielCVaEA/s800/ram%2520may%2520ban.png'),
(33, 50, 'Tai nghe jack 3.5', '2014-04-15 00:00:00', 'https://lh4.googleusercontent.com/-B4kFauLveQw/U0tbpoKCR4I/AAAAAAAAAf8/C4DLCweZ6pY/s800/tai%2520nghe.png'),
(34, 51, 'MousePad', '2014-04-15 00:00:00', 'https://lh4.googleusercontent.com/-iMjds65aKJk/U0tbp2v5-HI/AAAAAAAAAgA/7aBULUlnNmw/s800/tam%2520lot%2520chuot.png'),
(35, 52, 'tấm bảo vệ phím', '2014-04-15 00:00:00', 'https://lh3.googleusercontent.com/-CN-r7kWyVZk/U0tbrlDZ1bI/AAAAAAAAAgM/2j0Uy8y1rnE/s800/tam%2520lot%2520phim.png'),
(36, 40, 'đế tản nhiệt thường', '2014-04-15 00:00:00', 'https://lh6.googleusercontent.com/-wnmmggaN8HM/U0tbkp4g2-I/AAAAAAAAAeg/l8T9ebWG4U0/s800/de%2520tan%2520nhiet%2520thuong.png'),
(37, 53, 'switch tenda 5port', '2014-04-16 00:00:00', 'https://lh5.googleusercontent.com/-eRgjZP46I0c/U0tbr1KeekI/AAAAAAAAAgQ/9Rr5gLx5mA8/s800/tenda%25205port.png'),
(38, 54, 'tp-link 8 port', '2014-04-16 00:00:00', 'https://lh6.googleusercontent.com/-2iQFIojyO00/U0tbr_or8jI/AAAAAAAAAgY/HJCSAqIm1RQ/s800/tp-link%25208port.png'),
(39, 55, 'usb 2gb', '2014-04-16 00:00:00', 'https://lh3.googleusercontent.com/-VMBInYpEL7U/U0tbvy8AauI/AAAAAAAAAg0/mJ6T-69eeHE/s800/usb%25202gb.png'),
(40, 47, 'loa 4.1', '2014-04-16 00:00:00', 'https://lh3.googleusercontent.com/-q9zw862QTNk/U0tbn1ywaOI/AAAAAAAAAfg/QByyvtF52hY/s800/loa%252041.png'),
(41, 56, 'main jeway g31', '2014-04-16 00:00:00', 'https://lh4.googleusercontent.com/-9mFzaH9ju8o/U05RBE4NOcI/AAAAAAAAAhY/avi-Nu-CxPM/s800/main%2520jeway%2520g31.png'),
(42, 57, 'camera', '2014-04-18 00:00:00', 'https://lh3.googleusercontent.com/-Ha1LAiFyrlA/U0_ZGGwz4oI/AAAAAAAAAh4/IEFefanNpVg/s800/mo%2520hinh%2520tham%2520khao%2520camera.png');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_order_export`
--

CREATE TABLE IF NOT EXISTS `shopc_order_export` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `shopc_order_export`
--

INSERT INTO `shopc_order_export` (`id`, `idcustomer`, `date`, `note`) VALUES
(5, 1, '2014-04-15 14:11:34', 'Thêm thử'),
(6, 1, '2014-04-15 11:04:00', 'hóa đon bán lẻ'),
(7, 1, '2014-04-16 04:04:00', 'hóa đon bán lẻ'),
(8, 1, '2014-04-16 04:04:00', 'hóa đon bán lẻ'),
(9, 1, '2014-04-16 04:04:00', 'hóa đon bán lẻ');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_order_export_detail`
--

CREATE TABLE IF NOT EXISTS `shopc_order_export_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idorder` (`idorder`),
  KEY `idresource` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `shopc_order_export_detail`
--

INSERT INTO `shopc_order_export_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(14, 5, 37, 5, 7000),
(15, 5, 40, 1, 60000),
(16, 5, 49, 1, 390000),
(17, 5, 33, 6, 50000),
(18, 5, 35, 1, 15000),
(19, 5, 34, 3, 45000),
(20, 7, 32, 1, 15000),
(21, 7, 34, 1, 45000),
(22, 7, 49, 1, 390000);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_order_import`
--

CREATE TABLE IF NOT EXISTS `shopc_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopc_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=364 ;

--
-- Dumping data for table `shopc_order_import`
--

INSERT INTO `shopc_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(363, 9, '2014-04-08', '');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `shopc_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopc_order_import_detail_1` (`idorder`),
  KEY `shopc_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=665 ;

-- --------------------------------------------------------

--
-- Table structure for table `shopc_post`
--

CREATE TABLE IF NOT EXISTS `shopc_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `shopc_post`
--

INSERT INTO `shopc_post` (`id`, `title`, `content`, `author`, `time`, `count`, `key`) VALUES
(4, 'FAQ', '<p>\r\n	C&aacute;c c&acirc;u hỏi thường gặp được viết chi tiết ở đ&acirc;y.1</p>\r\n', '1', '0000-00-00 00:00:00', 1, 'faq-1397591102'),
(5, 'Chính sách', '<h3 style="text-align: justify;">\r\n	Ch&iacute;nh s&aacute;ch đổi trả h&agrave;ng v&agrave; ho&agrave;n tiền tại l&agrave; như thế n&agrave;o?</h3>\r\n<div style="text-align: justify;">\r\n	Khi mua sắm với Shop, qu&yacute; kh&aacute;ch c&oacute; thể đổi trả h&agrave;ng h&oacute;a trong v&ograve;ng 30 ng&agrave;y kể từ ng&agrave;y nhận h&agrave;ng, qu&yacute; kh&aacute;ch vui l&ograve;ng tham khảo th&ocirc;ng tin chi tiết về ch&iacute;nh s&aacute;ch đổi trả h&agrave;ng h&oacute;a của tại:...</div>\r\n<div style="text-align: justify;">\r\n	<h3>\r\n		Quy định đổi trả h&agrave;ng của Shop l&agrave; g&igrave;?</h3>\r\n	<div>\r\n		Qu&yacute; kh&aacute;ch c&oacute; thể đổi trả sản phẩm trong v&ograve;ng 30 ng&agrave;y kể từ ng&agrave;y nhận được đơn h&agrave;ng:</div>\r\n	<ul>\r\n		<li>\r\n			Đối với sản phẩm bị lỗi sản xuất hoặc giao sai quy c&aacute;ch: Shop sẽ gửi sản phẩm mới, ho&agrave;n tiền v&agrave;o t&agrave;i khoản của qu&yacute; kh&aacute;ch hoặc ho&agrave;n m&atilde; tiền điện tử.</li>\r\n		<li>\r\n			Đối với những sản phẩm kh&ocirc;ng phải lỗi của nh&agrave; sản xuất mà do sản ph&acirc;̉m chưa phù hợp nhu c&acirc;̀u sử dụng của quý khách: Shop sẽ chỉ ho&agrave;n bằng m&atilde; tiền điện tử.</li>\r\n		<li>\r\n			Đối với những sản phẩm bị lỗi sau 30 ng&agrave;y kể từ ng&agrave;y nhận h&agrave;ng, qu&yacute; kh&aacute;ch vui l&ograve;ng li&ecirc;n hệ trực tiếp trung t&acirc;m bảo h&agrave;nh ch&iacute;nh h&atilde;ng của sản phẩm để được hỗ trợ ngay lập tức.</li>\r\n	</ul>\r\n	<div>\r\n		Lưu &yacute;: Th&ocirc;ng tin về quy định đổi trả qu&yacute; kh&aacute;ch c&oacute; thể tham khảo tại: ...</div>\r\n</div>\r\n<h3>\r\n	T&ocirc;i c&oacute; thể đổi trả sản phẩm sau 30 ng&agrave;y kể từ ng&agrave;y nhận h&agrave;ng kh&ocirc;ng?</h3>\r\n<div style="text-align: justify;">\r\n	Rất tiếc, trong trường hợp n&agrave;y, sản phẩm chỉ được hỗ trợ bảo h&agrave;nh. Ch&uacute;ng t&ocirc;i khuyến kh&iacute;ch qu&yacute; kh&aacute;ch li&ecirc;n hệ trực tiếp nh&agrave; sản xuất hoặc trung t&acirc;m bảo h&agrave;nh ch&iacute;nh h&atilde;ng để được hỗ trợ nhanh ch&oacute;ng.</div>\r\n<div style="text-align: justify;">\r\n	<h3>\r\n		Nếu t&ocirc;i cảm thấy sản phẩm đ&atilde; mua kh&ocirc;ng ph&ugrave; hợp nhu cầu sử dụng, liệu t&ocirc;i c&oacute; thể đổi sang sản phẩm kh&aacute;c kh&ocirc;ng?</h3>\r\n	<div>\r\n		Qu&yacute; kh&aacute;ch c&oacute; thể đổi trả sản phẩm trong v&ograve;ng 30 ng&agrave;y kể từ ng&agrave;y nhận h&agrave;ng v&agrave; phải đảm bảo qu&yacute; kh&aacute;ch vẫn c&ograve;n giữ h&oacute;a đơn mua h&agrave;ng, sản phẩm chưa c&oacute; dấu hiệu sử dụng, c&ograve;n nguy&ecirc;n t&igrave;nh trạng đ&oacute;ng g&oacute;i ban đầu hoặc ni&ecirc;m phong (nếu c&oacute;) v&agrave; đầy đủ phụ kiện hoặc quà tặng kèm theo (n&ecirc;́u có).</div>\r\n</div>\r\n<h3 style="text-align: justify;">\r\n	L&agrave;m thế n&agrave;o t&ocirc;i biết được sản phẩm c&oacute; bị lỗi sản phẩm hay kh&ocirc;ng trong khi kh&ocirc;ng kiểm tra n&oacute;?</h3>\r\n<div style="text-align: justify;">\r\n	Đừng qu&aacute; lo lắng về điều n&agrave;y. Nếu Lazada.vn gửi sản phẩm bị lỗi đến qu&yacute; kh&aacute;ch, ch&uacute;ng t&ocirc;i sẽ đổi sản phẩm mới cho qu&yacute; kh&aacute;ch m&agrave; kh&ocirc;ng tốn bất cứ chi ph&iacute; n&agrave;o hoặc ho&agrave;n trả lại tiền cho qu&yacute; kh&aacute;ch.</div>\r\n', '', '0000-00-00 00:00:00', 0, 'chinh-sach-1395931412'),
(6, 'Tăng bảo mật cho giao dịch online tại Việt Nam', '<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	<strong><span style="color: rgb(51, 51, 51);">Bitdefender vừa giới thiệu tại Việt Nam giải ph&aacute;p bảo mật Gravity Zone 2014, cho ph&eacute;p chủ động bảo vệ giao dịch trực tuyến, ph&ograve;ng chống thất tho&aacute;t dữ liệu, bảo vệ hệ thống m&aacute;y chủ, m&aacute;y trạm, m&ocirc;i trường ảo h&oacute;a, thiết bị di động&hellip;</span></strong></p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: center;">\r\n	<span style="color: rgb(51, 102, 255);"><strong><img alt="Thêm giải pháp bảo mật cho giao dịch online ra mắt tại Việt Nam" height="415" src="http://media.meta.com.vn/photos/image/032014/28/Bao-mat-1.jpg" style="max-width: 640px; margin: 5px;" title="Giao dịch online luôn tiềm ẩn nguy cơ mất an toàn cao." width="550" /></strong><br />\r\n	Giao dịch online lu&ocirc;n tiềm ẩn nguy cơ mất an to&agrave;n cao.</span></p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	Ng&agrave;y 27/3,&nbsp;<em>Amphonet Erm</em>&nbsp;(<em>c&ocirc;ng ty ph&acirc;n phối sản phẩm Bitdefender v&agrave; Safetica tại Việt Nam</em>) đ&atilde; giới thiệu tại thị trường H&agrave; Nội giải ph&aacute;p&nbsp;<strong>Gravity Zone 2014</strong>&nbsp;của<em>&nbsp;Bitdefender</em>&nbsp;v&agrave; giải ph&aacute;p ph&ograve;ng chống thất tho&aacute;t dữ liệu chủ động của&nbsp;<em>Safetica,</em>&nbsp;cho ph&eacute;p bảo vệ to&agrave;n diện cho hệ thống m&aacute;y chủ, m&aacute;y trạm, m&ocirc;i trường ảo h&oacute;a v&agrave; thiết bị di động.</p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	C&aacute;c giải ph&aacute;p c&oacute; khả năng gi&uacute;p doanh nghiệp theo d&otilde;i luồng di chuyển của dữ liệu, t&igrave;m ra nguy&ecirc;n nh&acirc;n mất dữ liệu, gi&uacute;p cho c&aacute;c doanh nghiệp c&oacute; phương &aacute;n ph&ograve;ng chống rủi ro hiệu quả hơn.</p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	Giải ph&aacute;p của&nbsp;<em>Bitdefender</em>&nbsp;v&agrave;&nbsp;<em>Safepay</em>&nbsp;(<em>hiện đang được sử dụng rộng r&atilde;i tại thị trường Ch&acirc;u &Acirc;u</em>) c&ograve;n mang lại phương thức bảo mật hiệu quả cho kh&aacute;ch h&agrave;ng của doanh nghiệp khi thực hiện giao dịch trực tuyến như mua v&eacute; điện tử, mua h&agrave;ng online, giao dịch tiền tệ với ng&acirc;n h&agrave;ng.</p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	Cũng theo th&ocirc;ng tin được c&aacute;c chuy&ecirc;n gia bảo mật chia sẻ tại hội thảo, nghi&ecirc;n cứu gần đ&acirc;y của h&atilde;ng bảo mật Safetica cho thấy, c&oacute; đến 78% doanh nghiệp bị thất tho&aacute;t dữ liệu do nguy&ecirc;n nh&acirc;n nội bộ, 6/10 trường hợp thất tho&aacute;t dữ liệu chỉ được ph&aacute;t hiện do t&igrave;nh cờ.</p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	C&ograve;n&nbsp;<em>Bitdefender</em>&nbsp;chỉ ra rằng, hiện nay tại Việt Nam, d&ugrave; hệ thống bảo mật th&ocirc;ng tin trong khối doanh nghiệp t&agrave;i ch&iacute;nh tốt hơn khối doanh nghiệp phi t&agrave;i ch&iacute;nh, tuy nhi&ecirc;n khả năng ứng ph&oacute; với c&aacute;c mối đe dọa mất an to&agrave;n th&ocirc;ng tin của hầu hết doanh nghiệp vẫn c&ograve;n rất hạn chế, nhiều trường hợp bị hacker đ&aacute;nh cắp dữ liệu nhưng kh&ocirc;ng truy ra được đầu mối.</p>\r\n', '', '0000-00-00 00:00:00', 0, 'tang-bao-mat-cho-giao-dich-online-tai-viet-nam-1397580025'),
(10, 'So sánh Samsung Galaxy S5 với HTC One M8', '<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	Từ đầu 2014 đến thời điểm hiện tại c&oacute; kh&aacute; nhiều mẫu smartphone cao cấp được c&aacute;c h&atilde;ng c&ocirc;ng bố, trong đ&oacute; hai model&nbsp;<strong>Samsung&nbsp;<a href="http://www.24h.com.vn/samsung-galaxy-s5-c407e2870.html" style="text-decoration: none; color: rgb(0, 0, 255);">Galaxy S5</a>&nbsp;v&agrave; HTC One M8</strong>&nbsp;được đ&aacute;nh gi&aacute; kh&aacute; cao v&agrave; đang c&oacute; sẵn cho thị trường Việt Nam. Điều đ&aacute;ng n&oacute;i l&agrave; cả hai smartphone n&agrave;y đều dựa tr&ecirc;n c&aacute;ch tiếp cận thị trường ho&agrave;n to&agrave;n kh&aacute;c nhau.</p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0);">\r\n	<img alt="So sánh Samsung Galaxy S5 với HTC One M8 - 1" class="news-image" src="http://img-hcm.24hstatic.com:8008/upload/2-2014/images/2014-04-14/1397452740-samsung-galaxy-s5-vs-htc-one-m8-01.jpg" style="border: 0px; max-width: 400px;" /></p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 255); font-style: italic; text-align: center;">\r\n	Samsung Galaxy S5 (tr&aacute;i) v&agrave; HTC One M8 (phải)</p>\r\n<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	Ngoại trừ việc phải cạnh tranh với đối thủ lớn nhất hiện nay l&agrave; Apple, th&igrave; dường như Samsung kh&ocirc;ng gặp nhiều kh&oacute; khăn khi sản phẩm của họ phải đem ra so s&aacute;nh với những đối thủ kh&aacute;c. Tuy nhi&ecirc;n, trong v&agrave;i năm trở lại đ&acirc;y một số nh&agrave; sản xuất Android đ&atilde; nổi l&ecirc;n với những sản phẩm đ&aacute;ng ch&uacute; &yacute; như HTC.</p>\r\n<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	Cả Samsung v&agrave; HTC đều c&oacute; lập luận ri&ecirc;ng của họ trong cuộc cạnh tranh n&agrave;y. V&iacute; dụ, Samsung cho rằng m&aacute;y ảnh Ultrapixel của HTC c&oacute; qu&aacute; nhiều nhược điểm, trong khi HTC tiếp tục chọc ngo&aacute;y v&agrave;o chất liệu thiết kế của Samsung.</p>\r\n<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	<strong>Thiết kế</strong></p>\r\n<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	HTC One M8 được ca ngợi kh&aacute; nhiều về thiết kế khi sở hữu chất liệu nh&ocirc;m cao cấp v&agrave; chiếm đến 90% m&aacute;y được l&agrave;m bằng kim loại. Tuy nhi&ecirc;n, nếu đem so s&aacute;nh One M8 với HTC One 2013 th&igrave; thiết kế n&agrave;y c&oacute; phần k&eacute;m sang trọng v&agrave; g&oacute;c cạnh so với &ldquo;tiền bối&rdquo;.</p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0);">\r\n	<img alt="So sánh Samsung Galaxy S5 với HTC One M8 - 2" class="news-image" src="http://img-hcm.24hstatic.com:8008/upload/2-2014/images/2014-04-14/1397452740-samsung-galaxy-s5-vs-htc-one-m8-02.jpg" style="border: 0px; max-width: 400px;" /></p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 255); font-style: italic; text-align: center;">\r\n	Hai phi&ecirc;n bản c&oacute; triết l&yacute; ho&agrave;n to&agrave;n kh&aacute;c nhau</p>\r\n<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	Trong khi đ&oacute;,&nbsp;<em>Galaxy S5</em>&nbsp;vẫn mang đ&uacute;ng nghĩa một mẫu điện thoại th&ocirc;ng minh Android của Samsung - với c&aacute;i nh&igrave;n quen thuộc, nhưng phi&ecirc;n bản mới đ&atilde; c&oacute; ch&uacute;t thay đổi đ&aacute;ng kể về kiểu d&aacute;ng. Cụ thể lớp vỏ nhựa b&oacute;ng lo&aacute;ng ở mặt lưng m&agrave; Galaxy S4 từng sở hữu đ&atilde; được thay thế bằng lớp vỏ giả da, mang đến một c&aacute;i nh&igrave;n ho&agrave;n to&agrave;n mới, đồng thời bảo vệ m&aacute;y tốt hơn.</p>\r\n<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	Về tổng thể, cả hai thiết bị đều c&oacute; diện mạo kh&aacute; tốt, HTC One M8 xuất hiện đầy ấn tượng với chất liệu kim loại cao cấp. Trong khi, Galaxy S5 lại mang đến sự thoải m&aacute;i, v&agrave; chứng minh được m&igrave;nh mới l&agrave; chiếc điện thoại tốt hơn như; tấm lưng giả da mang lại cảm gi&aacute;c thoải m&aacute;i khi cầm tr&ecirc;n tay, trong khi vỏ kim loại của HTC One M8 vẫn kh&aacute; chắc chắn khi cầm nắm, nhưng lại dễ trượt rơi v&agrave; kh&ocirc;ng mấy thoải m&aacute;i.</p>\r\n<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	<em><strong>Về k&iacute;ch thước</strong></em></p>\r\n<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	&nbsp;</p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0);">\r\n	<img alt="So sánh Samsung Galaxy S5 với HTC One M8 - 3" class="news-image" src="http://img-hcm.24hstatic.com:8008/upload/2-2014/images/2014-04-14/1397452740-samsung-galaxy-s5-vs-htc-one-m8-03.jpg" style="border: 0px; max-width: 400px;" /></p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 255); font-style: italic; text-align: center;">\r\n	Camera 16MP của Galaxy S5 v&agrave; camera 4 Ultrapixel của One M8 c&oacute; khả năng chụp ảnh thiếu s&aacute;ng cực tốt</p>\r\n<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	Cả hai chiếc smartphone n&agrave;y đều l&agrave; thiết bị cầm tay kh&aacute; lớn. HTC One M8 sở hữu k&iacute;ch thước 146,36 x 70,6 x 9,35 mm l&agrave;m cho n&oacute; cao hơn, nhưng hẹp hơn so với Galaxy S5 142 x 72,5 x 8,1 mm. Ngo&agrave;i ra, chiếc smartphone Galaxy S5 c&ograve;n tỏ ra c&oacute; lợi thế về ngoại h&igrave;nh khi m&aacute;y mỏng hơn so với đối thủ. Trong khi trọng lượng cũng c&oacute; một ch&uacute;t ch&ecirc;nh lệch 145 g d&agrave;nh cho Galaxy S5 v&agrave; 160 g của&nbsp;<u>HTC One M8</u>&nbsp;(do chất liệu m&aacute;y được l&agrave;m chủ yếu bằng kim loại).</p>\r\n<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	Một trong những lợi thế dễ d&agrave;ng nhận thấy nhất tr&ecirc;n&nbsp;<a href="http://www.24h.com.vn/samsung-galaxy-s5-c407e2870.html" style="text-decoration: none; color: rgb(0, 0, 255);">Samsung Galaxy S5</a>&nbsp;đ&oacute; ch&iacute;nh l&agrave; ti&ecirc;u chuẩn IP67. Đ&acirc;y l&agrave; ti&ecirc;u chuẩn chống bụi ho&agrave;n to&agrave;n, chống nước ở độ s&acirc;u 1m v&agrave; trong khoảng thời gian 30 ph&uacute;t. Trong khi One M8 chỉ hỗ trợ ti&ecirc;u chuẩn IP x3, kh&ocirc;ng c&oacute; khả năng chống bụi, v&agrave; chỉ c&oacute; thể chịu nước dưới điều kiện mưa nhỏ.</p>\r\n<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	<em><strong>Mức gi&aacute;</strong></em></p>\r\n<p style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); text-align: justify;">\r\n	Một trong những t&iacute;nh năng được người d&ugrave;ng đặc biệt quan t&acirc;m ch&iacute;nh l&agrave; mức gi&aacute; của cả hai sản phẩm. HTC One M8 b&aacute;n tại thị trường Việt Nam c&oacute; gi&aacute; b&aacute;n 16,790.000 VND triệu đồng v&agrave; bắt đầu nhận đặt h&agrave;ng trước từ 21/4 đến 4/5/2014. Mức gi&aacute; của Samsung Galaxy S5 l&agrave; 15,990,000 VND.</p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0);">\r\n	<img alt="So sánh Samsung Galaxy S5 với HTC One M8 - 4" class="news-image" src="http://img-hcm.24hstatic.com:8008/upload/2-2014/images/2014-04-14/1397452740-samsung-galaxy-s5-vs-htc-one-m8-04.jpg" style="border: 0px; max-width: 400px;" /></p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 255); font-style: italic; text-align: center;">\r\n	Mặt trước của cả hai phi&ecirc;n bản đều rất sang trọng</p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0);">\r\n	<img alt="So sánh Samsung Galaxy S5 với HTC One M8 - 5" class="news-image" src="http://img-hcm.24hstatic.com:8008/upload/2-2014/images/2014-04-14/1397452740-samsung-galaxy-s5-vs-htc-one-m8-05.jpg" style="border: 0px; max-width: 400px;" /></p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 255); font-style: italic; text-align: center;">\r\n	Galaxy S5 sử dụng ph&iacute;m Home vật l&yacute;, c&ograve;n HTC One M8 d&ugrave;ng ph&iacute;m cảm ứng</p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0);">\r\n	<img alt="So sánh Samsung Galaxy S5 với HTC One M8 - 6" class="news-image" src="http://img-hcm.24hstatic.com:8008/upload/2-2014/images/2014-04-14/1397452740-samsung-galaxy-s5-vs-htc-one-m8-06.jpg" style="border: 0px; max-width: 400px;" /></p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 255); font-style: italic; text-align: center;">\r\n	Chất liệu kim loại được thể hiện tr&ecirc;n cạnh m&aacute;y v&agrave; c&aacute;c phim bấm</p>\r\n<p align="center" style="font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0);">\r\n	<img alt="So sánh Samsung Galaxy S5 với HTC One M8 - 7" class="news-image" src="http://img-hcm.24hstatic.com:8008/upload/2-2014/images/2014-04-14/1397452740-samsung-galaxy-s5-vs-htc-one-m8-07.jpg" style="border: 0px; max-width: 400px;" /></p>\r\n', '', '0000-00-00 00:00:00', 0, 'so-sanh-samsung-galaxy-s5-voi-htc-one-m8-1397580235'),
(14, 'Đấu loại vòng 2: Thêm nhiều ngân hàng biến mất', '<div style="padding: 0px; margin: 0px; line-height: 18px; font-size: 8pt; font-family: Verdana; color: rgb(0, 0, 128); text-align: center;">\r\n	<strong style="padding: 0px; margin: 0px;">Sau giai đoạn một với 9 ng&acirc;n h&agrave;ng yếu k&eacute;m đ&atilde; cơ bản ho&agrave;n tất, việc t&aacute;i cơ cấu ng&acirc;n h&agrave;ng tiếp tục được đẩy mạnh. Th&ocirc;ng tin từ NHNN cho biết sẽ c&oacute; 6 -7 NH nữa s&aacute;p nhập, hợp nhất.</strong></div>\r\n<p>\r\n	<strong style="padding: 0px; margin: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">Qua hai đợt t&aacute;i cơ cấu sẽ c&oacute; khoảng 15 ng&acirc;n h&agrave;ng bị loại khỏi hệ thống. K&eacute;o theo đ&oacute;, chắc chắn sẽ c&oacute; những thay đổi lớn về vị thế của c&aacute;c đại gia NH.</strong></p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	&nbsp;</p>\r\n<div style="padding: 0px; margin: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	&nbsp;</div>\r\n<p>\r\n	<strong style="padding: 0px; margin: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">C&aacute;c &acirc;m mưu mới</strong></p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Thị trường t&agrave;i ch&iacute;nh Việt Nam một th&aacute;ng gần đ&acirc;y lại nổi s&oacute;ng với h&agrave;ng loạt c&aacute;c th&ocirc;ng tin li&ecirc;n quan tới việc mua b&aacute;n s&aacute;p nhập NH được giữ k&iacute;n đồng loạt c&ocirc;ng bố.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Th&ocirc;ng tin&nbsp;<span class="xte5mrk0f8" id="xte5mrk0f8_1" style="padding: 0px; margin: 0px;">Southern Bank</span>&nbsp;bất ngờ c&oacute; kế hoạch s&aacute;p nhập v&agrave;o Sacombank thay v&igrave; Eximbank s&aacute;p nhập với Sacombank như đ&atilde; từng xới l&ecirc;n trước đ&oacute;, chưa kịp lắng xuống th&igrave; giới đầu tư đ&oacute;n nhận th&ecirc;m th&ocirc;ng tin 3 thương vụ nữa c&oacute; thể diễn ra.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Đầu tuần trước, th&ocirc;ng tin&nbsp;<span class="xte5mrk0f8" id="xte5mrk0f8_3" style="padding: 0px; margin: 0px;">Maritime</span>&nbsp;<span class="xte5mrk0f8" id="xte5mrk0f8_2" style="padding: 0px; margin: 0px;">Bank</span>&nbsp;sẽ tr&igrave;nh cổ đ&ocirc;ng th&ocirc;ng qua s&aacute;p nhập một tổ chức t&iacute;n dụng. Th&ocirc;ng tin chưa c&ocirc;ng bố ch&iacute;nh thức nhưng h&eacute; lộ ban đầu cho biết đ&oacute; l&agrave; Ng&acirc;n h&agrave;ng Ph&aacute;t triển M&ecirc; K&ocirc;ng (MDBbank). Hiện Maritime Bank đang l&agrave; cổ đ&ocirc;ng lớn nhất tại MBBank với hơn 10%.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Sau đ&oacute;, th&ocirc;ng tin Vietcombank (VCB) c&oacute; thể sẽ đ&oacute;n nhận một NH kh&aacute;c về với m&igrave;nh cũng đ&atilde; lan tỏa v&agrave; g&oacute;p phần v&agrave;o l&agrave;n s&oacute;ng mới trong lĩnh vực n&agrave;y. Vietcombank sẽ xin &yacute; kiến cổ đ&ocirc;ng về vấn đề n&agrave;y trong đại hội v&agrave;o ng&agrave;y 23/4 tới. Danh t&iacute;nh của &ldquo;đối t&aacute;c&rdquo; cũng chưa được tiết lộ.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Ng&acirc;n h&agrave;ng Xăng dầu Petrolimex (PGBank) nhiều khả năng sẽ &ldquo;về với&rdquo; VietinBank với khoảng 99% cổ phiếu PGBank sẽ được ho&aacute;n đổi sang VietinBank.</p>\r\n<table align="center" cellpadding="0" cellspacing="0" class="image center" style="padding: 0px; margin: 0px; text-align: center; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px;" width="400">\r\n	<tbody style="padding: 0px; margin: 0px;">\r\n		<tr style="padding: 0px; margin: 0px;">\r\n			<td style="padding: 0px; margin: 0px;">\r\n				<img alt="M&amp;A, Eximbank, Sacombank, Southern-Bank, Habubank, SHB, Vietcombank, VietinBank, DaiABank, HBBank, ngân-hàng, yếu-kém, sáp-nhập, thâu-tóm, mua-bán, nợ-xấu, nhà-đầu-tư, chiến-lược" src="http://ttol.vietnamnetjsc.vn//2014/04/15/07/56/dau-loai-vong-2-them-nhieu-ngan-hang-bien-mat_1.jpg" style="padding: 0px; margin: 0px auto; max-width: 450px;" title="M&amp;A, Eximbank, Sacombank, Southern-Bank, Habubank, SHB, Vietcombank, VietinBank, DaiABank, HBBank, ngân-hàng, yếu-kém, sáp-nhập, thâu-tóm, mua-bán, nợ-xấu, nhà-đầu-tư, chiến-lược" /></td>\r\n		</tr>\r\n		<tr style="padding: 0px; margin: 0px;">\r\n			<td align="center" class="image_desc" style="padding: 0px; margin: 0px;">\r\n				<div style="padding: 0px; margin: 0px; font-size: 8pt; font-family: Verdana; color: rgb(0, 0, 128);">\r\n					C&oacute; nhiều ng&acirc;n h&agrave;ng sẽ s&aacute;p nhập với nhau</div>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Ng&acirc;n h&agrave;ng Qu&acirc;n đội (MBB) mới đ&acirc;y cũng cho biết sẽ tr&igrave;nh cổ đ&ocirc;ng kế hoạch tận dụng c&aacute;c cơ hội để th&acirc;u t&oacute;m, s&aacute;p nhập một NH.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Th&ocirc;ng tin về c&aacute;c vụ s&aacute;p nhập được đồng loạt tung ra trong bối cảnh c&aacute;c NH bước v&agrave;o kỳ đại hội năm 2014. Đ&acirc;y l&agrave; thời điểm để c&aacute;c đơn vị xin &yacute; kiến cổ đ&ocirc;ng cho c&aacute;c vấn đề lớn, trong đ&oacute; c&oacute; t&aacute;i cấu tr&uacute;c vốn.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	L&agrave;n s&oacute;ng s&aacute;p nhập mới đang nổi l&ecirc;n ch&iacute;nh v&ograve;ng 2 của cơn b&atilde;o mua b&aacute;n s&aacute;p nhập trong lĩnh vực NH sau một số thương vụ trong c&aacute;c năm trước v&agrave; được coi như v&ograve;ng 1 của qu&aacute; tr&igrave;nh t&aacute;i cấu tr&uacute;c như: SHB-Habubank; 3 ng&acirc;n h&agrave;ng SCB - Đệ Nhất - Việt Nam T&iacute;n Nghĩa hợp th&agrave;nh SCB; Western Bank với PVFC th&agrave;nh PVcombank (2013).</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Cho đến thời điểm n&agrave;y, th&ocirc;ng qua hoạt động của c&aacute;c HN đ&atilde; hợp nhất, s&aacute;p nhập trong đợt đầu c&oacute; thể thấy nhiều đơn vị thay đổi theo hướng ng&agrave;y c&agrave;ng t&iacute;ch cực. Những c&aacute;i t&ecirc;n SHB hay Pvcombank&hellip; l&agrave; những kết quả tốt đẹp.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Trong những ng&agrave;y cuối c&ugrave;ng năm 2013, Ng&acirc;n h&agrave;ng Đại &Aacute; (DaiA Bank) đ&atilde; chốt danh s&aacute;ch cổ đ&ocirc;ng để ho&aacute;n đổi cổ phiếu DaiABank th&agrave;nh cổ phiếu Hdbank ho&agrave;n tất thut tục của việc s&aacute;p nhập.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	<strong style="padding: 0px; margin: 0px;">Điểm mới của v&ograve;ng 2</strong></p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	C&oacute; thể thấy, trong &ldquo;v&ograve;ng 2&rdquo; lần n&agrave;y, c&aacute;c th&ocirc;ng tin ph&aacute;t ra cho thấy, đ&atilde; bắt đầu xuất hiện những c&aacute;i t&ecirc;n lớn tham gia v&agrave;o qu&aacute; tr&igrave;nh M&amp;A như Vietcombank, VietinBank v&agrave; Sacombank. Đ&acirc;y c&oacute; lẽ l&agrave; đặc điểm kh&aacute;c với v&ograve;ng trước đ&oacute; v&agrave; n&oacute; hứa hẹn gi&uacute;p thị trường c&oacute; được c&aacute;c NHTM c&oacute; quy m&ocirc; v&agrave; tr&igrave;nh độ tương đương với c&aacute;c NH trong khu vực, chứ kh&ocirc;ng chỉ c&ograve;n nhăm nhăm tới mục ti&ecirc;u giảm nợ xấu, cải thiện thanh khoản, tr&aacute;nh đổ vỡ như trước đ&oacute;.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Tr&ecirc;n thực tế, s&aacute;p nhập c&aacute;c NH lại với nhau nằm trong Đề &aacute;n &quot;Cơ cấu lại hệ thống c&aacute;c TCTD giai đoạn 2011 - 2015 đ&atilde; được Thủ tướng Ch&iacute;nh phủ ph&ecirc; duyệt đầu th&aacute;ng 3/2012. Theo đ&oacute;, mục ti&ecirc;u l&agrave; nhằm cơ cấu lại căn bản, triệt để v&agrave; to&agrave;n diện hệ thống c&aacute;c TCTD theo hướng hiện đại, hoạt động an to&agrave;n, hiệu quả vững chắc với cấu tr&uacute;c đa dạng về sở hữu, quy m&ocirc;, loại h&igrave;nh c&oacute; khả năng trạnh canh lớn hơn v&agrave; dựa tr&ecirc;n nền tảng c&ocirc;ng nghệ, quản trị NH ti&ecirc;n tiến ph&ugrave; hợp với th&ocirc;ng lệ, chuẩn mực quốc tế.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Nhiều NĐT kỳ vọng l&agrave;n s&oacute;ng M&amp;A trong lĩnh vực NH lần n&agrave;y sẽ c&oacute; nhiều biến đổi về chất. Tuy nhi&ecirc;n, kh&ocirc;ng &iacute;t người cho rằng nhiều NH vẫn đang phải đối mặt với nhiều vấn đề yếu k&eacute;m n&ecirc;n gộp lại với nhau chưa hẳn đ&atilde; mạnh l&ecirc;n m&agrave; c&oacute; khi c&ograve;n phải dắt d&iacute;u nhau vượt kh&oacute; trong một thời gian d&agrave;i.&nbsp;</p>\r\n<table align="center" cellpadding="0" cellspacing="0" class="image center" style="padding: 0px; margin: 0px; text-align: center; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px;" width="400">\r\n	<tbody style="padding: 0px; margin: 0px;">\r\n		<tr style="padding: 0px; margin: 0px;">\r\n			<td style="padding: 0px; margin: 0px;">\r\n				<img alt="M&amp;A, Eximbank, Sacombank, Southern-Bank, Habubank, SHB, Vietcombank, VietinBank, DaiABank, HBBank, ngân-hàng, yếu-kém, sáp-nhập, thâu-tóm, mua-bán, nợ-xấu, nhà-đầu-tư, chiến-lược" src="http://ttol.vietnamnetjsc.vn//2014/04/15/07/56/dau-loai-vong-2-them-nhieu-ngan-hang-bien-mat_2.jpg" style="padding: 0px; margin: 0px auto; max-width: 450px;" title="M&amp;A, Eximbank, Sacombank, Southern-Bank, Habubank, SHB, Vietcombank, VietinBank, DaiABank, HBBank, ngân-hàng, yếu-kém, sáp-nhập, thâu-tóm, mua-bán, nợ-xấu, nhà-đầu-tư, chiến-lược" /></td>\r\n		</tr>\r\n		<tr style="padding: 0px; margin: 0px;">\r\n			<td class="image_desc" style="padding: 0px; margin: 0px;">\r\n				<p style="padding: 0px; margin: 10px 0px;">\r\n					&nbsp;</p>\r\n				<div style="padding: 0px; margin: 0px; font-size: 8pt; font-family: Verdana; color: rgb(0, 0, 128);">\r\n					Nhiều NĐT kỳ vọng l&agrave;n s&oacute;ng M&amp;A trong lĩnh vực NH lần n&agrave;y sẽ c&oacute; nhiều biến đổi về chất</div>\r\n				<p style="padding: 0px; margin: 10px 0px;">\r\n					&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Hồi đầu th&aacute;ng 4/2014, Ng&acirc;n h&agrave;ng Nh&agrave; nước (NHNN), cho biết, hệ thống NH vẫn đang đối mặt với tỷ lệ nợ xấu cao, vẫn ở mức khoảng 7% v&agrave; sẽ &ldquo;xử l&yacute;&rdquo; từ 6-7 NH th&ocirc;ng qua s&aacute;p nhập. Trong những c&aacute;i t&ecirc;n bị s&aacute;p nhập vừa được c&ocirc;ng bố, vẫn c&ograve;n c&oacute; NH được đ&aacute;nh gi&aacute; yếu k&eacute;m.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	C&oacute; một điểm c&oacute; lẽ l&agrave; chung ở 2 đợt t&aacute;i cấu tr&uacute;c lần n&agrave;y l&agrave; khi một vụ s&aacute;p nhập được c&ocirc;ng bố ra b&ecirc;n ngo&agrave;i th&igrave; c&aacute;c c&ocirc;ng việc ch&iacute;nh đều đ&atilde; được chuẩn bị trước. V&agrave; sau khi được c&ocirc;ng bố, việc s&aacute;p nhập sẽ được thực hiện rất nhanh sau đ&oacute;.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Một số chuy&ecirc;n gia NH gần đ&acirc;y cho rằng, việc s&aacute;p nhập c&aacute;c NH c&agrave;ng nhanh c&agrave;ng tốt bởi hệ thống NH Việt Nam hiện qu&aacute; đ&ocirc;ng v&agrave; việc xử l&yacute; nợ xấu cũng cần phải l&agrave;m dứt điểm, kh&ocirc;ng k&eacute;o d&agrave;i. Số lượng NH c&oacute; thể giảm hơn một nửa xuống c&ograve;n khoảng 15 đơn vị v&agrave;o cuối 2017.</p>\r\n<p style="padding: 0px; margin: 10px 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">\r\n	Kế hoạch l&agrave; vậy nhưng nhiều người lo ngại liệu c&aacute;c NH được coi l&agrave; l&agrave;nh mạnh c&oacute; g&aacute;nh được c&aacute;c NH yếu với khối nợ xấu đầy tr&ecirc;n m&igrave;nh hay kh&ocirc;ng? Vốn tập trung hơn th&igrave; khả năng cho vay DN lớn l&agrave; dễ d&agrave;ng v&agrave; nếu rủi ro th&igrave; m&oacute;n nợ đối với c&aacute;c DN đ&oacute; so với quy m&ocirc; vốn lớn sẽ kh&ocirc;ng nguy hiểm hay kh&ocirc;ng?</p>\r\n<p>\r\n	<span style="color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 18px; text-align: justify;">C&oacute; thể thấy, xử l&yacute; nợ xấu l&agrave; một việc cần l&agrave;m ngay, c&aacute;i ung nhọt cần được cắt bỏ. Tuy nhi&ecirc;n, việc cắt bỏ như thế n&agrave;o v&agrave; đ&aacute;nh gi&aacute; hiệu quả của việc l&agrave;m đ&oacute; cũng quan trọng. Sự gượng &eacute;p hoặc l&agrave;m theo chỉ đạo, theo chủ trương c&oacute; thể phản t&aacute;c dụng. Sự thay đổi về vị thế của c&aacute;c &ocirc;ng chủ trong c&aacute;c NH yếu k&eacute;m c&oacute; lẽ sẽ phải diễn ra mạnh mẽ hơn</span></p>\r\n', '', '0000-00-00 00:00:00', 0, 'dau-loai-vong-2-them-nhieu-ngan-hang-bien-mat-1397580500');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_post_tag`
--

CREATE TABLE IF NOT EXISTS `shopc_post_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_post` int(11) NOT NULL,
  `id_tag` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_post` (`id_post`),
  KEY `id_tag` (`id_tag`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `shopc_post_tag`
--

INSERT INTO `shopc_post_tag` (`id`, `id_post`, `id_tag`) VALUES
(5, 6, 1),
(9, 10, 2),
(11, 14, 3);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_presentation`
--

CREATE TABLE IF NOT EXISTS `shopc_presentation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `shopc_presentation`
--

INSERT INTO `shopc_presentation` (`id`, `name`, `order`, `key`) VALUES
(2, 'Trình bày 1', 1, 0),
(3, 'Trình bày 2', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_resource`
--

CREATE TABLE IF NOT EXISTS `shopc_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `idcategory` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `price1` int(12) NOT NULL,
  `price2` int(12) NOT NULL,
  `madein` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `madeby` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `style` int(11) NOT NULL,
  `canvas` int(11) NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopc_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=58 ;

--
-- Dumping data for table `shopc_resource`
--

INSERT INTO `shopc_resource` (`id`, `idsupplier`, `idcategory`, `name`, `code`, `price1`, `price2`, `madein`, `madeby`, `type`, `style`, `canvas`, `note`, `key`) VALUES
(32, 9, 13, 'Bộ vệ sinh máy tính 4 món', '', 10000, 15000, 'Việt Nam', 0, 0, 0, 0, '', 'bo-ve-sinh-may-tinh-4-mon-1397447981'),
(33, 9, 13, 'Chuột mitsumi lớn', '', 35000, 50000, 'Việt Nam', 0, 0, 0, 0, '', 'chuot-mitsumi-lon-1397448090'),
(34, 9, 13, 'Chuột Philips', '', 28000, 45000, 'Việt Nam', 0, 0, 0, 0, '', 'chuot-philips-1397448176'),
(35, 9, 13, 'Đầu đọc thẻ', '', 10000, 15000, 'Việt Nam', 0, 0, 0, 0, '', 'dau-doc-the-1397448233'),
(36, 9, 13, 'Dây mạng thường', '', 1500, 3000, 'Trung Quốc', 0, 0, 0, 0, '', 'day-mang-thuong-1397538934'),
(37, 9, 13, 'Dây mạng tốt', '', 3500, 7000, 'Trung Quốc', 0, 0, 0, 0, '', 'day-mang-tot-1397538945'),
(38, 9, 13, 'Đế tản nhiệt xếp 2 quạt', '', 35000, 50000, 'Trung Quốc', 0, 0, 0, 0, '', 'de-tan-nhiet-xep-2-quat-1397538972'),
(39, 9, 13, 'Đế tản nhiệt loại tốt', '', 95000, 135000, 'Trung Quốc', 0, 0, 0, 0, '', 'de-tan-nhiet-loai-tot-1397538964'),
(40, 9, 13, 'Đế tản nhiệt loại thường', '', 45000, 60000, 'Trung Quốc', 0, 0, 0, 0, '', 'de-tan-nhiet-loai-thuong-1397538956'),
(41, 9, 13, 'Đế tản nhiệt xếp hình bướm', '', 45000, 60000, 'Trung Quốc', 0, 0, 0, 0, '', 'de-tan-nhiet-xep-hinh-buom-1397539241'),
(42, 9, 13, 'Đèn led laptop', '', 15000, 25000, 'Trung Quốc', 0, 0, 0, 0, '', 'den-led-laptop-1397539328'),
(43, 9, 13, 'Headphone somic', '', 30000, 45000, 'Trung Quốc', 0, 0, 0, 0, '', 'headphone-somic-1397539453'),
(44, 9, 13, 'Keo giải nhiệt CPU', '', 7000, 10000, 'Trung Quốc', 0, 0, 0, 0, '', 'keo-giai-nhiet-cpu-1397539542'),
(45, 9, 13, 'Loa 2.0  nguồn DC', '', 180000, 225000, 'Trung Quốc', 0, 0, 0, 0, '', 'loa-20-nguon-dc-1397539736'),
(46, 9, 13, 'Loa 2.1 soundmax', '', 350000, 390000, 'Việt Nam', 0, 0, 0, 0, '', 'loa-21-soundmax-1397539920'),
(47, 9, 13, 'Loa 4.1 soundmax', '', 780000, 850000, 'Việt Nam', 0, 0, 0, 0, '', 'loa-41-soundmax-1397540051'),
(48, 9, 13, 'Phim mitsumi', '', 75000, 95000, 'Trung Quốc', 0, 0, 0, 0, '', 'phim-mitsumi-1397540112'),
(49, 9, 12, 'Ram DDR2 PC 2GB', '', 360000, 390000, 'Đài Loan', 0, 0, 0, 0, '', 'ram-ddr2-pc-2gb-1397540387'),
(50, 9, 13, 'Tai nghe jack 3.5', '', 20000, 35000, 'Trung Quốc', 0, 0, 0, 0, '', 'tai-nghe-jack-35-1397540664'),
(51, 9, 13, 'MousePad ( đế lót chuột)', '', 6000, 10000, 'Trung Quốc', 0, 0, 0, 0, '', 'mousepad-de-lot-chuot-1397540872'),
(52, 9, 13, 'Tấm dán bảo vệ phím', '', 10000, 20000, 'Trung Quốc', 0, 0, 0, 0, '', 'tam-dan-bao-ve-phim-1397541067'),
(53, 9, 13, 'Switch Tenda 5 port', '', 110000, 135000, 'Trung Quốc', 0, 0, 0, 0, '', 'switch-tenda-5-port-1397640797'),
(54, 9, 13, 'Switch TP-Link 8 port', '', 150000, 180000, 'Trung Quốc', 0, 0, 0, 0, '', 'switch-tp-link-8-port-1397640890'),
(55, 9, 13, 'USB Kingtons 2GB', '', 65000, 80000, 'Việt Nam', 0, 0, 0, 0, '', 'usb-kingtons-2gb-1397641005'),
(56, 9, 12, 'Main Jeway G31', '', 1050000, 1175000, 'Đài Loan', 0, 0, 0, 0, '', 'main-jeway-g31-1397641555'),
(57, 9, 18, 'Mô hình camera', '', 0, 0, 'Đài Loan', 0, 0, 0, 0, '', 'mo-hinh-camera-1397829370');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_save`
--

CREATE TABLE IF NOT EXISTS `shopc_save` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date1` date NOT NULL,
  `date2` date NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `shopc_save`
--

INSERT INTO `shopc_save` (`id`, `name`, `date1`, `date2`, `key`) VALUES
(1, 'Khuyến mãi tháng 3', '2014-03-27', '2014-03-31', 'khuyen-mai-thang-3');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_save_resource`
--

CREATE TABLE IF NOT EXISTS `shopc_save_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsave` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsave` (`idsave`),
  KEY `idresource` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `shopc_slide`
--

CREATE TABLE IF NOT EXISTS `shopc_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idpresentation` int(11) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `shopc_slide`
--

INSERT INTO `shopc_slide` (`id`, `idpresentation`, `name`, `order`, `note`, `url`) VALUES
(1, 1, 'Hàng mới về', 1, 'Hàng mới về 2013', 'https://lh6.googleusercontent.com/-W0SWkx8AL24/Uy-irrEgv_I/AAAAAAAAA8Y/5bTIDivghLQ/s800/slider1.png'),
(2, 1, 'Bán chạy nhất', 2, 'Những hàng bán chạy nhất', 'https://lh4.googleusercontent.com/-jpsjoG4wL64/Uy-iw16t3lI/AAAAAAAAA8o/jlcuqg24ktY/s800/slider2.png'),
(3, 1, 'Bộ sưu tập mùa hè', 1, 'Bộ sưu tập mùa hè năm nay', 'https://lh6.googleusercontent.com/-yU_HBeMIY18/Uy-iu1GHBmI/AAAAAAAAA8g/efaDupRHia8/s800/slider3.png'),
(4, 2, 'Dịch vụ chăm sóc máy tính 95.000đ/năm', 1, '', 'https://lh3.googleusercontent.com/-h4rJ0wIw2zE/UwoAUGZQq4I/AAAAAAAAAYk/YbpFaulHG-8/s800/1%2520mat%2520truoc%2520BH.png'),
(5, 2, 'Quy định HDN CARE', 0, '', 'https://lh3.googleusercontent.com/-5fvugoD4H1M/UwoATp--kGI/AAAAAAAAAYg/_MMumzOPZJc/s800/3%2520mat%2520sau%2520BH.png');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_supplier`
--

CREATE TABLE IF NOT EXISTS `shopc_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `shopc_supplier`
--

INSERT INTO `shopc_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(9, 'Nhà cung cấp 1', '0919 22 44 33', 'Q4 TPHCM', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_tag`
--

CREATE TABLE IF NOT EXISTS `shopc_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) NOT NULL,
  `order` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `shopc_tag`
--

INSERT INTO `shopc_tag` (`id`, `name`, `key`, `order`, `position`) VALUES
(1, 'Tin IT', 'tin-it', 1, 1),
(2, 'Công nghệ mới', 'cong-nghe-moi', 2, 1),
(3, 'Doanh nghiệp', 'doanh-nghiep', 3, 1),
(4, 'Phần mềm', 'phan-mem', 3, 1),
(5, 'Riêng tư', 'rieng-tu', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_tracking`
--

CREATE TABLE IF NOT EXISTS `shopc_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `shopc_tracking`
--

INSERT INTO `shopc_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(17, '2014-03-01', '2014-03-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(18, '2014-04-01', '2014-04-30', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `shopc_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `ticket1` bigint(20) NOT NULL,
  `ticket2` bigint(20) NOT NULL,
  `paid1` bigint(20) NOT NULL,
  `paid2` bigint(20) NOT NULL,
  `debt` bigint(20) NOT NULL,
  `paid1_remain` bigint(11) NOT NULL,
  `paid2_remain` bigint(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=206 ;

--
-- Dumping data for table `shopc_tracking_daily`
--

INSERT INTO `shopc_tracking_daily` (`id`, `id_tracking`, `date`, `ticket1`, `ticket2`, `paid1`, `paid2`, `debt`, `paid1_remain`, `paid2_remain`) VALUES
(147, 16, '2014-02-01', 0, 0, 0, 0, 0, 0, 0),
(148, 16, '2014-02-02', 0, 0, 0, 0, 0, 0, 0),
(149, 16, '2014-02-03', 0, 0, 0, 0, 0, 0, 0),
(150, 16, '2014-02-04', 0, 0, 0, 0, 0, 0, 0),
(151, 16, '2014-02-05', 0, 0, 0, 0, 0, 0, 0),
(152, 16, '2014-02-06', 0, 0, 0, 0, 0, 0, 0),
(153, 16, '2014-02-07', 0, 0, 0, 0, 0, 0, 0),
(154, 16, '2014-02-08', 0, 0, 0, 0, 0, 0, 0),
(155, 16, '2014-02-09', 0, 0, 0, 0, 0, 0, 0),
(156, 16, '2014-02-10', 0, 0, 0, 0, 0, 0, 0),
(157, 16, '2014-02-11', 0, 0, 0, 0, 0, 0, 0),
(158, 16, '2014-02-12', 0, 0, 0, 0, 0, 0, 0),
(159, 16, '2014-02-13', 0, 0, 0, 0, 0, 0, 0),
(160, 16, '2014-02-14', 0, 0, 0, 0, 0, 0, 0),
(161, 16, '2014-02-15', 0, 0, 0, 0, 0, 0, 0),
(162, 16, '2014-02-16', 0, 0, 0, 0, 0, 0, 0),
(163, 16, '2014-02-17', 0, 0, 0, 0, 0, 0, 0),
(164, 16, '2014-02-18', 0, 0, 0, 0, 0, 0, 0),
(165, 16, '2014-02-19', 0, 0, 0, 0, 0, 0, 0),
(166, 16, '2014-02-20', 0, 0, 0, 0, 0, 0, 0),
(167, 16, '2014-02-21', 0, 0, 0, 0, 0, 0, 0),
(168, 16, '2014-02-22', 0, 0, 0, 0, 0, 0, 0),
(169, 16, '2014-02-23', 0, 0, 0, 0, 0, 0, 0),
(170, 16, '2014-02-24', 0, 0, 0, 0, 0, 0, 0),
(171, 16, '2014-02-25', 0, 0, 0, 0, 0, 0, 0),
(172, 16, '2014-02-26', 0, 0, 0, 0, 0, 0, 0),
(173, 16, '2014-02-27', 56000, 0, 0, 0, 0, 0, 0),
(174, 16, '2014-02-28', 0, 0, 0, 0, 0, 0, 0),
(175, 17, '2014-03-01', 0, 0, 0, 0, 0, 0, 0),
(176, 17, '2014-03-02', 0, 0, 0, 0, 0, 0, 0),
(177, 17, '2014-03-03', 0, 0, 0, 0, 0, 0, 0),
(178, 17, '2014-03-04', 0, 0, 0, 0, 0, 0, 0),
(179, 17, '2014-03-05', 0, 0, 0, 0, 0, 0, 0),
(180, 17, '2014-03-06', 0, 0, 0, 0, 0, 0, 0),
(181, 17, '2014-03-07', 0, 0, 0, 0, 0, 0, 0),
(182, 17, '2014-03-08', 0, 0, 0, 0, 0, 0, 0),
(183, 17, '2014-03-09', 0, 0, 0, 0, 0, 0, 0),
(184, 17, '2014-03-10', 0, 0, 0, 0, 0, 0, 0),
(185, 17, '2014-03-11', 0, 0, 0, 0, 0, 0, 0),
(186, 17, '2014-03-12', 0, 0, 0, 0, 0, 0, 0),
(187, 17, '2014-03-13', 500, 15, 3490000, 50000, 3000000, 875000, 3950000),
(188, 17, '2014-03-14', 500, 30, 3400000, 950000, 0, 1705000, 3000000),
(189, 17, '2014-03-15', 6040, 0, 2000000, 0, 0, 52360000, 0),
(190, 17, '2014-03-16', 0, 0, 0, 0, 0, 0, 0),
(191, 17, '2014-03-17', 0, 0, 0, 0, 0, 0, 0),
(192, 17, '2014-03-18', 0, 0, 0, 0, 0, 0, 0),
(193, 17, '2014-03-19', 0, 0, 0, 0, 0, 0, 0),
(194, 17, '2014-03-20', 0, 0, 0, 0, 0, 0, 0),
(195, 17, '2014-03-21', 0, 0, 0, 0, 0, 0, 0),
(196, 17, '2014-03-22', 0, 0, 0, 0, 0, 0, 0),
(197, 17, '2014-03-23', 0, 0, 0, 0, 0, 0, 0),
(198, 17, '2014-03-24', 0, 0, 0, 0, 0, 0, 0),
(199, 17, '2014-03-25', 0, 0, 0, 0, 0, 0, 0),
(200, 17, '2014-03-26', 0, 0, 0, 0, 0, 0, 0),
(201, 17, '2014-03-27', 0, 0, 0, 0, 0, 0, 0),
(202, 17, '2014-03-28', 0, 0, 0, 0, 0, 0, 0),
(203, 17, '2014-03-29', 0, 0, 0, 0, 0, 0, 0),
(204, 17, '2014-03-30', 0, 0, 0, 0, 0, 0, 0),
(205, 17, '2014-03-31', 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_user`
--

CREATE TABLE IF NOT EXISTS `shopc_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `shopc_user`
--

INSERT INTO `shopc_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `shopc_category1`
--
ALTER TABLE `shopc_category1`
  ADD CONSTRAINT `shopc_category1_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `shopc_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_image`
--
ALTER TABLE `shopc_image`
  ADD CONSTRAINT `shopc_image_ibfk_1` FOREIGN KEY (`idresource`) REFERENCES `shopc_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_order_export_detail`
--
ALTER TABLE `shopc_order_export_detail`
  ADD CONSTRAINT `shopc_order_export_detail_ibfk_2` FOREIGN KEY (`idresource`) REFERENCES `shopc_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `shopc_order_export_detail_ibfk_1` FOREIGN KEY (`idorder`) REFERENCES `shopc_order_export` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_order_import`
--
ALTER TABLE `shopc_order_import`
  ADD CONSTRAINT `shopc_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `shopc_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_order_import_detail`
--
ALTER TABLE `shopc_order_import_detail`
  ADD CONSTRAINT `shopc_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `shopc_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `shopc_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `shopc_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_post_tag`
--
ALTER TABLE `shopc_post_tag`
  ADD CONSTRAINT `shopc_post_tag_ibfk_2` FOREIGN KEY (`id_tag`) REFERENCES `shopc_tag` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `shopc_post_tag_ibfk_1` FOREIGN KEY (`id_post`) REFERENCES `shopc_post` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_resource`
--
ALTER TABLE `shopc_resource`
  ADD CONSTRAINT `shopc_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `shopc_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_save_resource`
--
ALTER TABLE `shopc_save_resource`
  ADD CONSTRAINT `shopc_save_resource_ibfk_2` FOREIGN KEY (`idresource`) REFERENCES `shopc_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `shopc_save_resource_ibfk_1` FOREIGN KEY (`idsave`) REFERENCES `shopc_save` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
