-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 12, 2014 at 11:45 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlcuahang_veso`
--

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_collect_customer`
--

CREATE TABLE IF NOT EXISTS `haokiet_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `haokiet_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `haokiet_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `haokiet_collect_general`
--

CREATE TABLE IF NOT EXISTS `haokiet_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `haokiet_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `haokiet_collect_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `haokiet_config`
--

CREATE TABLE IF NOT EXISTS `haokiet_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `haokiet_config`
--

INSERT INTO `haokiet_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '1'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'ĐẠI LÝ VÉ SỐ HÀO KIỆT'),
(11, 'ADDRESS', 'Nha Mân Châu Thành Đồng Tháp'),
(12, 'PHONE', '0918 555 343'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'N_MONTH_LOG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_customer`
--

CREATE TABLE IF NOT EXISTS `haokiet_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  `id_domain` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_domain` (`id_domain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=216 ;

--
-- Dumping data for table `haokiet_customer`
--

INSERT INTO `haokiet_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`, `id_domain`) VALUES
(14, 'Anh Đông', 0, '', '', '', '', 0, 4),
(15, 'Anh Hùng', 0, '', '', '', '', 0, 4),
(16, 'Anh Nghĩa', 0, '', '', '', '', 0, 4),
(17, 'Nghĩa', 0, '', '', '', '', 0, 4),
(18, 'Anh Cường', 0, '', '', '', '', 0, 4),
(19, 'Anh Tông', 0, '', '', '', '', 0, 4),
(20, 'Chú Bảy', 0, '', '', '', '', 0, 4),
(21, 'Dì Mước', 0, '', '', '', '', 0, 4),
(22, 'Chị Phương Đò', 0, '', '', '', '', 0, 4),
(23, 'Chị Hồng CT', 0, '', '', '', '', 0, 4),
(24, 'Chị Nương', 0, '', '', '', '', 0, 4),
(25, 'Duyên', 0, '', '', '', '', 0, 4),
(26, 'Dì Cúc', 0, '', '', '', '', 0, 4),
(27, 'dì Hai', 0, '', '', '', '', 0, 4),
(28, 'Dì Năm', 0, '', '', '', '', 0, 4),
(29, 'Chị Út', 0, '', '', '', '', 0, 4),
(30, 'Dì Mười', 0, '', '', '', '', 0, 4),
(31, 'Dì Rùa', 0, '', '', '', '', 0, 4),
(32, 'Chị Sa', 0, '', '', '', '', 0, 4),
(33, 'Dì Út Lan', 0, '', '', '', '', 0, 4),
(34, 'Dì Chín CT', 0, '', '', '', '', 0, 4),
(35, 'Chị Hồ', 0, '', '', '', '', 0, 4),
(36, 'Chị Quyên', 0, '', '', '', '', 0, 4),
(37, 'Dì Thạch', 0, '', '', '', '', 0, 4),
(38, 'Anh Lập', 0, '', '', '', '', 0, 4),
(39, 'Chú Nhơn', 0, '', '', '', '', 0, 4),
(40, 'Dì Lan', 0, '', '', '', '', 0, 4),
(41, 'Chú Hữu', 0, '', '', '', '', 0, 4),
(42, 'Tậm Địa', 0, '', '', '', '', 0, 4),
(43, 'Dì Muối', 0, '', '', '', '', 0, 4),
(44, 'Chị Xuân', 0, '', '', '', '', 0, 4),
(45, 'Lượm', 0, '', '', '', '', 0, 4),
(46, 'Chị Tiên', 0, '', '', '', '', 0, 4),
(47, 'Diì Ba Lợi', 0, '', '', '', '', 0, 4),
(48, 'Út lùn', 0, '', '', '', '', 0, 4),
(49, 'Dì Luyến', 0, '', '', '', '', 0, 4),
(50, 'Dì Bảy', 0, '', '', '', '', 0, 4),
(51, 'Dì Tám', 0, '', '', '', '', 0, 4),
(52, 'Chú Ngợi', 0, '', '', '', '', 0, 4),
(53, 'Chú Trung', 0, '', '', '', '', 0, 4),
(54, 'Nhã', 0, '', '', '', '', 0, 4),
(55, 'Thuận', 0, '', '', '', '', 0, 4),
(56, 'Bé Lan', 0, '', '', '', '', 0, 4),
(57, 'Chị Sáu', 0, '', '', '', '', 0, 4),
(58, 'Anh An', 0, '', '', '', '', 0, 4),
(59, 'Chú Tuấn', 0, '', '', '', '', 0, 4),
(60, 'Chú Gấm', 0, '', '', '', '', 0, 4),
(61, 'Ngũ', 0, '', '', '', '', 0, 4),
(62, 'Ốc Bu', 0, '', '', '', '', 0, 4),
(63, 'Chị Chín Thiện', 0, '', '', '', '', 0, 4),
(64, 'Chị Thu', 0, '', '', '', '', 0, 4),
(65, 'Giang', 0, '', '', '', '', 0, 4),
(66, 'Chú Hủ', 0, '', '', '', '', 0, 4),
(67, 'Dì Hiền', 0, '', '', '', '', 0, 4),
(68, 'Trang', 0, '', '', '', '', 0, 4),
(69, 'Anh Út Đình', 0, '', '', '', '', 0, 4),
(70, 'Chú Út', 0, '', '', '', '', 0, 4),
(71, 'Chị Gái', 0, '', '', '', '', 0, 4),
(72, 'Chị Diễm', 0, '', '', '', '', 0, 4),
(73, 'Chị Loan', 0, '', '', '', '', 0, 4),
(74, 'Anh Gấu', 0, '', '', '', '', 0, 4),
(75, 'Chú Tư', 0, '', '', '', '', 0, 1),
(76, 'Chú Hai', 0, '', '', '', '', 0, 1),
(77, 'Dì Hồng', 0, '', '', '', '', 0, 1),
(78, 'Dì Thoa', 0, '', '', '', '', 0, 1),
(79, 'Dì Đẹp', 0, '', '', '', '', 0, 1),
(80, 'Chị Muối', 0, '', '', '', '', 0, 1),
(81, 'Dì Bé', 0, '', '', '', '', 0, 1),
(82, 'Dì Út', 0, '', '', '', '', 0, 1),
(83, 'Chị Mai', 0, '', '', '', '', 0, 1),
(84, 'Chị Thảo', 0, '', '', '', '', 0, 1),
(85, 'Chị Thảo Lùn', 0, '', '', '', '', 0, 1),
(86, 'Chị Thanh', 0, '', '', '', '', 0, 1),
(87, 'Chị Thủy', 0, '', '', '', '', 0, 1),
(88, 'Dì Vân', 0, '', '', '', '', 0, 1),
(89, 'Dì Haà', 0, '', '', '', '', 0, 1),
(90, 'Dì Thủy', 0, '', '', '', '', 0, 1),
(91, 'Dì Mỹ', 0, '', '', '', '', 0, 1),
(92, 'Dì Chín', 0, '', '', '', '', 0, 1),
(93, 'Chú Hiếu', 0, '', '', '', '', 0, 1),
(94, 'Dì Bông', 0, '', '', '', '', 0, 1),
(95, 'Chị Gái', 0, '', '', '', '', 0, 1),
(96, 'Dì Út Cái Gia', 0, '', '', '', '', 0, 1),
(97, 'Dì Hoa', 0, '', '', '', '', 0, 1),
(98, 'Dì Liên', 0, '', '', '', '', 0, 1),
(99, 'Chị Hồng Cái Gia', 0, '', '', '', '', 0, 1),
(100, 'Chị Cẩm', 0, '', '', '', '', 0, 1),
(101, 'Chị Thảo', 0, '', '', '', '', 0, 1),
(102, 'Dì Năm', 0, '', '', '', '', 0, 1),
(103, 'Chị Hiền', 0, '', '', '', '', 0, 1),
(104, 'Chị Vân', 0, '', '', '', '', 0, 1),
(105, 'Chú Thắng', 0, '', '', '', '', 0, 2),
(106, 'Chú Tâm', 0, '', '', '', '', 0, 2),
(107, 'Dũng', 0, '', '', '', '', 0, 2),
(108, 'Chú Bảy', 0, '', '', '', '', 0, 2),
(109, 'Anh Hùng', 0, '', '', '', '', 0, 2),
(110, 'Dì Bảy Sông Dưa', 0, '', '', '', '', 0, 2),
(111, 'Dung', 0, '', '', '', '', 0, 2),
(112, 'Chị Thúy', 0, '', '', '', '', 0, 2),
(113, 'Lan', 0, '', '', '', '', 0, 2),
(114, 'Dì Thủy Sông Dưa', 0, '', '', '', '', 0, 2),
(115, 'Chị Hạnh', 0, '', '', '', '', 0, 2),
(116, 'Chị Ánh', 0, '', '', '', '', 0, 2),
(117, 'Dì Hợp', 0, '', '', '', '', 0, 2),
(118, 'Dì Sáu Dân', 0, '', '', '', '', 0, 2),
(119, 'Anh Hiển', 0, '', '', '', '', 0, 2),
(120, 'Anh Hiều', 0, '', '', '', '', 0, 2),
(121, 'Anh Tí', 0, '', '', '', '', 0, 2),
(122, 'Chị Phươc', 0, '', '', '', '', 0, 2),
(123, 'Chú Hiếu', 0, '', '', '', '', 0, 2),
(124, 'Anh Út Mù U', 0, '', '', '', '', 0, 2),
(125, 'Bé Hai', 0, '', '', '', '', 0, 2),
(126, 'Nguyên', 0, '', '', '', '', 0, 2),
(127, 'Chị Hoa Bến Đò Tứ Phước	', 0, '', '', '', '', 0, 2),
(128, 'Dì Sáu Lực', 0, '', '', '', '', 0, 2),
(129, 'Dì Dung', 0, '', '', '', '', 0, 2),
(130, 'Chị Thư', 0, '', '', '', '', 0, 2),
(131, 'Dì Lợi', 0, '', '', '', '', 0, 2),
(132, 'Dì Hương', 0, '', '', '', '', 0, 2),
(133, 'Dì Thoa', 0, '', '', '', '', 0, 2),
(134, 'Sĩ', 0, '', '', '', '', 0, 2),
(135, 'Chị Sương', 0, '', '', '', '', 0, 2),
(136, 'Chị Nu', 0, '', '', '', '', 0, 2),
(137, 'Phượng', 0, '', '', '', '', 0, 2),
(138, 'Má Phượng', 0, '', '', '', '', 0, 2),
(139, 'Chị Hiền', 0, '', '', '', '', 0, 2),
(140, 'Thúy Diệp', 0, '', '', '', '', 0, 2),
(141, 'Anh Tuấn', 0, '', '', '', '', 0, 2),
(142, 'Dì Hai Bán Bông', 0, '', '', '', '', 0, 2),
(143, 'Chị Thủy', 0, '', '', '', '', 0, 2),
(144, 'Dì Hai Tân Xuân	', 0, '', '', '', '', 0, 2),
(145, 'Chị Thuận', 0, '', '', '', '', 0, 2),
(146, 'Chị Đào', 0, '', '', '', '', 0, 2),
(147, 'Dì Ba Hồng', 0, '', '', '', '', 0, 2),
(148, 'Loan Đại', 0, '', '', '', '', 0, 2),
(149, 'Chú Hai Tèo', 0, '', '', '', '', 0, 2),
(150, 'Dì Mum', 0, '', '', '', '', 0, 2),
(151, 'Dì Mận', 0, '', '', '', '', 0, 2),
(152, 'Dì Sáu Hang Mai', 0, '', '', '', '', 0, 2),
(153, 'Chị Hồng', 0, '', '', '', '', 0, 2),
(154, 'Cúc', 0, '', '', '', '', 0, 2),
(155, 'Chị Chín Mổ', 0, '', '', '', '', 0, 2),
(156, 'Dì Thủy Đại', 0, '', '', '', '', 0, 2),
(157, 'Chị Giao', 0, '', '', '', '', 0, 2),
(158, 'Chú Lắm', 0, '', '', '', '', 0, 2),
(159, 'Dì Vân', 0, '', '', '', '', 0, 2),
(160, 'Chị Nhiều', 0, '', '', '', '', 0, 2),
(161, 'Chú Hai Đường', 0, '', '', '', '', 0, 2),
(162, 'Dì Hiền', 0, '', '', '', '', 0, 2),
(163, 'Anh Tâm', 0, '', '', '', '', 0, 2),
(164, 'Dì Năm Cá', 0, '', '', '', '', 0, 2),
(165, 'Chị Hạnh Tân Xuân', 0, '', '', '', '', 0, 2),
(166, 'Chị Thúy Tân Xuân', 0, '', '', '', '', 0, 2),
(167, 'Dì Chi', 0, '', '', '', '', 0, 2),
(168, 'Lâu', 0, '', '', '', '', 0, 2),
(169, 'Chị Thu', 0, '', '', '', '', 0, 2),
(170, 'Chị Hồng Sáu Tước', 0, '', '', '', '', 0, 2),
(171, 'Chị Dung Ba Mun', 0, '', '', '', '', 0, 2),
(172, 'Chị Đào', 0, '', '', '', '', 0, 2),
(173, 'Dì Sáu Hỉ', 0, '', '', '', '', 0, 2),
(174, 'Chú Quí', 0, '', '', '', '', 0, 2),
(175, 'Chị Sương', 0, '', '', '', '', 0, 2),
(176, 'Chú Hoàng', 0, '', '', '', '', 0, 2),
(177, 'Chị Bé Ba', 0, '', '', '', '', 0, 2),
(178, 'Anh Hóa', 0, '', '', '', '', 0, 3),
(179, 'Nhí', 0, '', '', '', '', 0, 3),
(180, 'Chị Ly', 0, '', '', '', '', 0, 3),
(181, 'Dì Năm', 0, '', '', '', '', 0, 3),
(182, 'Diễm', 0, '', '', '', '', 0, 3),
(183, 'Dì Bảy', 0, '', '', '', '', 0, 3),
(184, 'Dì Oanh Sàn', 0, '', '', '', '', 0, 3),
(185, 'Dì Oanh Mía', 0, '', '', '', '', 0, 3),
(186, 'Chị Bé Hai', 0, '', '', '', '', 0, 3),
(187, 'Dì Hai', 0, '', '', '', '', 0, 3),
(188, 'Chị Loan', 0, '', '', '', '', 0, 3),
(189, 'Chị Hồng Thanh Phụng', 0, '', '', '', '', 0, 3),
(190, 'Chị Diệu', 0, '', '', '', '', 0, 3),
(191, 'Giang', 0, '', '', '', '', 0, 3),
(192, 'Anh Lâm', 0, '', '', '', '', 0, 3),
(193, 'Chú Nhân', 0, '', '', '', '', 0, 3),
(194, 'Dì Hoa', 0, '', '', '', '', 0, 3),
(195, 'Chú Ba', 0, '', '', '', '', 0, 3),
(196, 'Chú Nở', 0, '', '', '', '', 0, 3),
(197, 'Chị Chín', 0, '', '', '', '', 0, 3),
(198, 'Nhi Đồng', 0, '', '', '', '', 0, 3),
(199, 'Chị Út', 0, '', '', '', '', 0, 3),
(200, 'Chú Cụ', 0, '', '', '', '', 0, 3),
(201, 'Chị Trang', 0, '', '', '', '', 0, 3),
(202, 'Chị Bé Tư', 0, '', '', '', '', 0, 3),
(203, 'Chị Lem', 0, '', '', '', '', 0, 3),
(204, 'Anh Nam', 0, '', '', '', '', 0, 3),
(205, 'Chị Phường', 0, '', '', '', '', 0, 3),
(206, 'Phương', 0, '', '', '', '', 0, 3),
(207, 'Trúc', 0, '', '', '', '', 0, 3),
(208, 'Chị Năm', 0, '', '', '', '', 0, 3),
(209, 'Thảo', 0, '', '', '', '', 0, 3),
(210, 'Dì Út Huệ', 0, '', '', '', '', 0, 3),
(211, 'Chị Diệu', 0, '', '', '', '', 0, 3),
(212, 'Dì Bê', 0, '', '', '', '', 0, 5),
(213, 'Hạnh', 0, '', '', '', '', 0, 5),
(214, 'Thái', 0, '', '', '', '', 0, 5),
(215, 'Anh Thịnh', 0, '', '', '', '', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_customer_log`
--

CREATE TABLE IF NOT EXISTS `haokiet_customer_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_customer` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `ticket1` int(11) NOT NULL,
  `ticket2` int(11) NOT NULL,
  `paid1` int(11) NOT NULL,
  `paid2` int(11) NOT NULL,
  `debt` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_customer` (`id_customer`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=203 ;

--
-- Dumping data for table `haokiet_customer_log`
--

INSERT INTO `haokiet_customer_log` (`id`, `id_customer`, `datetime`, `ticket1`, `ticket2`, `paid1`, `paid2`, `debt`) VALUES
(1, 14, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(2, 15, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(3, 16, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(4, 17, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(5, 18, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(6, 19, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(7, 20, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(8, 21, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(9, 22, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(10, 23, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(11, 24, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(12, 25, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(13, 26, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(14, 27, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(15, 28, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(16, 29, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(17, 30, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(18, 31, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(19, 32, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(20, 33, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(21, 34, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(22, 35, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(23, 36, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(24, 37, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(25, 38, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(26, 39, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(27, 40, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(28, 41, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(29, 42, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(30, 43, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(31, 44, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(32, 45, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(33, 46, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(34, 47, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(35, 48, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(36, 49, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(37, 50, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(38, 51, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(39, 52, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(40, 53, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(41, 54, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(42, 55, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(43, 56, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(44, 57, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(45, 58, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(46, 59, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(47, 60, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(48, 61, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(49, 62, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(50, 63, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(51, 64, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(52, 65, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(53, 66, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(54, 67, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(55, 68, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(56, 69, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(57, 70, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(58, 71, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(59, 72, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(60, 73, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(61, 74, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(62, 75, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(63, 76, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(64, 77, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(65, 78, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(66, 79, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(67, 80, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(68, 81, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(69, 82, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(70, 83, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(71, 84, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(72, 85, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(73, 86, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(74, 87, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(75, 88, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(76, 89, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(77, 90, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(78, 91, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(79, 92, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(80, 93, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(81, 94, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(82, 95, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(83, 96, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(84, 97, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(85, 98, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(86, 99, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(87, 100, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(88, 101, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(89, 102, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(90, 103, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(91, 104, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(92, 105, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(93, 106, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(94, 107, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(95, 108, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(96, 109, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(97, 110, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(98, 111, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(99, 112, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(100, 113, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(101, 114, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(102, 115, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(103, 116, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(104, 117, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(105, 118, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(106, 119, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(107, 120, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(108, 121, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(109, 122, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(110, 123, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(111, 124, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(112, 125, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(113, 126, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(114, 127, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(115, 128, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(116, 129, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(117, 130, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(118, 131, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(119, 132, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(120, 133, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(121, 134, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(122, 135, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(123, 136, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(124, 137, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(125, 138, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(126, 139, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(127, 140, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(128, 141, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(129, 142, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(130, 143, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(131, 144, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(132, 145, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(133, 146, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(134, 147, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(135, 148, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(136, 149, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(137, 150, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(138, 151, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(139, 152, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(140, 153, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(141, 154, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(142, 155, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(143, 156, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(144, 157, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(145, 158, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(146, 159, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(147, 160, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(148, 161, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(149, 162, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(150, 163, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(151, 164, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(152, 165, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(153, 166, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(154, 167, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(155, 168, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(156, 169, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(157, 170, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(158, 171, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(159, 172, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(160, 173, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(161, 174, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(162, 175, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(163, 176, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(164, 177, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(165, 178, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(166, 179, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(167, 180, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(168, 181, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(169, 182, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(170, 183, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(171, 184, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(172, 185, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(173, 186, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(174, 187, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(175, 188, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(176, 189, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(177, 190, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(178, 191, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(179, 192, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(180, 193, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(181, 194, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(182, 195, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(183, 196, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(184, 197, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(185, 198, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(186, 199, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(187, 200, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(188, 201, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(189, 202, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(190, 203, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(191, 204, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(192, 205, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(193, 206, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(194, 207, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(195, 208, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(196, 209, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(197, 210, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(198, 211, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(199, 212, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(200, 213, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(201, 214, '2014-03-13 00:00:00', 0, 0, 0, 0, 0),
(202, 215, '2014-03-13 00:00:00', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_domain`
--

CREATE TABLE IF NOT EXISTS `haokiet_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `haokiet_domain`
--

INSERT INTO `haokiet_domain` (`id`, `name`) VALUES
(1, 'Mỹ Thuận'),
(2, 'Nha Mân'),
(3, 'Sa Đéc'),
(4, 'Cái Tàu'),
(5, 'Vĩnh Long');

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_employee`
--

CREATE TABLE IF NOT EXISTS `haokiet_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `haokiet_employee`
--

INSERT INTO `haokiet_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(2, 'Nhân viên', 'Bán hàng', 1, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_guest`
--

CREATE TABLE IF NOT EXISTS `haokiet_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `haokiet_guest`
--

INSERT INTO `haokiet_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_order_import`
--

CREATE TABLE IF NOT EXISTS `haokiet_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `haokiet_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=363 ;

--
-- Dumping data for table `haokiet_order_import`
--

INSERT INTO `haokiet_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(362, 8, '2014-03-14', '');

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `haokiet_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `haokiet_order_import_detail_1` (`idorder`),
  KEY `haokiet_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=658 ;

--
-- Dumping data for table `haokiet_order_import_detail`
--

INSERT INTO `haokiet_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(657, 362, 19, 2000, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_paid_customer`
--

CREATE TABLE IF NOT EXISTS `haokiet_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `haokiet_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `haokiet_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `haokiet_paid_employee`
--

CREATE TABLE IF NOT EXISTS `haokiet_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `haokiet_paid_employee`
--


-- --------------------------------------------------------

--
-- Table structure for table `haokiet_paid_general`
--

CREATE TABLE IF NOT EXISTS `haokiet_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `haokiet_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=175 ;

--
-- Dumping data for table `haokiet_paid_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `haokiet_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `haokiet_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `haokiet_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `haokiet_paid_pay_roll`
--


-- --------------------------------------------------------

--
-- Table structure for table `haokiet_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `haokiet_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `haokiet_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `haokiet_paid_supplier`
--


-- --------------------------------------------------------

--
-- Table structure for table `haokiet_resource`
--

CREATE TABLE IF NOT EXISTS `haokiet_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `haokiet_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=112 ;

--
-- Dumping data for table `haokiet_resource`
--

INSERT INTO `haokiet_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(19, 8, 'Tờ 10.000 đồng', 'Tờ', 10000, '');

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_supplier`
--

CREATE TABLE IF NOT EXISTS `haokiet_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `haokiet_supplier`
--

INSERT INTO `haokiet_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(8, 'Mai Hữu Ánh', '0703 111 222', 'P4 Vĩnh Long', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_term`
--

CREATE TABLE IF NOT EXISTS `haokiet_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `haokiet_term`
--

INSERT INTO `haokiet_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_term_collect`
--

CREATE TABLE IF NOT EXISTS `haokiet_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `haokiet_term_collect`
--

INSERT INTO `haokiet_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_tracking`
--

CREATE TABLE IF NOT EXISTS `haokiet_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `haokiet_tracking`
--

INSERT INTO `haokiet_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(16, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `haokiet_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=175 ;

--
-- Dumping data for table `haokiet_tracking_daily`
--

INSERT INTO `haokiet_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(147, 16, '2014-02-01', 0, 0, 0, 0, 0),
(148, 16, '2014-02-02', 0, 0, 0, 0, 0),
(149, 16, '2014-02-03', 0, 0, 0, 0, 0),
(150, 16, '2014-02-04', 0, 0, 0, 0, 0),
(151, 16, '2014-02-05', 0, 0, 0, 0, 0),
(152, 16, '2014-02-06', 0, 0, 0, 0, 0),
(153, 16, '2014-02-07', 0, 0, 0, 0, 0),
(154, 16, '2014-02-08', 0, 0, 0, 0, 0),
(155, 16, '2014-02-09', 0, 0, 0, 0, 0),
(156, 16, '2014-02-10', 0, 0, 0, 0, 0),
(157, 16, '2014-02-11', 0, 0, 0, 0, 0),
(158, 16, '2014-02-12', 0, 0, 0, 0, 0),
(159, 16, '2014-02-13', 0, 0, 0, 0, 0),
(160, 16, '2014-02-14', 0, 0, 0, 0, 0),
(161, 16, '2014-02-15', 0, 0, 0, 0, 0),
(162, 16, '2014-02-16', 0, 0, 0, 0, 0),
(163, 16, '2014-02-17', 0, 0, 0, 0, 0),
(164, 16, '2014-02-18', 0, 0, 0, 0, 0),
(165, 16, '2014-02-19', 0, 0, 0, 0, 0),
(166, 16, '2014-02-20', 0, 0, 0, 0, 0),
(167, 16, '2014-02-21', 0, 0, 0, 0, 0),
(168, 16, '2014-02-22', 0, 0, 0, 0, 0),
(169, 16, '2014-02-23', 0, 0, 0, 0, 0),
(170, 16, '2014-02-24', 0, 0, 0, 0, 0),
(171, 16, '2014-02-25', 0, 0, 0, 0, 0),
(172, 16, '2014-02-26', 0, 0, 0, 0, 0),
(173, 16, '2014-02-27', 56000, 0, 0, 0, 0),
(174, 16, '2014-02-28', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `haokiet_user`
--

CREATE TABLE IF NOT EXISTS `haokiet_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `haokiet_user`
--

INSERT INTO `haokiet_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `haokiet_collect_customer`
--
ALTER TABLE `haokiet_collect_customer`
  ADD CONSTRAINT `haokiet_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `haokiet_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `haokiet_collect_general`
--
ALTER TABLE `haokiet_collect_general`
  ADD CONSTRAINT `haokiet_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `haokiet_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `haokiet_customer`
--
ALTER TABLE `haokiet_customer`
  ADD CONSTRAINT `haokiet_customer_ibfk_1` FOREIGN KEY (`id_domain`) REFERENCES `haokiet_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `haokiet_customer_log`
--
ALTER TABLE `haokiet_customer_log`
  ADD CONSTRAINT `haokiet_customer_log_ibfk_1` FOREIGN KEY (`id_customer`) REFERENCES `haokiet_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `haokiet_order_import`
--
ALTER TABLE `haokiet_order_import`
  ADD CONSTRAINT `haokiet_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `haokiet_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `haokiet_order_import_detail`
--
ALTER TABLE `haokiet_order_import_detail`
  ADD CONSTRAINT `haokiet_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `haokiet_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `haokiet_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `haokiet_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `haokiet_paid_customer`
--
ALTER TABLE `haokiet_paid_customer`
  ADD CONSTRAINT `haokiet_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `haokiet_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `haokiet_paid_employee`
--
ALTER TABLE `haokiet_paid_employee`
  ADD CONSTRAINT `haokiet_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `haokiet_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `haokiet_paid_general`
--
ALTER TABLE `haokiet_paid_general`
  ADD CONSTRAINT `haokiet_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `haokiet_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `haokiet_paid_pay_roll`
--
ALTER TABLE `haokiet_paid_pay_roll`
  ADD CONSTRAINT `haokiet_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `haokiet_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `haokiet_paid_supplier`
--
ALTER TABLE `haokiet_paid_supplier`
  ADD CONSTRAINT `haokiet_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `haokiet_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `haokiet_resource`
--
ALTER TABLE `haokiet_resource`
  ADD CONSTRAINT `haokiet_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `haokiet_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
