-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 10, 2014 at 08:33 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_qlcuahang_giaydepxuatkhau`
--

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_collect_customer`
--

CREATE TABLE IF NOT EXISTS `giaydep_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_collect_general`
--

CREATE TABLE IF NOT EXISTS `giaydep_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_collect_1` (`id_term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_collect_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_config`
--

CREATE TABLE IF NOT EXISTS `giaydep_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `giaydep_config`
--

INSERT INTO `giaydep_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '1'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'GIÀY DÉP XUẤT KHẨU'),
(11, 'ADDRESS', 'Phó Cơ Điều, F3, TP Vĩnh Long'),
(12, 'PHONE', '0919.153.189'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'N_MONTH_LOG', '1'),
(17, 'PHONE', '9000'),
(18, 'PHONE', '8700'),
(19, 'PRICE1', '9000'),
(20, 'PRICE2', '8700');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_customer`
--

CREATE TABLE IF NOT EXISTS `giaydep_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=261 ;

--
-- Dumping data for table `giaydep_customer`
--

INSERT INTO `giaydep_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(218, 'Anh Tấn', 0, '', '', '', '', 0),
(219, 'Di 7', 0, '', '', '', '', 0),
(220, 'Di 8', 0, '', '', '', '', 0),
(221, 'Ut lun', 0, '', '', '', '', 0),
(223, 'Di 3 loi', 0, '', '', '', '', 0),
(224, 'Chi tien', 0, '', '', '', '', 0),
(225, 'Ca rang', 0, '', '', '', '', 0),
(233, 'Chu phuoc', 0, '', '', '', '', 0),
(234, 'Di Chi', 0, '', '', '', '', 0),
(238, 'Mai Mì', 0, '', '', '', '', 0),
(244, 'Thảo', 0, '', '', '', '', 0),
(245, 'Dì Mai', 0, '', '', '', '', 0),
(246, 'Dì Bé', 0, '', '', '', '', 0),
(247, 'Dì 10 đò', 0, '', '', '', '', 0),
(248, 'Chú Út Cá', 0, '', '', '', '', 0),
(249, 'Chị Liễu', 0, '', '', '', '', 0),
(250, 'Chị Bé 2 Bcồn', 0, '', '', '', '', 0),
(251, 'Dì 3 Bcồn', 0, '', '', '', '', 0),
(252, 'Dì 5 Bcồn', 0, '', '', '', '', 0),
(253, 'Chị Đào', 0, '', '', '', '', 0),
(254, 'Chị Trân', 0, '', '', '', '', 0),
(255, 'Chị Hồng', 0, '', '', '', '', 0),
(257, 'Chị Thùy', 0, '', '', '', '', 0),
(259, 'Dì Nho', 0, '', '', '', '', 0),
(260, 'Tui nè1', 21, '31', '11', '51', '41', 61);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_employee`
--

CREATE TABLE IF NOT EXISTS `giaydep_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `giaydep_employee`
--

INSERT INTO `giaydep_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(2, 'Nhân viên', 'Bán hàng', 1, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_guest`
--

CREATE TABLE IF NOT EXISTS `giaydep_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `giaydep_guest`
--

INSERT INTO `giaydep_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_export`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_export` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `giaydep_order_export`
--

INSERT INTO `giaydep_order_export` (`id`, `idcustomer`, `date`, `description`) VALUES
(1, 218, '2014-08-09', 'ABC'),
(2, 219, '2014-08-09', '');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_export_detail`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_export_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `count1` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `giaydep_order_export_detail`
--

INSERT INTO `giaydep_order_export_detail` (`id`, `idorder`, `idresource`, `count`, `count1`, `price`) VALUES
(1, 1, 22, 11, 1, 30000),
(2, 1, 19, 10, 0, 25000),
(3, 2, 19, 200, 0, 45000);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_import`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=370 ;

--
-- Dumping data for table `giaydep_order_import`
--

INSERT INTO `giaydep_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(366, 10, '2014-08-09', ''),
(367, 8, '2014-08-08', ''),
(368, 9, '2014-08-09', '');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `count1` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_order_import_detail_1` (`idorder`),
  KEY `giaydep_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=665 ;

--
-- Dumping data for table `giaydep_order_import_detail`
--

INSERT INTO `giaydep_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `count1`, `price`) VALUES
(658, 366, 21, 200, 100, 250000),
(659, 367, 19, 100, 2, 35000),
(660, 368, 20, 150, 0, 350000),
(661, 366, 22, 100, 0, 235000),
(662, 367, 23, 10, 0, 50000);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_customer`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_employee`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_employee`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_general`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_paid_1` (`id_term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_supplier`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_resource`
--

CREATE TABLE IF NOT EXISTS `giaydep_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `giaydep_resource`
--

INSERT INTO `giaydep_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(19, 8, 'Giày Trẻ Em 001', 'Đôi', 38000, ''),
(20, 9, 'Giày Thời Trang 001', 'Đôi', 340000, 'Giày thời trang 001'),
(21, 10, 'Giày Thể Thao 001', 'Đôi', 250000, 'Giày Thể Thao 001'),
(22, 10, 'Giày Thể Thao 002', 'Đôi', 235000, 'Giày Thể Thao 001'),
(23, 8, 'Giày Trẻ Em 002', 'Đôi', 50000, ''),
(24, 8, 'Giày Trẻ Em 003', 'Đôi', 65000, '');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_supplier`
--

CREATE TABLE IF NOT EXISTS `giaydep_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `giaydep_supplier`
--

INSERT INTO `giaydep_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(8, 'Giày Trẻ Em', '111111111', 'P4 Vĩnh Long', '', 0),
(9, 'Giày Thời Trang', '222222222', 'Vĩnh Long', '', 0),
(10, 'Giày Thể Thao', '333333333', 'Vĩnh Long', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_term`
--

CREATE TABLE IF NOT EXISTS `giaydep_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `giaydep_term`
--

INSERT INTO `giaydep_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_term_collect`
--

CREATE TABLE IF NOT EXISTS `giaydep_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `giaydep_term_collect`
--

INSERT INTO `giaydep_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `giaydep_tracking`
--

INSERT INTO `giaydep_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(18, '2014-08-01', '2014-08-31', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `import` bigint(20) NOT NULL,
  `export` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=297 ;

--
-- Dumping data for table `giaydep_tracking_daily`
--

INSERT INTO `giaydep_tracking_daily` (`id`, `id_tracking`, `date`, `import`, `export`) VALUES
(266, 18, '2014-08-01', 0, 0),
(267, 18, '2014-08-02', 0, 0),
(268, 18, '2014-08-03', 0, 0),
(269, 18, '2014-08-04', 0, 0),
(270, 18, '2014-08-05', 0, 0),
(271, 18, '2014-08-06', 0, 0),
(272, 18, '2014-08-07', 0, 0),
(273, 18, '2014-08-08', 0, 0),
(274, 18, '2014-08-09', 126000000, 9550000),
(275, 18, '2014-08-10', 0, 0),
(276, 18, '2014-08-11', 0, 0),
(277, 18, '2014-08-12', 0, 0),
(278, 18, '2014-08-13', 0, 0),
(279, 18, '2014-08-14', 0, 0),
(280, 18, '2014-08-15', 0, 0),
(281, 18, '2014-08-16', 0, 0),
(282, 18, '2014-08-17', 0, 0),
(283, 18, '2014-08-18', 0, 0),
(284, 18, '2014-08-19', 0, 0),
(285, 18, '2014-08-20', 0, 0),
(286, 18, '2014-08-21', 0, 0),
(287, 18, '2014-08-22', 0, 0),
(288, 18, '2014-08-23', 0, 0),
(289, 18, '2014-08-24', 0, 0),
(290, 18, '2014-08-25', 0, 0),
(291, 18, '2014-08-26', 0, 0),
(292, 18, '2014-08-27', 0, 0),
(293, 18, '2014-08-28', 0, 0),
(294, 18, '2014-08-29', 0, 0),
(295, 18, '2014-08-30', 0, 0),
(296, 18, '2014-08-31', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_domain_daily`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_domain_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_domain` int(11) NOT NULL,
  `date` date NOT NULL,
  `ticket_selling` bigint(20) NOT NULL,
  `ticket_selling_back` bigint(20) NOT NULL,
  `ticket_value` bigint(20) NOT NULL,
  `debt` bigint(20) NOT NULL,
  `paid_ticket` bigint(11) NOT NULL,
  `paid_debt` bigint(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=577 ;

--
-- Dumping data for table `giaydep_tracking_domain_daily`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_supplier_daily`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_supplier_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_supplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `ticket_import` bigint(20) NOT NULL,
  `ticket_import_back` bigint(20) NOT NULL,
  `value_import` bigint(20) NOT NULL,
  `value_import_back` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=208 ;

--
-- Dumping data for table `giaydep_tracking_supplier_daily`
--

INSERT INTO `giaydep_tracking_supplier_daily` (`id`, `id_supplier`, `date`, `ticket_import`, `ticket_import_back`, `value_import`, `value_import_back`) VALUES
(205, 10, '2014-08-09', 300, 100, 73500000, 25000000),
(206, 9, '2014-08-09', 150, 0, 52500000, 0),
(207, 8, '2014-08-09', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_user`
--

CREATE TABLE IF NOT EXISTS `giaydep_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `giaydep_user`
--

INSERT INTO `giaydep_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `giaydep_collect_customer`
--
ALTER TABLE `giaydep_collect_customer`
  ADD CONSTRAINT `giaydep_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `giaydep_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_collect_general`
--
ALTER TABLE `giaydep_collect_general`
  ADD CONSTRAINT `giaydep_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `giaydep_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_order_import`
--
ALTER TABLE `giaydep_order_import`
  ADD CONSTRAINT `giaydep_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `giaydep_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_order_import_detail`
--
ALTER TABLE `giaydep_order_import_detail`
  ADD CONSTRAINT `giaydep_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `giaydep_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `giaydep_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `giaydep_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_customer`
--
ALTER TABLE `giaydep_paid_customer`
  ADD CONSTRAINT `giaydep_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `giaydep_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_employee`
--
ALTER TABLE `giaydep_paid_employee`
  ADD CONSTRAINT `giaydep_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `giaydep_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_general`
--
ALTER TABLE `giaydep_paid_general`
  ADD CONSTRAINT `giaydep_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `giaydep_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_supplier`
--
ALTER TABLE `giaydep_paid_supplier`
  ADD CONSTRAINT `giaydep_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `giaydep_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_resource`
--
ALTER TABLE `giaydep_resource`
  ADD CONSTRAINT `giaydep_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `giaydep_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
