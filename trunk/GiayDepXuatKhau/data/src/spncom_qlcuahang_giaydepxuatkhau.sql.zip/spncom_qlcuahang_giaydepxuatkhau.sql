-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 14, 2014 at 06:07 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_qlcuahang_giaydepxuatkhau`
--

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_collect_customer`
--

CREATE TABLE IF NOT EXISTS `giaydep_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_collect_general`
--

CREATE TABLE IF NOT EXISTS `giaydep_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_collect_1` (`id_term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_collect_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_config`
--

CREATE TABLE IF NOT EXISTS `giaydep_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `giaydep_config`
--

INSERT INTO `giaydep_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '1'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'GIÀY DÉP XUẤT KHẨU'),
(11, 'ADDRESS', 'Phó Cơ Điều, F3, TP Vĩnh Long'),
(12, 'PHONE', '0919.153.189'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'N_MONTH_LOG', '1'),
(17, 'PHONE', '9000'),
(18, 'PHONE', '8700'),
(19, 'PRICE1', '9000'),
(20, 'PRICE2', '8700');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_customer`
--

CREATE TABLE IF NOT EXISTS `giaydep_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=262 ;

--
-- Dumping data for table `giaydep_customer`
--

INSERT INTO `giaydep_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '', 'không có', '', '', 0),
(2, 'Bùi Thanh Tuấn', 0, '', '0919 153 189', 'Đồng Tháp', '', 0),
(261, 'Nguyễn Văn A', 0, '', '0996355368', 'Vinh Long', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_employee`
--

CREATE TABLE IF NOT EXISTS `giaydep_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `giaydep_employee`
--

INSERT INTO `giaydep_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(2, 'Nhân viên', 'Bán hàng', 1, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_guest`
--

CREATE TABLE IF NOT EXISTS `giaydep_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `giaydep_guest`
--

INSERT INTO `giaydep_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_export`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_export` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `state` int(11) NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `giaydep_order_export`
--

INSERT INTO `giaydep_order_export` (`id`, `iduser`, `idcustomer`, `date`, `state`, `description`) VALUES
(1, 4, 2, '2014-11-01 00:00:00', 1, 'ABC'),
(2, 4, 2, '2014-11-01 00:00:00', 3, 'của tui nè'),
(3, 4, 1, '2014-11-09 00:00:00', 1, 'Đơn hàng'),
(11, 4, 1, '2014-11-09 13:25:40', 3, 'abc'),
(12, 4, 261, '2014-11-09 19:49:31', 2, 'Đơn hàng'),
(13, 4, 1, '2014-11-09 20:28:32', 1, 'Đơn hàng'),
(14, 3, 2, '2014-11-10 00:32:36', 2, 'Đơn hàng'),
(15, 3, 261, '2014-11-10 00:33:15', 3, 'Đơn hàng'),
(16, 5, 1, '2014-11-10 00:36:07', 3, 'Đơn hàng'),
(17, 5, 1, '2014-11-10 00:36:20', 0, 'Đơn hàng'),
(18, 4, 1, '2014-11-14 17:46:54', 0, 'Đơn hàng');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_export_detail`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_export_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `count1` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `giaydep_order_export_detail`
--

INSERT INTO `giaydep_order_export_detail` (`id`, `idorder`, `idresource`, `count`, `count1`, `price`) VALUES
(1, 1, 22, 20, 1, 30000),
(2, 1, 19, 5, 0, 25000),
(3, 2, 19, 20, 0, 45000),
(4, 3, 19, 3, 1, 38000),
(5, 3, 23, 11, 1, 50000),
(6, 3, 21, 2, 1, 250000),
(7, 3, 22, 1, 1, 235000),
(8, 10, 19, 1, 1, 38000),
(9, 11, 19, 1, 1, 38000),
(10, 11, 24, 1, 1, 65000),
(11, 11, 21, 2, 1, 250000),
(12, 12, 19, 2, 1, 68000),
(13, 13, 22, 1, 1, 335000),
(14, 14, 19, 2, 1, 68000),
(15, 15, 20, 1, 1, 440000),
(16, 15, 21, 1, 1, 350000),
(17, 16, 19, 1, 1, 68000),
(18, 17, 28, 1, 1, 480000),
(19, 13, 19, 1, 1, 68000),
(20, 13, 20, 1, 1, 440000),
(21, 18, 22, 1, 1, 335000),
(22, 18, 21, 1, 1, 350000),
(23, 18, 20, 11, 1, 440000),
(24, 18, 19, 2, 1, 68000);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_import`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=370 ;

--
-- Dumping data for table `giaydep_order_import`
--

INSERT INTO `giaydep_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(366, 10, '2014-11-01', ''),
(367, 8, '2014-11-01', ''),
(368, 9, '2014-11-01', ''),
(369, 8, '2014-11-02', '');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `giaydep_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `count1` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_order_import_detail_1` (`idorder`),
  KEY `giaydep_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=664 ;

--
-- Dumping data for table `giaydep_order_import_detail`
--

INSERT INTO `giaydep_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `count1`, `price`) VALUES
(658, 366, 21, 50, 0, 250000),
(659, 367, 19, 100, 2, 35000),
(660, 368, 20, 150, 0, 350000),
(661, 366, 22, 100, 0, 235000),
(662, 367, 23, 10, 0, 50000),
(663, 369, 19, 5, 0, 38000);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_customer`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_employee`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_employee`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_general`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_paid_1` (`id_term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `giaydep_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_paid_supplier`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_resource`
--

CREATE TABLE IF NOT EXISTS `giaydep_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price_import` int(10) NOT NULL,
  `price_export` int(11) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `giaydep_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `giaydep_resource`
--

INSERT INTO `giaydep_resource` (`id`, `idsupplier`, `name`, `unit`, `price_import`, `price_export`, `description`, `image`) VALUES
(19, 8, 'GTE001', 'Đôi', 38000, 68000, 'Giày Trẻ Em', 'https://lh3.googleusercontent.com/-VWfv12Vr8s0/VF9gRejiZqI/AAAAAAAABR0/VWYVTNulmt4/s800/GiayTreEm001.jpg'),
(20, 9, 'GTR001', 'Đôi', 340000, 440000, 'Giày thời trang 001', 'https://lh3.googleusercontent.com/-6RMXsRdA35Q/VF9gQTfKY9I/AAAAAAAABRg/p41_Wpzb4JU/s400/GiayThoiTrang001.JPG'),
(21, 10, 'GTT001', 'Đôi', 250000, 350000, 'Giày Thể Thao 001', 'https://lh5.googleusercontent.com/-Qiei0hFA-yw/VF9gPKoJuRI/AAAAAAAABRU/MKdKXz4z3Qo/s400/GiayTheThao001.JPG'),
(22, 10, 'GTT002', 'Đôi', 235000, 335000, 'Giày Thể Thao 001', 'https://lh3.googleusercontent.com/-st-MsPiNPk4/VF9gOzR8QjI/AAAAAAAABRM/r11PO9LrULI/s400/GiayTheThao002.jpg'),
(23, 8, 'GTE002', 'Đôi', 50000, 80000, '', 'https://lh4.googleusercontent.com/-g9RVRmVaVIc/VF9gSP0UbfI/AAAAAAAABSE/0ZtTPjgTyRY/s288/GiayTreEm002.jpg'),
(24, 8, 'GTE003', 'Đôi', 65000, 85000, '', 'https://lh3.googleusercontent.com/-e9YZ9x4nrn4/VF9gSu_tBOI/AAAAAAAABSI/RogJK-5E3_0/s288/GiayTreEm003.jpg'),
(25, 10, 'GTT003', 'Đôi', 270000, 370000, 'Giày thể thao Bitis mẫu 003', 'https://lh5.googleusercontent.com/-Pc8ijUwhv_E/VF9gO6GGvwI/AAAAAAAABRI/fs-i8G6umRo/s400/GiayTheThao003.jpg'),
(26, 10, 'GTT004', 'Đôi', 265000, 365000, 'Giày thể thao mẫu 004', 'https://lh5.googleusercontent.com/-vJlhbEdE7B8/VF9gP62mILI/AAAAAAAABRc/cwAdgPvXNbo/s400/GiayTheThao004.jpg'),
(27, 9, 'GTR002', 'Đôi', 320000, 420000, '', 'https://lh4.googleusercontent.com/-rjgiECoIMjg/VF9gRAD8UbI/AAAAAAAABRw/beuNyJyP_Yc/s400/GiayThoiTrang002.png'),
(28, 9, 'GTR003', 'Đôi', 320000, 480000, '', 'https://lh6.googleusercontent.com/-JazWRiklQY4/VF9gReyVoAI/AAAAAAAABR4/bxXfCHOFTFY/s400/GiayThoiTrang003.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_supplier`
--

CREATE TABLE IF NOT EXISTS `giaydep_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `giaydep_supplier`
--

INSERT INTO `giaydep_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(8, 'Giày Trẻ Em', '111111111', 'P4 Vĩnh Long', '', 0),
(9, 'Giày Thời Trang', '222222222', 'Vĩnh Long', '', 0),
(10, 'Giày Thể Thao', '333333333', 'Vĩnh Long', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_term`
--

CREATE TABLE IF NOT EXISTS `giaydep_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `giaydep_term`
--

INSERT INTO `giaydep_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_term_collect`
--

CREATE TABLE IF NOT EXISTS `giaydep_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `giaydep_term_collect`
--

INSERT INTO `giaydep_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `giaydep_tracking`
--

INSERT INTO `giaydep_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(19, '2014-11-01', '2014-11-30', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `import` bigint(20) NOT NULL,
  `export` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=327 ;

--
-- Dumping data for table `giaydep_tracking_daily`
--

INSERT INTO `giaydep_tracking_daily` (`id`, `id_tracking`, `date`, `import`, `export`) VALUES
(266, 18, '2014-08-01', 0, 0),
(267, 18, '2014-08-02', 0, 0),
(268, 18, '2014-08-03', 0, 0),
(269, 18, '2014-08-04', 0, 0),
(270, 18, '2014-08-05', 0, 0),
(271, 18, '2014-08-06', 0, 0),
(272, 18, '2014-08-07', 0, 0),
(273, 18, '2014-08-08', 0, 0),
(274, 18, '2014-08-09', 126000000, 9550000),
(275, 18, '2014-08-10', 0, 0),
(276, 18, '2014-08-11', 0, 0),
(277, 18, '2014-08-12', 0, 0),
(278, 18, '2014-08-13', 0, 0),
(279, 18, '2014-08-14', 0, 0),
(280, 18, '2014-08-15', 0, 0),
(281, 18, '2014-08-16', 0, 0),
(282, 18, '2014-08-17', 0, 0),
(283, 18, '2014-08-18', 0, 0),
(284, 18, '2014-08-19', 0, 0),
(285, 18, '2014-08-20', 0, 0),
(286, 18, '2014-08-21', 0, 0),
(287, 18, '2014-08-22', 0, 0),
(288, 18, '2014-08-23', 0, 0),
(289, 18, '2014-08-24', 0, 0),
(290, 18, '2014-08-25', 0, 0),
(291, 18, '2014-08-26', 0, 0),
(292, 18, '2014-08-27', 0, 0),
(293, 18, '2014-08-28', 0, 0),
(294, 18, '2014-08-29', 0, 0),
(295, 18, '2014-08-30', 0, 0),
(296, 18, '2014-08-31', 0, 0),
(297, 19, '2014-11-01', 36000000, 0),
(298, 19, '2014-11-02', 0, 0),
(299, 19, '2014-11-03', 0, 0),
(300, 19, '2014-11-04', 0, 0),
(301, 19, '2014-11-05', 0, 0),
(302, 19, '2014-11-06', 0, 0),
(303, 19, '2014-11-07', 0, 0),
(304, 19, '2014-11-08', 0, 0),
(305, 19, '2014-11-09', 0, 0),
(306, 19, '2014-11-10', 0, 0),
(307, 19, '2014-11-11', 0, 0),
(308, 19, '2014-11-12', 0, 0),
(309, 19, '2014-11-13', 0, 0),
(310, 19, '2014-11-14', 0, 0),
(311, 19, '2014-11-15', 0, 0),
(312, 19, '2014-11-16', 0, 0),
(313, 19, '2014-11-17', 0, 0),
(314, 19, '2014-11-18', 0, 0),
(315, 19, '2014-11-19', 0, 0),
(316, 19, '2014-11-20', 0, 0),
(317, 19, '2014-11-21', 0, 0),
(318, 19, '2014-11-22', 0, 0),
(319, 19, '2014-11-23', 0, 0),
(320, 19, '2014-11-24', 0, 0),
(321, 19, '2014-11-25', 0, 0),
(322, 19, '2014-11-26', 0, 0),
(323, 19, '2014-11-27', 0, 0),
(324, 19, '2014-11-28', 0, 0),
(325, 19, '2014-11-29', 0, 0),
(326, 19, '2014-11-30', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_daily_resource`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_daily_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` double NOT NULL,
  `count_import` double NOT NULL,
  `count_export` double NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=181 ;

--
-- Dumping data for table `giaydep_tracking_daily_resource`
--

INSERT INTO `giaydep_tracking_daily_resource` (`id`, `id_td`, `id_resource`, `count_old`, `count_import`, `count_export`, `price`) VALUES
(1, 297, 19, 0, 100, 25, 38000),
(2, 297, 20, 0, 150, 0, 340000),
(3, 297, 21, 0, 50, 0, 250000),
(4, 297, 22, 0, 100, 20, 235000),
(5, 297, 23, 0, 10, 0, 50000),
(6, 297, 24, 0, 0, 0, 65000),
(7, 297, 25, 0, 0, 0, 270000),
(8, 297, 26, 0, 0, 0, 265000),
(9, 297, 27, 0, 0, 0, 320000),
(10, 297, 28, 0, 0, 0, 320000),
(11, 298, 19, 75, 5, 0, 38000),
(12, 298, 20, 150, 0, 0, 340000),
(13, 298, 21, 50, 0, 0, 250000),
(14, 298, 22, 80, 0, 0, 235000),
(15, 298, 23, 10, 0, 0, 50000),
(16, 298, 24, 0, 0, 0, 65000),
(17, 298, 25, 0, 0, 0, 270000),
(18, 298, 26, 0, 0, 0, 265000),
(19, 298, 27, 0, 0, 0, 320000),
(20, 298, 28, 0, 0, 0, 320000),
(21, 299, 19, 80, 0, 0, 38000),
(22, 299, 20, 150, 0, 0, 340000),
(23, 299, 21, 50, 0, 0, 250000),
(24, 299, 22, 80, 0, 0, 235000),
(25, 299, 23, 10, 0, 0, 50000),
(26, 299, 24, 0, 0, 0, 65000),
(27, 299, 25, 0, 0, 0, 270000),
(28, 299, 26, 0, 0, 0, 265000),
(29, 299, 27, 0, 0, 0, 320000),
(30, 299, 28, 0, 0, 0, 320000),
(31, 300, 19, 80, 0, 0, 38000),
(32, 300, 20, 150, 0, 0, 340000),
(33, 300, 21, 50, 0, 0, 250000),
(34, 300, 22, 80, 0, 0, 235000),
(35, 300, 23, 10, 0, 0, 50000),
(36, 300, 24, 0, 0, 0, 65000),
(37, 300, 25, 0, 0, 0, 270000),
(38, 300, 26, 0, 0, 0, 265000),
(39, 300, 27, 0, 0, 0, 320000),
(40, 300, 28, 0, 0, 0, 320000),
(41, 301, 19, 80, 0, 0, 38000),
(42, 301, 20, 150, 0, 0, 340000),
(43, 301, 21, 50, 0, 0, 250000),
(44, 301, 22, 80, 0, 0, 235000),
(45, 301, 23, 10, 0, 0, 50000),
(46, 301, 24, 0, 0, 0, 65000),
(47, 301, 25, 0, 0, 0, 270000),
(48, 301, 26, 0, 0, 0, 265000),
(49, 301, 27, 0, 0, 0, 320000),
(50, 301, 28, 0, 0, 0, 320000),
(51, 302, 19, 80, 0, 0, 38000),
(52, 302, 20, 150, 0, 0, 340000),
(53, 302, 21, 50, 0, 0, 250000),
(54, 302, 22, 80, 0, 0, 235000),
(55, 302, 23, 10, 0, 0, 50000),
(56, 302, 24, 0, 0, 0, 65000),
(57, 302, 25, 0, 0, 0, 270000),
(58, 302, 26, 0, 0, 0, 265000),
(59, 302, 27, 0, 0, 0, 320000),
(60, 302, 28, 0, 0, 0, 320000),
(61, 303, 19, 80, 0, 0, 38000),
(62, 303, 20, 150, 0, 0, 340000),
(63, 303, 21, 50, 0, 0, 250000),
(64, 303, 22, 80, 0, 0, 235000),
(65, 303, 23, 10, 0, 0, 50000),
(66, 303, 24, 0, 0, 0, 65000),
(67, 303, 25, 0, 0, 0, 270000),
(68, 303, 26, 0, 0, 0, 265000),
(69, 303, 27, 0, 0, 0, 320000),
(70, 303, 28, 0, 0, 0, 320000),
(71, 304, 19, 80, 0, 0, 38000),
(72, 304, 20, 150, 0, 0, 340000),
(73, 304, 21, 50, 0, 0, 250000),
(74, 304, 22, 80, 0, 0, 235000),
(75, 304, 23, 10, 0, 0, 50000),
(76, 304, 24, 0, 0, 0, 65000),
(77, 304, 25, 0, 0, 0, 270000),
(78, 304, 26, 0, 0, 0, 265000),
(79, 304, 27, 0, 0, 0, 320000),
(80, 304, 28, 0, 0, 0, 320000),
(81, 305, 19, 80, 0, 3, 38000),
(82, 305, 20, 150, 0, 0, 340000),
(83, 305, 21, 50, 0, 2, 250000),
(84, 305, 22, 80, 0, 1, 235000),
(85, 305, 23, 10, 0, 11, 50000),
(86, 305, 24, 0, 0, 0, 65000),
(87, 305, 25, 0, 0, 0, 270000),
(88, 305, 26, 0, 0, 0, 265000),
(89, 305, 27, 0, 0, 0, 320000),
(90, 305, 28, 0, 0, 0, 320000),
(91, 306, 19, 77, 0, 0, 38000),
(92, 306, 20, 150, 0, 0, 340000),
(93, 306, 21, 48, 0, 0, 250000),
(94, 306, 22, 79, 0, 0, 235000),
(95, 306, 23, -1, 0, 0, 50000),
(96, 306, 24, 0, 0, 0, 65000),
(97, 306, 25, 0, 0, 0, 270000),
(98, 306, 26, 0, 0, 0, 265000),
(99, 306, 27, 0, 0, 0, 320000),
(100, 306, 28, 0, 0, 0, 320000),
(101, 307, 19, 77, 0, 0, 38000),
(102, 307, 20, 150, 0, 0, 340000),
(103, 307, 21, 48, 0, 0, 250000),
(104, 307, 22, 79, 0, 0, 235000),
(105, 307, 23, -1, 0, 0, 50000),
(106, 307, 24, 0, 0, 0, 65000),
(107, 307, 25, 0, 0, 0, 270000),
(108, 307, 26, 0, 0, 0, 265000),
(109, 307, 27, 0, 0, 0, 320000),
(110, 307, 28, 0, 0, 0, 320000),
(111, 308, 19, 77, 0, 0, 38000),
(112, 308, 20, 150, 0, 0, 340000),
(113, 308, 21, 48, 0, 0, 250000),
(114, 308, 22, 79, 0, 0, 235000),
(115, 308, 23, -1, 0, 0, 50000),
(116, 308, 24, 0, 0, 0, 65000),
(117, 308, 25, 0, 0, 0, 270000),
(118, 308, 26, 0, 0, 0, 265000),
(119, 308, 27, 0, 0, 0, 320000),
(120, 308, 28, 0, 0, 0, 320000),
(121, 309, 19, 77, 0, 0, 38000),
(122, 309, 20, 150, 0, 0, 340000),
(123, 309, 21, 48, 0, 0, 250000),
(124, 309, 22, 79, 0, 0, 235000),
(125, 309, 23, -1, 0, 0, 50000),
(126, 309, 24, 0, 0, 0, 65000),
(127, 309, 25, 0, 0, 0, 270000),
(128, 309, 26, 0, 0, 0, 265000),
(129, 309, 27, 0, 0, 0, 320000),
(130, 309, 28, 0, 0, 0, 320000),
(131, 310, 19, 77, 0, 0, 38000),
(132, 310, 20, 150, 0, 0, 340000),
(133, 310, 21, 48, 0, 0, 250000),
(134, 310, 22, 79, 0, 0, 235000),
(135, 310, 23, -1, 0, 0, 50000),
(136, 310, 24, 0, 0, 0, 65000),
(137, 310, 25, 0, 0, 0, 270000),
(138, 310, 26, 0, 0, 0, 265000),
(139, 310, 27, 0, 0, 0, 320000),
(140, 310, 28, 0, 0, 0, 320000),
(141, 311, 19, 77, 0, 0, 38000),
(142, 311, 20, 150, 0, 0, 340000),
(143, 311, 21, 48, 0, 0, 250000),
(144, 311, 22, 79, 0, 0, 235000),
(145, 311, 23, -1, 0, 0, 50000),
(146, 311, 24, 0, 0, 0, 65000),
(147, 311, 25, 0, 0, 0, 270000),
(148, 311, 26, 0, 0, 0, 265000),
(149, 311, 27, 0, 0, 0, 320000),
(150, 311, 28, 0, 0, 0, 320000),
(151, 312, 19, 77, 0, 0, 38000),
(152, 312, 20, 150, 0, 0, 340000),
(153, 312, 21, 48, 0, 0, 250000),
(154, 312, 22, 79, 0, 0, 235000),
(155, 312, 23, -1, 0, 0, 50000),
(156, 312, 24, 0, 0, 0, 65000),
(157, 312, 25, 0, 0, 0, 270000),
(158, 312, 26, 0, 0, 0, 265000),
(159, 312, 27, 0, 0, 0, 320000),
(160, 312, 28, 0, 0, 0, 320000),
(161, 313, 19, 0, 0, 0, 38000),
(162, 313, 20, 0, 0, 0, 340000),
(163, 313, 21, 0, 0, 0, 250000),
(164, 313, 22, 0, 0, 0, 235000),
(165, 313, 23, 0, 0, 0, 50000),
(166, 313, 24, 0, 0, 0, 65000),
(167, 313, 25, 0, 0, 0, 270000),
(168, 313, 26, 0, 0, 0, 265000),
(169, 313, 27, 0, 0, 0, 320000),
(170, 313, 28, 0, 0, 0, 320000),
(171, 314, 19, 0, 0, 0, 38000),
(172, 314, 20, 0, 0, 0, 340000),
(173, 314, 21, 0, 0, 0, 250000),
(174, 314, 22, 0, 0, 0, 235000),
(175, 314, 23, 0, 0, 0, 50000),
(176, 314, 24, 0, 0, 0, 65000),
(177, 314, 25, 0, 0, 0, 270000),
(178, 314, 26, 0, 0, 0, 265000),
(179, 314, 27, 0, 0, 0, 320000),
(180, 314, 28, 0, 0, 0, 320000);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_store`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaydep_tracking_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaydep_tracking_supplier_daily`
--

CREATE TABLE IF NOT EXISTS `giaydep_tracking_supplier_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_supplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `ticket_import` bigint(20) NOT NULL,
  `ticket_import_back` bigint(20) NOT NULL,
  `value_import` bigint(20) NOT NULL,
  `value_import_back` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=208 ;

--
-- Dumping data for table `giaydep_tracking_supplier_daily`
--

INSERT INTO `giaydep_tracking_supplier_daily` (`id`, `id_supplier`, `date`, `ticket_import`, `ticket_import_back`, `value_import`, `value_import_back`) VALUES
(205, 10, '2014-08-09', 300, 100, 73500000, 25000000),
(206, 9, '2014-08-09', 150, 0, 52500000, 0),
(207, 8, '2014-08-09', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaydep_user`
--

CREATE TABLE IF NOT EXISTS `giaydep_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `giaydep_user`
--

INSERT INTO `giaydep_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(5, 'Cửa hàng', 'cuahang@gmail.com', '123456', 0, NULL, '2014-11-10 00:10:08', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `giaydep_collect_customer`
--
ALTER TABLE `giaydep_collect_customer`
  ADD CONSTRAINT `giaydep_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `giaydep_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_collect_general`
--
ALTER TABLE `giaydep_collect_general`
  ADD CONSTRAINT `giaydep_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `giaydep_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_order_import`
--
ALTER TABLE `giaydep_order_import`
  ADD CONSTRAINT `giaydep_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `giaydep_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_order_import_detail`
--
ALTER TABLE `giaydep_order_import_detail`
  ADD CONSTRAINT `giaydep_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `giaydep_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `giaydep_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `giaydep_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_customer`
--
ALTER TABLE `giaydep_paid_customer`
  ADD CONSTRAINT `giaydep_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `giaydep_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_employee`
--
ALTER TABLE `giaydep_paid_employee`
  ADD CONSTRAINT `giaydep_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `giaydep_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_general`
--
ALTER TABLE `giaydep_paid_general`
  ADD CONSTRAINT `giaydep_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `giaydep_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_paid_supplier`
--
ALTER TABLE `giaydep_paid_supplier`
  ADD CONSTRAINT `giaydep_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `giaydep_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giaydep_resource`
--
ALTER TABLE `giaydep_resource`
  ADD CONSTRAINT `giaydep_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `giaydep_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
