-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 27, 2014 at 07:35 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlcuahan_yoyoshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `shopc_category`
--

CREATE TABLE IF NOT EXISTS `shopc_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `shopc_category`
--

INSERT INTO `shopc_category` (`id`, `name`, `key`, `order`) VALUES
(1, 'Thời trang nam', 'thoi-trang-nam', 1),
(2, 'Thời trang nữ', 'thoi-trang-nu', 2),
(14, 'Thời trang bé', 'thoi-trang-be', 3);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_category1`
--

CREATE TABLE IF NOT EXISTS `shopc_category1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `shopc_category1`
--

INSERT INTO `shopc_category1` (`id`, `id_category`, `name`, `key`, `order`) VALUES
(1, 1, 'Sơ mi', 'so-mi', 2),
(2, 1, 'Áo thun', 'ao-thun', 0),
(3, 2, 'Váy', 'vay', 0),
(4, 2, 'đầm', 'dam', 0),
(5, 2, 'đổ ngủ', 'do-ngu', 0),
(6, 2, 'áo tắm', 'ao-tam', 0),
(7, 14, '1 tháng tuổi', '1-thang-tuoi', 0),
(8, 14, '3 tháng tuổi', '3-thang-tuoi', 0),
(9, 14, '1 tuổi', '1-tuoi', 0),
(10, 14, '2 tuổi', '2-tuoi', 0),
(11, 14, '3 tuổi', '3-tuoi', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_config`
--

CREATE TABLE IF NOT EXISTS `shopc_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=31 ;

--
-- Dumping data for table `shopc_config`
--

INSERT INTO `shopc_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '1'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'SHOP YOYO'),
(11, 'ADDRESS', 'TP HCM'),
(12, 'PHONE', '0919 153 189'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'POST_POLICY', '5'),
(19, 'EVERY_5_MINUTES', '2000'),
(22, 'SLOGAN', 'Khẩu hiệu của Shop'),
(23, 'POST_INTRODUCTION', '1'),
(24, 'POST_FAQ', '4'),
(28, 'POST_POLICY', '5'),
(29, 'N_MONTH_LOG', '1'),
(30, 'PRESENTATION_HOME', '1');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_customer`
--

CREATE TABLE IF NOT EXISTS `shopc_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  `id_domain` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_domain` (`id_domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `shopc_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `shopc_domain`
--

CREATE TABLE IF NOT EXISTS `shopc_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `shopc_domain`
--

INSERT INTO `shopc_domain` (`id`, `name`) VALUES
(1, 'Mỹ Thuận'),
(2, 'Nha Mân'),
(3, 'Sa Đéc'),
(4, 'Cái Tàu'),
(5, 'Vĩnh Long');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_employee`
--

CREATE TABLE IF NOT EXISTS `shopc_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `shopc_employee`
--

INSERT INTO `shopc_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(2, 'Nhân viên', 'Bán hàng', 1, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_guest`
--

CREATE TABLE IF NOT EXISTS `shopc_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `shopc_guest`
--

INSERT INTO `shopc_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_image`
--

CREATE TABLE IF NOT EXISTS `shopc_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idresource` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `url` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idresource` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `shopc_image`
--

INSERT INTO `shopc_image` (`id`, `idresource`, `name`, `date`, `url`) VALUES
(1, 19, 'H1', '2014-03-28 00:00:00', 'https://lh6.googleusercontent.com/-IJWA6r3XWR0/Uy-inp2oWBI/AAAAAAAAA74/6HfGac8WOJM/s800/product1.jpg'),
(2, 19, 'H2', '2014-03-24 00:00:00', 'https://lh6.googleusercontent.com/-U1KC_9hV5eI/Uy-ins6AXhI/AAAAAAAAA70/OEIs6c0kG7k/s800/product11.jpg'),
(3, 19, 'H3', '2014-03-24 00:00:00', 'https://lh3.googleusercontent.com/-nscgUnWTJYU/Uy-inogN9_I/AAAAAAAAA7s/25S_2wQ8rmw/s800/product12.jpg'),
(4, 20, 'H1', '2014-03-24 00:00:00', 'https://lh5.googleusercontent.com/-SYxAJg_i3JE/Uy-iou-zqwI/AAAAAAAAA8E/m4Nr0SkZzpc/s800/product2.jpg'),
(5, 21, 'H1', '2014-03-24 00:00:00', 'https://lh3.googleusercontent.com/-yW7lYC2AgOI/Uy-iom5lpmI/AAAAAAAAA8Q/sbwdzR2lS4k/s800/product3.jpg'),
(6, 22, 'H1', '2014-03-24 00:00:00', 'https://lh4.googleusercontent.com/-PyZ2aW4g10A/Uy-ipNMcFzI/AAAAAAAAA8M/aD5tP4yW4Jo/s800/product4.jpg'),
(7, 23, 'H1', '2014-03-28 00:00:00', 'https://lh6.googleusercontent.com/-IJWA6r3XWR0/Uy-inp2oWBI/AAAAAAAAA74/6HfGac8WOJM/s800/product1.jpg'),
(8, 24, 'H1', '2014-03-28 00:00:00', 'https://lh6.googleusercontent.com/-IJWA6r3XWR0/Uy-inp2oWBI/AAAAAAAAA74/6HfGac8WOJM/s800/product1.jpg'),
(9, 26, '1', '2014-03-28 00:00:00', 'https://lh6.googleusercontent.com/-IJWA6r3XWR0/Uy-inp2oWBI/AAAAAAAAA74/6HfGac8WOJM/s800/product1.jpg'),
(10, 25, '1', '2014-03-28 00:00:00', 'https://lh6.googleusercontent.com/-IJWA6r3XWR0/Uy-inp2oWBI/AAAAAAAAA74/6HfGac8WOJM/s800/product1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_order_import`
--

CREATE TABLE IF NOT EXISTS `shopc_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopc_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=363 ;

--
-- Dumping data for table `shopc_order_import`
--

INSERT INTO `shopc_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(362, 8, '2014-03-14', '');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `shopc_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopc_order_import_detail_1` (`idorder`),
  KEY `shopc_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=661 ;

--
-- Dumping data for table `shopc_order_import_detail`
--

INSERT INTO `shopc_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(657, 362, 19, 10, 10000),
(658, 362, 20, 10, 56000),
(659, 362, 21, 10, 95000),
(660, 362, 22, 10, 120000);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_post`
--

CREATE TABLE IF NOT EXISTS `shopc_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `shopc_post`
--

INSERT INTO `shopc_post` (`id`, `title`, `content`, `key`) VALUES
(1, 'Giới thiệu', '<p>\r\n	B&agrave;i viết giới thiệu về Shop được viết chi tiết ở đ&acirc;y.1</p>\r\n', 'gioi-thieu-1395735520'),
(4, 'FAQ', '<p>\r\n	C&aacute;c c&acirc;u hỏi thường gặp được viết chi tiết ở đ&acirc;y.</p>\r\n', 'faq-1395727808'),
(5, 'Chính sách', '<h3 style="text-align: justify;">\r\n	Ch&iacute;nh s&aacute;ch đổi trả h&agrave;ng v&agrave; ho&agrave;n tiền tại l&agrave; như thế n&agrave;o?</h3>\r\n<div style="text-align: justify;">\r\n	Khi mua sắm với Shop, qu&yacute; kh&aacute;ch c&oacute; thể đổi trả h&agrave;ng h&oacute;a trong v&ograve;ng 30 ng&agrave;y kể từ ng&agrave;y nhận h&agrave;ng, qu&yacute; kh&aacute;ch vui l&ograve;ng tham khảo th&ocirc;ng tin chi tiết về ch&iacute;nh s&aacute;ch đổi trả h&agrave;ng h&oacute;a của tại:...</div>\r\n<div style="text-align: justify;">\r\n	<h3>\r\n		Quy định đổi trả h&agrave;ng của Shop l&agrave; g&igrave;?</h3>\r\n	<div>\r\n		Qu&yacute; kh&aacute;ch c&oacute; thể đổi trả sản phẩm trong v&ograve;ng 30 ng&agrave;y kể từ ng&agrave;y nhận được đơn h&agrave;ng:</div>\r\n	<ul>\r\n		<li>\r\n			Đối với sản phẩm bị lỗi sản xuất hoặc giao sai quy c&aacute;ch: Shop sẽ gửi sản phẩm mới, ho&agrave;n tiền v&agrave;o t&agrave;i khoản của qu&yacute; kh&aacute;ch hoặc ho&agrave;n m&atilde; tiền điện tử.</li>\r\n		<li>\r\n			Đối với những sản phẩm kh&ocirc;ng phải lỗi của nh&agrave; sản xuất mà do sản ph&acirc;̉m chưa phù hợp nhu c&acirc;̀u sử dụng của quý khách: Shop sẽ chỉ ho&agrave;n bằng m&atilde; tiền điện tử.</li>\r\n		<li>\r\n			Đối với những sản phẩm bị lỗi sau 30 ng&agrave;y kể từ ng&agrave;y nhận h&agrave;ng, qu&yacute; kh&aacute;ch vui l&ograve;ng li&ecirc;n hệ trực tiếp trung t&acirc;m bảo h&agrave;nh ch&iacute;nh h&atilde;ng của sản phẩm để được hỗ trợ ngay lập tức.</li>\r\n	</ul>\r\n	<div>\r\n		Lưu &yacute;: Th&ocirc;ng tin về quy định đổi trả qu&yacute; kh&aacute;ch c&oacute; thể tham khảo tại: ...</div>\r\n</div>\r\n<h3>\r\n	T&ocirc;i c&oacute; thể đổi trả sản phẩm sau 30 ng&agrave;y kể từ ng&agrave;y nhận h&agrave;ng kh&ocirc;ng?</h3>\r\n<div style="text-align: justify;">\r\n	Rất tiếc, trong trường hợp n&agrave;y, sản phẩm chỉ được hỗ trợ bảo h&agrave;nh. Ch&uacute;ng t&ocirc;i khuyến kh&iacute;ch qu&yacute; kh&aacute;ch li&ecirc;n hệ trực tiếp nh&agrave; sản xuất hoặc trung t&acirc;m bảo h&agrave;nh ch&iacute;nh h&atilde;ng để được hỗ trợ nhanh ch&oacute;ng.</div>\r\n<div style="text-align: justify;">\r\n	<h3>\r\n		Nếu t&ocirc;i cảm thấy sản phẩm đ&atilde; mua kh&ocirc;ng ph&ugrave; hợp nhu cầu sử dụng, liệu t&ocirc;i c&oacute; thể đổi sang sản phẩm kh&aacute;c kh&ocirc;ng?</h3>\r\n	<div>\r\n		Qu&yacute; kh&aacute;ch c&oacute; thể đổi trả sản phẩm trong v&ograve;ng 30 ng&agrave;y kể từ ng&agrave;y nhận h&agrave;ng v&agrave; phải đảm bảo qu&yacute; kh&aacute;ch vẫn c&ograve;n giữ h&oacute;a đơn mua h&agrave;ng, sản phẩm chưa c&oacute; dấu hiệu sử dụng, c&ograve;n nguy&ecirc;n t&igrave;nh trạng đ&oacute;ng g&oacute;i ban đầu hoặc ni&ecirc;m phong (nếu c&oacute;) v&agrave; đầy đủ phụ kiện hoặc quà tặng kèm theo (n&ecirc;́u có).</div>\r\n</div>\r\n<h3 style="text-align: justify;">\r\n	L&agrave;m thế n&agrave;o t&ocirc;i biết được sản phẩm c&oacute; bị lỗi sản phẩm hay kh&ocirc;ng trong khi kh&ocirc;ng kiểm tra n&oacute;?</h3>\r\n<div style="text-align: justify;">\r\n	Đừng qu&aacute; lo lắng về điều n&agrave;y. Nếu Lazada.vn gửi sản phẩm bị lỗi đến qu&yacute; kh&aacute;ch, ch&uacute;ng t&ocirc;i sẽ đổi sản phẩm mới cho qu&yacute; kh&aacute;ch m&agrave; kh&ocirc;ng tốn bất cứ chi ph&iacute; n&agrave;o hoặc ho&agrave;n trả lại tiền cho qu&yacute; kh&aacute;ch.</div>\r\n', 'chinh-sach-1395931412');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_presentation`
--

CREATE TABLE IF NOT EXISTS `shopc_presentation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `shopc_presentation`
--

INSERT INTO `shopc_presentation` (`id`, `name`, `order`, `key`) VALUES
(1, 'Trình bày 1', 1, 0),
(2, 'Trình bày 2', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_resource`
--

CREATE TABLE IF NOT EXISTS `shopc_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `idcategory` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `price1` int(12) NOT NULL,
  `price2` int(12) NOT NULL,
  `madein` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `madeby` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `style` int(11) NOT NULL,
  `canvas` int(11) NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopc_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Dumping data for table `shopc_resource`
--

INSERT INTO `shopc_resource` (`id`, `idsupplier`, `idcategory`, `name`, `code`, `price1`, `price2`, `madein`, `madeby`, `type`, `style`, `canvas`, `note`, `key`) VALUES
(19, 8, 1, 'Sơ mi nam 01', 'QD001', 155000, 250000, 'Hong Kong', 0, 0, 0, 0, '', 'so-mi-nam-01-1395939468'),
(20, 8, 2, 'Áo thun nam 02', 'ATN002', 56000, 112000, 'Việt Nam', 0, 0, 0, 0, 'Áo thun nam 02', 'ao-thun-nam-02-1395940336'),
(21, 8, 3, 'Váy nữ ren 01', 'JN001', 95000, 160000, 'Trung Quốc', 0, 0, 0, 0, '101', 'vay-nu-ren-01-1395940939'),
(22, 8, 4, 'Đầm nữ ngắn 01', 'SM001', 120000, 220000, 'Hong Kong', 0, 0, 0, 0, '5', 'dam-nu-ngan-01-1395940932'),
(23, 8, 1, 'Sơ mi nam 02', 'SMN02', 56000, 100000, 'Việt Nam', 0, 0, 0, 0, '', 'so-mi-nam-02-1395940378'),
(24, 8, 1, 'Sơ mi nam 03', 'SMN03', 55000, 85000, 'Việt Nam', 0, 0, 0, 0, '', 'so-mi-nam-03-1395940701'),
(25, 8, 4, 'Đầm nữ ren 02', 'VNR02', 120000, 180000, 'Việt Nam', 0, 0, 0, 0, 'Đầm nữ ren 02', 'dam-nu-ren-02-1395941072'),
(26, 8, 2, 'Áo thun nam 02', 'ATN02', 60000, 90000, 'Việt Nam', 0, 0, 0, 0, 'Áo thun nam 02', 'ao-thun-nam-02-1395941110');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_save`
--

CREATE TABLE IF NOT EXISTS `shopc_save` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date1` date NOT NULL,
  `date2` date NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `shopc_save`
--

INSERT INTO `shopc_save` (`id`, `name`, `date1`, `date2`, `key`) VALUES
(1, 'Khuyến mãi tháng 3', '2014-03-27', '2014-03-31', 'khuyen-mai-thang-3');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_save_resource`
--

CREATE TABLE IF NOT EXISTS `shopc_save_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsave` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `shopc_save_resource`
--

INSERT INTO `shopc_save_resource` (`id`, `idsave`, `idresource`, `discount`, `value`) VALUES
(2, 1, 19, 15, 20000),
(3, 1, 20, 10, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_slide`
--

CREATE TABLE IF NOT EXISTS `shopc_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idpresentation` int(11) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `shopc_slide`
--

INSERT INTO `shopc_slide` (`id`, `idpresentation`, `name`, `order`, `note`, `url`) VALUES
(1, 1, 'Hàng mới về', 1, 'Hàng mới về 2013', 'https://lh6.googleusercontent.com/-W0SWkx8AL24/Uy-irrEgv_I/AAAAAAAAA8Y/5bTIDivghLQ/s800/slider1.png'),
(2, 1, 'Bán chạy nhất', 2, 'Những hàng bán chạy nhất', 'https://lh4.googleusercontent.com/-jpsjoG4wL64/Uy-iw16t3lI/AAAAAAAAA8o/jlcuqg24ktY/s800/slider2.png'),
(3, 1, 'Bộ sưu tập mùa hè', 1, 'Bộ sưu tập mùa hè năm nay', 'https://lh6.googleusercontent.com/-yU_HBeMIY18/Uy-iu1GHBmI/AAAAAAAAA8g/efaDupRHia8/s800/slider3.png');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_supplier`
--

CREATE TABLE IF NOT EXISTS `shopc_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `shopc_supplier`
--

INSERT INTO `shopc_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(8, 'Nhà cung cấp 1', '0919 11 22 33', 'Q3 TPHCM', '', 0),
(9, 'Nhà cung cấp 2', '0919 22 44 33', 'Q4 TPHCM', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_tracking`
--

CREATE TABLE IF NOT EXISTS `shopc_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `shopc_tracking`
--

INSERT INTO `shopc_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(17, '2014-03-01', '2014-03-31', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `shopc_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `ticket1` bigint(20) NOT NULL,
  `ticket2` bigint(20) NOT NULL,
  `paid1` bigint(20) NOT NULL,
  `paid2` bigint(20) NOT NULL,
  `debt` bigint(20) NOT NULL,
  `paid1_remain` bigint(11) NOT NULL,
  `paid2_remain` bigint(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=206 ;

--
-- Dumping data for table `shopc_tracking_daily`
--

INSERT INTO `shopc_tracking_daily` (`id`, `id_tracking`, `date`, `ticket1`, `ticket2`, `paid1`, `paid2`, `debt`, `paid1_remain`, `paid2_remain`) VALUES
(147, 16, '2014-02-01', 0, 0, 0, 0, 0, 0, 0),
(148, 16, '2014-02-02', 0, 0, 0, 0, 0, 0, 0),
(149, 16, '2014-02-03', 0, 0, 0, 0, 0, 0, 0),
(150, 16, '2014-02-04', 0, 0, 0, 0, 0, 0, 0),
(151, 16, '2014-02-05', 0, 0, 0, 0, 0, 0, 0),
(152, 16, '2014-02-06', 0, 0, 0, 0, 0, 0, 0),
(153, 16, '2014-02-07', 0, 0, 0, 0, 0, 0, 0),
(154, 16, '2014-02-08', 0, 0, 0, 0, 0, 0, 0),
(155, 16, '2014-02-09', 0, 0, 0, 0, 0, 0, 0),
(156, 16, '2014-02-10', 0, 0, 0, 0, 0, 0, 0),
(157, 16, '2014-02-11', 0, 0, 0, 0, 0, 0, 0),
(158, 16, '2014-02-12', 0, 0, 0, 0, 0, 0, 0),
(159, 16, '2014-02-13', 0, 0, 0, 0, 0, 0, 0),
(160, 16, '2014-02-14', 0, 0, 0, 0, 0, 0, 0),
(161, 16, '2014-02-15', 0, 0, 0, 0, 0, 0, 0),
(162, 16, '2014-02-16', 0, 0, 0, 0, 0, 0, 0),
(163, 16, '2014-02-17', 0, 0, 0, 0, 0, 0, 0),
(164, 16, '2014-02-18', 0, 0, 0, 0, 0, 0, 0),
(165, 16, '2014-02-19', 0, 0, 0, 0, 0, 0, 0),
(166, 16, '2014-02-20', 0, 0, 0, 0, 0, 0, 0),
(167, 16, '2014-02-21', 0, 0, 0, 0, 0, 0, 0),
(168, 16, '2014-02-22', 0, 0, 0, 0, 0, 0, 0),
(169, 16, '2014-02-23', 0, 0, 0, 0, 0, 0, 0),
(170, 16, '2014-02-24', 0, 0, 0, 0, 0, 0, 0),
(171, 16, '2014-02-25', 0, 0, 0, 0, 0, 0, 0),
(172, 16, '2014-02-26', 0, 0, 0, 0, 0, 0, 0),
(173, 16, '2014-02-27', 56000, 0, 0, 0, 0, 0, 0),
(174, 16, '2014-02-28', 0, 0, 0, 0, 0, 0, 0),
(175, 17, '2014-03-01', 0, 0, 0, 0, 0, 0, 0),
(176, 17, '2014-03-02', 0, 0, 0, 0, 0, 0, 0),
(177, 17, '2014-03-03', 0, 0, 0, 0, 0, 0, 0),
(178, 17, '2014-03-04', 0, 0, 0, 0, 0, 0, 0),
(179, 17, '2014-03-05', 0, 0, 0, 0, 0, 0, 0),
(180, 17, '2014-03-06', 0, 0, 0, 0, 0, 0, 0),
(181, 17, '2014-03-07', 0, 0, 0, 0, 0, 0, 0),
(182, 17, '2014-03-08', 0, 0, 0, 0, 0, 0, 0),
(183, 17, '2014-03-09', 0, 0, 0, 0, 0, 0, 0),
(184, 17, '2014-03-10', 0, 0, 0, 0, 0, 0, 0),
(185, 17, '2014-03-11', 0, 0, 0, 0, 0, 0, 0),
(186, 17, '2014-03-12', 0, 0, 0, 0, 0, 0, 0),
(187, 17, '2014-03-13', 500, 15, 3490000, 50000, 3000000, 875000, 3950000),
(188, 17, '2014-03-14', 500, 30, 3400000, 950000, 0, 1705000, 3000000),
(189, 17, '2014-03-15', 6040, 0, 2000000, 0, 0, 52360000, 0),
(190, 17, '2014-03-16', 0, 0, 0, 0, 0, 0, 0),
(191, 17, '2014-03-17', 0, 0, 0, 0, 0, 0, 0),
(192, 17, '2014-03-18', 0, 0, 0, 0, 0, 0, 0),
(193, 17, '2014-03-19', 0, 0, 0, 0, 0, 0, 0),
(194, 17, '2014-03-20', 0, 0, 0, 0, 0, 0, 0),
(195, 17, '2014-03-21', 0, 0, 0, 0, 0, 0, 0),
(196, 17, '2014-03-22', 0, 0, 0, 0, 0, 0, 0),
(197, 17, '2014-03-23', 0, 0, 0, 0, 0, 0, 0),
(198, 17, '2014-03-24', 0, 0, 0, 0, 0, 0, 0),
(199, 17, '2014-03-25', 0, 0, 0, 0, 0, 0, 0),
(200, 17, '2014-03-26', 0, 0, 0, 0, 0, 0, 0),
(201, 17, '2014-03-27', 0, 0, 0, 0, 0, 0, 0),
(202, 17, '2014-03-28', 0, 0, 0, 0, 0, 0, 0),
(203, 17, '2014-03-29', 0, 0, 0, 0, 0, 0, 0),
(204, 17, '2014-03-30', 0, 0, 0, 0, 0, 0, 0),
(205, 17, '2014-03-31', 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_user`
--

CREATE TABLE IF NOT EXISTS `shopc_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `shopc_user`
--

INSERT INTO `shopc_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `shopc_customer`
--
ALTER TABLE `shopc_customer`
  ADD CONSTRAINT `shopc_customer_ibfk_1` FOREIGN KEY (`id_domain`) REFERENCES `shopc_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_image`
--
ALTER TABLE `shopc_image`
  ADD CONSTRAINT `shopc_image_ibfk_1` FOREIGN KEY (`idresource`) REFERENCES `shopc_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_order_import`
--
ALTER TABLE `shopc_order_import`
  ADD CONSTRAINT `shopc_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `shopc_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_order_import_detail`
--
ALTER TABLE `shopc_order_import_detail`
  ADD CONSTRAINT `shopc_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `shopc_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `shopc_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `shopc_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_resource`
--
ALTER TABLE `shopc_resource`
  ADD CONSTRAINT `shopc_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `shopc_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
