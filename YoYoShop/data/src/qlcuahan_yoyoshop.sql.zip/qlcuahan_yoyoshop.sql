-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2014 at 09:53 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlcuahan_yoyoshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `shopc_category`
--

CREATE TABLE IF NOT EXISTS `shopc_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `shopc_category`
--

INSERT INTO `shopc_category` (`id`, `name`, `order`) VALUES
(1, 'Thời trang nam', 1),
(2, 'Thời trang nữ', 2),
(14, 'Thời trang bé', 3);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_category1`
--

CREATE TABLE IF NOT EXISTS `shopc_category1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `shopc_category1`
--

INSERT INTO `shopc_category1` (`id`, `id_category`, `name`, `order`) VALUES
(1, 1, 'Sơ mi', 2),
(2, 1, 'Áo thun', 0),
(3, 2, 'Váy', 0),
(4, 2, 'đầm', 0),
(5, 2, 'đổ ngủ', 0),
(6, 2, 'áo tắm', 0),
(7, 14, '1 tháng tuổi', 0),
(8, 14, '3 tháng tuổi', 0),
(9, 14, '1 tuổi', 0),
(10, 14, '2 tuổi', 0),
(11, 14, '3 tuổi', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_config`
--

CREATE TABLE IF NOT EXISTS `shopc_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `shopc_config`
--

INSERT INTO `shopc_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '1'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'SHOP BÁN QUẦN ÁO'),
(11, 'ADDRESS', 'TP HCM'),
(12, 'PHONE', '0919 153 189'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'N_MONTH_LOG', '1'),
(17, 'PRICE1', '9000'),
(18, 'PRICE2', '8700'),
(19, 'EVERY_5_MINUTES', '2000');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_customer`
--

CREATE TABLE IF NOT EXISTS `shopc_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  `id_domain` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_domain` (`id_domain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=217 ;

--
-- Dumping data for table `shopc_customer`
--

INSERT INTO `shopc_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`, `id_domain`) VALUES
(14, 'Anh Đông', 0, '', '', '', '', 0, 4),
(15, 'Anh Hùng', 0, '', '', '', '', 0, 4),
(16, 'Anh Nghĩa', 0, '', '', '', '', 0, 4),
(17, 'Nghĩa', 0, '', '', '', '', 0, 4),
(18, 'Anh Cường', 0, '', '', '', '', 0, 4),
(19, 'Anh Tông', 0, '', '', '', '', 0, 4),
(20, 'Chú Bảy', 0, '', '', '', '', 0, 4),
(21, 'Dì Mước', 0, '', '', '', '', 0, 4),
(22, 'Chị Phương Đò', 0, '', '', '', '', 0, 4),
(23, 'Chị Hồng CT', 0, '', '', '', '', 0, 4),
(24, 'Chị Nương', 0, '', '', '', '', 0, 4),
(25, 'Duyên', 0, '', '', '', '', 0, 4),
(26, 'Dì Cúc', 0, '', '', '', '', 0, 4),
(27, 'dì Hai', 0, '', '', '', '', 0, 4),
(28, 'Dì Năm', 0, '', '', '', '', 0, 4),
(29, 'Chị Út', 0, '', '', '', '', 0, 4),
(30, 'Dì Mười', 0, '', '', '', '', 0, 4),
(31, 'Dì Rùa', 0, '', '', '', '', 0, 4),
(32, 'Chị Sa', 0, '', '', '', '', 0, 4),
(33, 'Dì Út Lan', 0, '', '', '', '', 0, 4),
(34, 'Dì Chín CT', 0, '', '', '', '', 0, 4),
(35, 'Chị Hồ', 0, '', '', '', '', 0, 4),
(36, 'Chị Quyên', 0, '', '', '', '', 0, 4),
(37, 'Dì Thạch', 0, '', '', '', '', 0, 4),
(38, 'Anh Lập', 0, '', '', '', '', 0, 4),
(39, 'Chú Nhơn', 0, '', '', '', '', 0, 4),
(40, 'Dì Lan', 0, '', '', '', '', 0, 4),
(41, 'Chú Hữu', 0, '', '', '', '', 0, 4),
(42, 'Tậm Địa', 0, '', '', '', '', 0, 4),
(43, 'Dì Muối', 0, '', '', '', '', 0, 4),
(44, 'Chị Xuân', 0, '', '', '', '', 0, 4),
(45, 'Lượm', 0, '', '', '', '', 0, 4),
(46, 'Chị Tiên', 0, '', '', '', '', 0, 4),
(47, 'Diì Ba Lợi', 0, '', '', '', '', 0, 4),
(48, 'Út lùn', 0, '', '', '', '', 0, 4),
(49, 'Dì Luyến', 0, '', '', '', '', 0, 4),
(50, 'Dì Bảy', 0, '', '', '', '', 0, 4),
(51, 'Dì Tám', 0, '', '', '', '', 0, 4),
(52, 'Chú Ngợi', 0, '', '', '', '', 0, 4),
(53, 'Chú Trung', 0, '', '', '', '', 0, 4),
(54, 'Nhã', 0, '', '', '', '', 0, 4),
(55, 'Thuận', 0, '', '', '', '', 0, 4),
(56, 'Bé Lan', 0, '', '', '', '', 0, 4),
(57, 'Chị Sáu', 0, '', '', '', '', 0, 4),
(58, 'Anh An', 0, '', '', '', '', 0, 4),
(59, 'Chú Tuấn', 0, '', '', '', '', 0, 4),
(60, 'Chú Gấm', 0, '', '', '', '', 0, 4),
(61, 'Ngũ', 0, '', '', '', '', 0, 4),
(62, 'Ốc Bu', 0, '', '', '', '', 0, 4),
(63, 'Chị Chín Thiện', 0, '', '', '', '', 0, 4),
(64, 'Chị Thu', 0, '', '', '', '', 0, 4),
(65, 'Giang', 0, '', '', '', '', 0, 4),
(66, 'Chú Hủ', 0, '', '', '', '', 0, 4),
(67, 'Dì Hiền', 0, '', '', '', '', 0, 4),
(68, 'Trang', 0, '', '', '', '', 0, 4),
(69, 'Anh Út Đình', 0, '', '', '', '', 0, 4),
(70, 'Chú Út', 0, '', '', '', '', 0, 4),
(71, 'Chị Gái', 0, '', '', '', '', 0, 4),
(72, 'Chị Diễm', 0, '', '', '', '', 0, 4),
(73, 'Chị Loan', 0, '', '', '', '', 0, 4),
(74, 'Anh Gấu', 0, '', '', '', '', 0, 4),
(75, 'Chú Tư', 0, '', '', '', '', 0, 1),
(76, 'Chú Hai', 0, '', '', '', '', 0, 1),
(77, 'Dì Hồng', 0, '', '', '', '', 0, 1),
(78, 'Dì Thoa', 0, '', '', '', '', 0, 1),
(79, 'Dì Đẹp', 0, '', '', '', '', 0, 1),
(80, 'Chị Muối', 0, '', '', '', '', 0, 1),
(81, 'Dì Bé', 0, '', '', '', '', 0, 1),
(82, 'Dì Út', 0, '', '', '', '', 0, 1),
(83, 'Chị Mai', 0, '', '', '', '', 0, 1),
(84, 'Chị Thảo', 0, '', '', '', '', 0, 1),
(85, 'Chị Thảo Lùn', 0, '', '', '', '', 0, 1),
(86, 'Chị Thanh', 0, '', '', '', '', 0, 1),
(87, 'Chị Thủy', 0, '', '', '', '', 0, 1),
(88, 'Dì Vân', 0, '', '', '', '', 0, 1),
(89, 'Dì Haà', 0, '', '', '', '', 0, 1),
(90, 'Dì Thủy', 0, '', '', '', '', 0, 1),
(91, 'Dì Mỹ', 0, '', '', '', '', 0, 1),
(92, 'Dì Chín', 0, '', '', '', '', 0, 1),
(93, 'Chú Hiếu', 0, '', '', '', '', 0, 1),
(94, 'Dì Bông', 0, '', '', '', '', 0, 1),
(95, 'Chị Gái', 0, '', '', '', '', 0, 1),
(96, 'Dì Út Cái Gia', 0, '', '', '', '', 0, 1),
(97, 'Dì Hoa', 0, '', '', '', '', 0, 1),
(98, 'Dì Liên', 0, '', '', '', '', 0, 1),
(99, 'Chị Hồng Cái Gia', 0, '', '', '', '', 0, 1),
(100, 'Chị Cẩm', 0, '', '', '', '', 0, 1),
(101, 'Chị Thảo', 0, '', '', '', '', 0, 1),
(102, 'Dì Năm', 0, '', '', '', '', 0, 1),
(103, 'Chị Hiền', 0, '', '', '', '', 0, 1),
(104, 'Chị Vân', 0, '', '', '', '', 0, 1),
(105, 'Chú Thắng', 0, '', '', '', '', 0, 2),
(106, 'Chú Tâm', 0, '', '', '', '', 0, 2),
(107, 'Dũng', 0, '', '', '', '', 0, 2),
(108, 'Chú Bảy', 0, '', '', '', '', 0, 2),
(109, 'Anh Hùng', 0, '', '', '', '', 0, 2),
(110, 'Dì Bảy Sông Dưa', 0, '', '', '', '', 0, 2),
(111, 'Dung', 0, '', '', '', '', 0, 2),
(112, 'Chị Thúy', 0, '', '', '', '', 0, 2),
(113, 'Lan', 0, '', '', '', '', 0, 2),
(114, 'Dì Thủy Sông Dưa', 0, '', '', '', '', 0, 2),
(115, 'Chị Hạnh', 0, '', '', '', '', 0, 2),
(116, 'Chị Ánh', 0, '', '', '', '', 0, 2),
(117, 'Dì Hợp', 0, '', '', '', '', 0, 2),
(118, 'Dì Sáu Dân', 0, '', '', '', '', 0, 2),
(119, 'Anh Hiển', 0, '', '', '', '', 0, 2),
(120, 'Anh Hiều', 0, '', '', '', '', 0, 2),
(121, 'Anh Tí', 0, '', '', '', '', 0, 2),
(122, 'Chị Phươc', 0, '', '', '', '', 0, 2),
(123, 'Chú Hiếu', 0, '', '', '', '', 0, 2),
(124, 'Anh Út Mù U', 0, '', '', '', '', 0, 2),
(125, 'Bé Hai', 0, '', '', '', '', 0, 2),
(126, 'Nguyên', 0, '', '', '', '', 0, 2),
(127, 'Chị Hoa Bến Đò Tứ Phước	', 0, '', '', '', '', 0, 2),
(128, 'Dì Sáu Lực', 0, '', '', '', '', 0, 2),
(129, 'Dì Dung', 0, '', '', '', '', 0, 2),
(130, 'Chị Thư', 0, '', '', '', '', 0, 2),
(131, 'Dì Lợi', 0, '', '', '', '', 0, 2),
(132, 'Dì Hương', 0, '', '', '', '', 0, 2),
(133, 'Dì Thoa', 0, '', '', '', '', 0, 2),
(134, 'Sĩ', 0, '', '', '', '', 0, 2),
(135, 'Chị Sương', 0, '', '', '', '', 0, 2),
(136, 'Chị Nu', 0, '', '', '', '', 0, 2),
(137, 'Phượng', 0, '', '', '', '', 0, 2),
(138, 'Má Phượng', 0, '', '', '', '', 0, 2),
(139, 'Chị Hiền', 0, '', '', '', '', 0, 2),
(140, 'Thúy Diệp', 0, '', '', '', '', 0, 2),
(141, 'Anh Tuấn', 0, '', '', '', '', 0, 2),
(142, 'Dì Hai Bán Bông', 0, '', '', '', '', 0, 2),
(143, 'Chị Thủy', 0, '', '', '', '', 0, 2),
(144, 'Dì Hai Tân Xuân	', 0, '', '', '', '', 0, 2),
(145, 'Chị Thuận', 0, '', '', '', '', 0, 2),
(146, 'Chị Đào', 0, '', '', '', '', 0, 2),
(147, 'Dì Ba Hồng', 0, '', '', '', '', 0, 2),
(148, 'Loan Đại', 0, '', '', '', '', 0, 2),
(149, 'Chú Hai Tèo', 0, '', '', '', '', 0, 2),
(150, 'Dì Mum', 0, '', '', '', '', 0, 2),
(151, 'Dì Mận', 0, '', '', '', '', 0, 2),
(152, 'Dì Sáu Hang Mai', 0, '', '', '', '', 0, 2),
(153, 'Chị Hồng', 0, '', '', '', '', 0, 2),
(154, 'Cúc', 0, '', '', '', '', 0, 2),
(155, 'Chị Chín Mổ', 0, '', '', '', '', 0, 2),
(156, 'Dì Thủy Đại', 0, '', '', '', '', 0, 2),
(157, 'Chị Giao', 0, '', '', '', '', 0, 2),
(158, 'Chú Lắm', 0, '', '', '', '', 0, 2),
(159, 'Dì Vân', 0, '', '', '', '', 0, 2),
(160, 'Chị Nhiều', 0, '', '', '', '', 0, 2),
(161, 'Chú Hai Đường', 0, '', '', '', '', 0, 2),
(162, 'Dì Hiền', 0, '', '', '', '', 0, 2),
(163, 'Anh Tâm', 0, '', '', '', '', 0, 2),
(164, 'Dì Năm Cá', 0, '', '', '', '', 0, 2),
(165, 'Chị Hạnh Tân Xuân', 0, '', '', '', '', 0, 2),
(166, 'Chị Thúy Tân Xuân', 0, '', '', '', '', 0, 2),
(167, 'Dì Chi', 0, '', '', '', '', 0, 2),
(168, 'Lâu', 0, '', '', '', '', 0, 2),
(169, 'Chị Thu', 0, '', '', '', '', 0, 2),
(170, 'Chị Hồng Sáu Tước', 0, '', '', '', '', 0, 2),
(171, 'Chị Dung Ba Mun', 0, '', '', '', '', 0, 2),
(172, 'Chị Đào', 0, '', '', '', '', 0, 2),
(173, 'Dì Sáu Hỉ', 0, '', '', '', '', 0, 2),
(174, 'Chú Quí', 0, '', '', '', '', 0, 2),
(175, 'Chị Sương', 0, '', '', '', '', 0, 2),
(176, 'Chú Hoàng', 0, '', '', '', '', 0, 2),
(177, 'Chị Bé Ba', 0, '', '', '', '', 0, 2),
(178, 'Anh Hóa', 0, '', '', '', '', 0, 3),
(179, 'Nhí', 0, '', '', '', '', 0, 3),
(180, 'Chị Ly', 0, '', '', '', '', 0, 3),
(181, 'Dì Năm', 0, '', '', '', '', 0, 3),
(182, 'Diễm', 0, '', '', '', '', 0, 3),
(183, 'Dì Bảy', 0, '', '', '', '', 0, 3),
(184, 'Dì Oanh Sàn', 0, '', '', '', '', 0, 3),
(185, 'Dì Oanh Mía', 0, '', '', '', '', 0, 3),
(186, 'Chị Bé Hai', 0, '', '', '', '', 0, 3),
(187, 'Dì Hai', 0, '', '', '', '', 0, 3),
(188, 'Chị Loan', 0, '', '', '', '', 0, 3),
(189, 'Chị Hồng Thanh Phụng', 0, '', '', '', '', 0, 3),
(190, 'Chị Diệu', 0, '', '', '', '', 0, 3),
(191, 'Giang', 0, '', '', '', '', 0, 3),
(192, 'Anh Lâm', 0, '', '', '', '', 0, 3),
(193, 'Chú Nhân', 0, '', '', '', '', 0, 3),
(194, 'Dì Hoa', 0, '', '', '', '', 0, 3),
(195, 'Chú Ba', 0, '', '', '', '', 0, 3),
(196, 'Chú Nở', 0, '', '', '', '', 0, 3),
(197, 'Chị Chín', 0, '', '', '', '', 0, 3),
(198, 'Nhi Đồng', 0, '', '', '', '', 0, 3),
(199, 'Chị Út', 0, '', '', '', '', 0, 3),
(200, 'Chú Cụ', 0, '', '', '', '', 0, 3),
(201, 'Chị Trang', 0, '', '', '', '', 0, 3),
(202, 'Chị Bé Tư', 0, '', '', '', '', 0, 3),
(203, 'Chị Lem', 0, '', '', '', '', 0, 3),
(204, 'Anh Nam', 0, '', '', '', '', 0, 3),
(205, 'Chị Phường', 0, '', '', '', '', 0, 3),
(206, 'Phương', 0, '', '', '', '', 0, 3),
(207, 'Trúc', 0, '', '', '', '', 0, 3),
(208, 'Chị Năm', 0, '', '', '', '', 0, 3),
(209, 'Thảo', 0, '', '', '', '', 0, 3),
(210, 'Dì Út Huệ', 0, '', '', '', '', 0, 3),
(211, 'Chị Diệu', 0, '', '', '', '', 0, 3),
(212, 'Dì Bê', 0, '', '', '', '', 0, 5),
(213, 'Hạnh', 0, '', '', '', '', 0, 5),
(214, 'Thái', 0, '', '', '', '', 0, 5),
(215, 'Anh Thịnh', 0, '', '', '', '', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_domain`
--

CREATE TABLE IF NOT EXISTS `shopc_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `shopc_domain`
--

INSERT INTO `shopc_domain` (`id`, `name`) VALUES
(1, 'Mỹ Thuận'),
(2, 'Nha Mân'),
(3, 'Sa Đéc'),
(4, 'Cái Tàu'),
(5, 'Vĩnh Long');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_employee`
--

CREATE TABLE IF NOT EXISTS `shopc_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `shopc_employee`
--

INSERT INTO `shopc_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(2, 'Nhân viên', 'Bán hàng', 1, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_guest`
--

CREATE TABLE IF NOT EXISTS `shopc_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `shopc_guest`
--

INSERT INTO `shopc_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_order_import`
--

CREATE TABLE IF NOT EXISTS `shopc_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopc_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=363 ;

--
-- Dumping data for table `shopc_order_import`
--

INSERT INTO `shopc_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(362, 8, '2014-03-14', '');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `shopc_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopc_order_import_detail_1` (`idorder`),
  KEY `shopc_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=658 ;

--
-- Dumping data for table `shopc_order_import_detail`
--

INSERT INTO `shopc_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(657, 362, 19, 2000, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_resource`
--

CREATE TABLE IF NOT EXISTS `shopc_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopc_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `shopc_resource`
--

INSERT INTO `shopc_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(19, 8, 'Tờ 10.000 đồng', 'Tờ', 10000, '');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_supplier`
--

CREATE TABLE IF NOT EXISTS `shopc_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `shopc_supplier`
--

INSERT INTO `shopc_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(8, 'Nhà cung cấp 1', '0703 111 222', 'Q3 TPHCM', '', 0),
(9, 'Nhà cung cấp 2', '', 'Q4 TPHCM', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_tracking`
--

CREATE TABLE IF NOT EXISTS `shopc_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `shopc_tracking`
--

INSERT INTO `shopc_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(17, '2014-03-01', '2014-03-31', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `shopc_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `ticket1` bigint(20) NOT NULL,
  `ticket2` bigint(20) NOT NULL,
  `paid1` bigint(20) NOT NULL,
  `paid2` bigint(20) NOT NULL,
  `debt` bigint(20) NOT NULL,
  `paid1_remain` bigint(11) NOT NULL,
  `paid2_remain` bigint(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=206 ;

--
-- Dumping data for table `shopc_tracking_daily`
--

INSERT INTO `shopc_tracking_daily` (`id`, `id_tracking`, `date`, `ticket1`, `ticket2`, `paid1`, `paid2`, `debt`, `paid1_remain`, `paid2_remain`) VALUES
(147, 16, '2014-02-01', 0, 0, 0, 0, 0, 0, 0),
(148, 16, '2014-02-02', 0, 0, 0, 0, 0, 0, 0),
(149, 16, '2014-02-03', 0, 0, 0, 0, 0, 0, 0),
(150, 16, '2014-02-04', 0, 0, 0, 0, 0, 0, 0),
(151, 16, '2014-02-05', 0, 0, 0, 0, 0, 0, 0),
(152, 16, '2014-02-06', 0, 0, 0, 0, 0, 0, 0),
(153, 16, '2014-02-07', 0, 0, 0, 0, 0, 0, 0),
(154, 16, '2014-02-08', 0, 0, 0, 0, 0, 0, 0),
(155, 16, '2014-02-09', 0, 0, 0, 0, 0, 0, 0),
(156, 16, '2014-02-10', 0, 0, 0, 0, 0, 0, 0),
(157, 16, '2014-02-11', 0, 0, 0, 0, 0, 0, 0),
(158, 16, '2014-02-12', 0, 0, 0, 0, 0, 0, 0),
(159, 16, '2014-02-13', 0, 0, 0, 0, 0, 0, 0),
(160, 16, '2014-02-14', 0, 0, 0, 0, 0, 0, 0),
(161, 16, '2014-02-15', 0, 0, 0, 0, 0, 0, 0),
(162, 16, '2014-02-16', 0, 0, 0, 0, 0, 0, 0),
(163, 16, '2014-02-17', 0, 0, 0, 0, 0, 0, 0),
(164, 16, '2014-02-18', 0, 0, 0, 0, 0, 0, 0),
(165, 16, '2014-02-19', 0, 0, 0, 0, 0, 0, 0),
(166, 16, '2014-02-20', 0, 0, 0, 0, 0, 0, 0),
(167, 16, '2014-02-21', 0, 0, 0, 0, 0, 0, 0),
(168, 16, '2014-02-22', 0, 0, 0, 0, 0, 0, 0),
(169, 16, '2014-02-23', 0, 0, 0, 0, 0, 0, 0),
(170, 16, '2014-02-24', 0, 0, 0, 0, 0, 0, 0),
(171, 16, '2014-02-25', 0, 0, 0, 0, 0, 0, 0),
(172, 16, '2014-02-26', 0, 0, 0, 0, 0, 0, 0),
(173, 16, '2014-02-27', 56000, 0, 0, 0, 0, 0, 0),
(174, 16, '2014-02-28', 0, 0, 0, 0, 0, 0, 0),
(175, 17, '2014-03-01', 0, 0, 0, 0, 0, 0, 0),
(176, 17, '2014-03-02', 0, 0, 0, 0, 0, 0, 0),
(177, 17, '2014-03-03', 0, 0, 0, 0, 0, 0, 0),
(178, 17, '2014-03-04', 0, 0, 0, 0, 0, 0, 0),
(179, 17, '2014-03-05', 0, 0, 0, 0, 0, 0, 0),
(180, 17, '2014-03-06', 0, 0, 0, 0, 0, 0, 0),
(181, 17, '2014-03-07', 0, 0, 0, 0, 0, 0, 0),
(182, 17, '2014-03-08', 0, 0, 0, 0, 0, 0, 0),
(183, 17, '2014-03-09', 0, 0, 0, 0, 0, 0, 0),
(184, 17, '2014-03-10', 0, 0, 0, 0, 0, 0, 0),
(185, 17, '2014-03-11', 0, 0, 0, 0, 0, 0, 0),
(186, 17, '2014-03-12', 0, 0, 0, 0, 0, 0, 0),
(187, 17, '2014-03-13', 500, 15, 3490000, 50000, 3000000, 875000, 3950000),
(188, 17, '2014-03-14', 500, 30, 3400000, 950000, 0, 1705000, 3000000),
(189, 17, '2014-03-15', 6040, 0, 2000000, 0, 0, 52360000, 0),
(190, 17, '2014-03-16', 0, 0, 0, 0, 0, 0, 0),
(191, 17, '2014-03-17', 0, 0, 0, 0, 0, 0, 0),
(192, 17, '2014-03-18', 0, 0, 0, 0, 0, 0, 0),
(193, 17, '2014-03-19', 0, 0, 0, 0, 0, 0, 0),
(194, 17, '2014-03-20', 0, 0, 0, 0, 0, 0, 0),
(195, 17, '2014-03-21', 0, 0, 0, 0, 0, 0, 0),
(196, 17, '2014-03-22', 0, 0, 0, 0, 0, 0, 0),
(197, 17, '2014-03-23', 0, 0, 0, 0, 0, 0, 0),
(198, 17, '2014-03-24', 0, 0, 0, 0, 0, 0, 0),
(199, 17, '2014-03-25', 0, 0, 0, 0, 0, 0, 0),
(200, 17, '2014-03-26', 0, 0, 0, 0, 0, 0, 0),
(201, 17, '2014-03-27', 0, 0, 0, 0, 0, 0, 0),
(202, 17, '2014-03-28', 0, 0, 0, 0, 0, 0, 0),
(203, 17, '2014-03-29', 0, 0, 0, 0, 0, 0, 0),
(204, 17, '2014-03-30', 0, 0, 0, 0, 0, 0, 0),
(205, 17, '2014-03-31', 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_user`
--

CREATE TABLE IF NOT EXISTS `shopc_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `shopc_user`
--

INSERT INTO `shopc_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `shopc_customer`
--
ALTER TABLE `shopc_customer`
  ADD CONSTRAINT `shopc_customer_ibfk_1` FOREIGN KEY (`id_domain`) REFERENCES `shopc_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_order_import`
--
ALTER TABLE `shopc_order_import`
  ADD CONSTRAINT `shopc_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `shopc_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_order_import_detail`
--
ALTER TABLE `shopc_order_import_detail`
  ADD CONSTRAINT `shopc_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `shopc_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `shopc_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `shopc_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_resource`
--
ALTER TABLE `shopc_resource`
  ADD CONSTRAINT `shopc_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `shopc_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
