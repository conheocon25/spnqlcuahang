-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 11, 2014 at 09:36 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_qlcuahang_hdncomputer`
--

-- --------------------------------------------------------

--
-- Table structure for table `shopc_category`
--

CREATE TABLE IF NOT EXISTS `shopc_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `shopc_category`
--

INSERT INTO `shopc_category` (`id`, `name`, `key`, `order`) VALUES
(1, 'Linh kiện và Phụ kiện', 'linh-kien-va-phu-kien', 1),
(14, 'Dịch vụ', 'dich-vu', 3);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_category1`
--

CREATE TABLE IF NOT EXISTS `shopc_category1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_category` (`id_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `shopc_category1`
--

INSERT INTO `shopc_category1` (`id`, `id_category`, `name`, `key`, `order`) VALUES
(12, 1, 'Linh kiện', 'linh-kien', 0),
(13, 1, 'Phụ kiện', 'phu-kien', 0),
(14, 14, 'Bảo dưỡng máy tính', 'bao-duong-may-tinh', 0),
(15, 14, 'Sửa chữa, bảo trì máy tính', 'sua-chua-bao-tri-may-tinh', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_config`
--

CREATE TABLE IF NOT EXISTS `shopc_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=31 ;

--
-- Dumping data for table `shopc_config`
--

INSERT INTO `shopc_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '1'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'HDN COMPUTER'),
(11, 'ADDRESS', '399D/31 Ấp Phước Yên A, Phú Quới, Long Hồ, Vĩnh Long'),
(12, 'PHONE', '094 490 6467'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'POST_POLICY', '5'),
(19, 'EVERY_5_MINUTES', '2000'),
(22, 'SLOGAN', 'Uy Tin - Chất Lượng - Nhiệt Tình'),
(23, 'POST_INTRODUCTION', '1'),
(24, 'POST_FAQ', '4'),
(28, 'POST_POLICY', '5'),
(29, 'N_MONTH_LOG', '1'),
(30, 'PRESENTATION_HOME', '2');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_customer`
--

CREATE TABLE IF NOT EXISTS `shopc_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `shopc_customer`
--

INSERT INTO `shopc_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_domain`
--

CREATE TABLE IF NOT EXISTS `shopc_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `shopc_domain`
--

INSERT INTO `shopc_domain` (`id`, `name`) VALUES
(1, 'Mỹ Thuận'),
(2, 'Nha Mân'),
(3, 'Sa Đéc'),
(4, 'Cái Tàu'),
(5, 'Vĩnh Long');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_employee`
--

CREATE TABLE IF NOT EXISTS `shopc_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `shopc_employee`
--

INSERT INTO `shopc_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(2, 'Nhân viên', 'Bán hàng', 1, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_guest`
--

CREATE TABLE IF NOT EXISTS `shopc_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `shopc_guest`
--

INSERT INTO `shopc_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_image`
--

CREATE TABLE IF NOT EXISTS `shopc_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idresource` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `url` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idresource` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `shopc_image`
--

INSERT INTO `shopc_image` (`id`, `idresource`, `name`, `date`, `url`) VALUES
(11, 27, 'CHUỘT MITSUMI', '2014-04-08 00:00:00', 'http://quangcaoad.com/views/uploads/chuot-mitsumi-quang-su7-2-mau.jpg'),
(12, 28, 'Loa Xí Ngầu', '2014-04-08 00:00:00', 'http://fyi.vn/data/img_product/500/loa-xi-ngau-mini-20-2.png'),
(13, 29, '1 NĂM BẢO TRÌ MÁY TÍNH', '2014-04-08 00:00:00', 'http://www.maytinhkimoanh.com.vn/Images/News/Sub/images/Btri.jpg'),
(14, 30, 'PHỤ VỤ TẬN NƠI', '2014-04-08 00:00:00', 'http://suachuabaotrimaytinh.vn/upload/A%20UP/sua%20laptop%20tai%20nha.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_order_export`
--

CREATE TABLE IF NOT EXISTS `shopc_order_export` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `shopc_order_export`
--

INSERT INTO `shopc_order_export` (`id`, `idcustomer`, `date`, `note`) VALUES
(1, 1, '2014-04-06 00:00:00', 'abc'),
(4, 1, '2014-04-06 10:04:00', 'hóa đon bán lẻ');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_order_export_detail`
--

CREATE TABLE IF NOT EXISTS `shopc_order_export_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `shopc_order_export_detail`
--

INSERT INTO `shopc_order_export_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(1, 1, 19, 5, 250000),
(2, 1, 23, 2, 100000),
(3, 4, 20, 3, 112000),
(4, 4, 28, 1, 90000),
(5, 4, 27, 2, 40000),
(6, 4, 29, 1, 95000);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_order_import`
--

CREATE TABLE IF NOT EXISTS `shopc_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopc_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=364 ;

--
-- Dumping data for table `shopc_order_import`
--

INSERT INTO `shopc_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(363, 9, '2014-04-08', '');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `shopc_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopc_order_import_detail_1` (`idorder`),
  KEY `shopc_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=665 ;

--
-- Dumping data for table `shopc_order_import_detail`
--

INSERT INTO `shopc_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(661, 363, 27, 5, 25000),
(662, 363, 28, 5, 60000),
(663, 363, 29, 5, 0),
(664, 363, 30, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_post`
--

CREATE TABLE IF NOT EXISTS `shopc_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `shopc_post`
--

INSERT INTO `shopc_post` (`id`, `title`, `content`, `key`) VALUES
(1, 'Giới thiệu', '<p>\r\n	<strong>HDN Computer</strong></p>\r\n<p>\r\n	<strong>ĐC: 399D/31 Ấp Phước Y&ecirc;n A, Ph&uacute; Quới, Long Hồ, Vĩnh Long.</strong></p>\r\n<p>\r\n	<strong>ĐT: 094 490 6467</strong></p>\r\n<p>\r\n	<strong>Email: </strong><a href="mailto:quihuu1990@gmail.com"><strong>quihuu1990@gmail.com</strong></a></p>\r\n', 'gioi-thieu-1396971404'),
(4, 'FAQ', '<p>\r\n	C&aacute;c c&acirc;u hỏi thường gặp được viết chi tiết ở đ&acirc;y.</p>\r\n', 'faq-1395727808'),
(5, 'Chính sách', '<h3 style="text-align: justify;">\r\n	Ch&iacute;nh s&aacute;ch đổi trả h&agrave;ng v&agrave; ho&agrave;n tiền tại l&agrave; như thế n&agrave;o?</h3>\r\n<div style="text-align: justify;">\r\n	Khi mua sắm với Shop, qu&yacute; kh&aacute;ch c&oacute; thể đổi trả h&agrave;ng h&oacute;a trong v&ograve;ng 30 ng&agrave;y kể từ ng&agrave;y nhận h&agrave;ng, qu&yacute; kh&aacute;ch vui l&ograve;ng tham khảo th&ocirc;ng tin chi tiết về ch&iacute;nh s&aacute;ch đổi trả h&agrave;ng h&oacute;a của tại:...</div>\r\n<div style="text-align: justify;">\r\n	<h3>\r\n		Quy định đổi trả h&agrave;ng của Shop l&agrave; g&igrave;?</h3>\r\n	<div>\r\n		Qu&yacute; kh&aacute;ch c&oacute; thể đổi trả sản phẩm trong v&ograve;ng 30 ng&agrave;y kể từ ng&agrave;y nhận được đơn h&agrave;ng:</div>\r\n	<ul>\r\n		<li>\r\n			Đối với sản phẩm bị lỗi sản xuất hoặc giao sai quy c&aacute;ch: Shop sẽ gửi sản phẩm mới, ho&agrave;n tiền v&agrave;o t&agrave;i khoản của qu&yacute; kh&aacute;ch hoặc ho&agrave;n m&atilde; tiền điện tử.</li>\r\n		<li>\r\n			Đối với những sản phẩm kh&ocirc;ng phải lỗi của nh&agrave; sản xuất mà do sản ph&acirc;̉m chưa phù hợp nhu c&acirc;̀u sử dụng của quý khách: Shop sẽ chỉ ho&agrave;n bằng m&atilde; tiền điện tử.</li>\r\n		<li>\r\n			Đối với những sản phẩm bị lỗi sau 30 ng&agrave;y kể từ ng&agrave;y nhận h&agrave;ng, qu&yacute; kh&aacute;ch vui l&ograve;ng li&ecirc;n hệ trực tiếp trung t&acirc;m bảo h&agrave;nh ch&iacute;nh h&atilde;ng của sản phẩm để được hỗ trợ ngay lập tức.</li>\r\n	</ul>\r\n	<div>\r\n		Lưu &yacute;: Th&ocirc;ng tin về quy định đổi trả qu&yacute; kh&aacute;ch c&oacute; thể tham khảo tại: ...</div>\r\n</div>\r\n<h3>\r\n	T&ocirc;i c&oacute; thể đổi trả sản phẩm sau 30 ng&agrave;y kể từ ng&agrave;y nhận h&agrave;ng kh&ocirc;ng?</h3>\r\n<div style="text-align: justify;">\r\n	Rất tiếc, trong trường hợp n&agrave;y, sản phẩm chỉ được hỗ trợ bảo h&agrave;nh. Ch&uacute;ng t&ocirc;i khuyến kh&iacute;ch qu&yacute; kh&aacute;ch li&ecirc;n hệ trực tiếp nh&agrave; sản xuất hoặc trung t&acirc;m bảo h&agrave;nh ch&iacute;nh h&atilde;ng để được hỗ trợ nhanh ch&oacute;ng.</div>\r\n<div style="text-align: justify;">\r\n	<h3>\r\n		Nếu t&ocirc;i cảm thấy sản phẩm đ&atilde; mua kh&ocirc;ng ph&ugrave; hợp nhu cầu sử dụng, liệu t&ocirc;i c&oacute; thể đổi sang sản phẩm kh&aacute;c kh&ocirc;ng?</h3>\r\n	<div>\r\n		Qu&yacute; kh&aacute;ch c&oacute; thể đổi trả sản phẩm trong v&ograve;ng 30 ng&agrave;y kể từ ng&agrave;y nhận h&agrave;ng v&agrave; phải đảm bảo qu&yacute; kh&aacute;ch vẫn c&ograve;n giữ h&oacute;a đơn mua h&agrave;ng, sản phẩm chưa c&oacute; dấu hiệu sử dụng, c&ograve;n nguy&ecirc;n t&igrave;nh trạng đ&oacute;ng g&oacute;i ban đầu hoặc ni&ecirc;m phong (nếu c&oacute;) v&agrave; đầy đủ phụ kiện hoặc quà tặng kèm theo (n&ecirc;́u có).</div>\r\n</div>\r\n<h3 style="text-align: justify;">\r\n	L&agrave;m thế n&agrave;o t&ocirc;i biết được sản phẩm c&oacute; bị lỗi sản phẩm hay kh&ocirc;ng trong khi kh&ocirc;ng kiểm tra n&oacute;?</h3>\r\n<div style="text-align: justify;">\r\n	Đừng qu&aacute; lo lắng về điều n&agrave;y. Nếu Lazada.vn gửi sản phẩm bị lỗi đến qu&yacute; kh&aacute;ch, ch&uacute;ng t&ocirc;i sẽ đổi sản phẩm mới cho qu&yacute; kh&aacute;ch m&agrave; kh&ocirc;ng tốn bất cứ chi ph&iacute; n&agrave;o hoặc ho&agrave;n trả lại tiền cho qu&yacute; kh&aacute;ch.</div>\r\n', 'chinh-sach-1395931412');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_presentation`
--

CREATE TABLE IF NOT EXISTS `shopc_presentation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `shopc_presentation`
--

INSERT INTO `shopc_presentation` (`id`, `name`, `order`, `key`) VALUES
(2, 'Trình bày 1', 1, 0),
(3, 'Trình bày 2', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_resource`
--

CREATE TABLE IF NOT EXISTS `shopc_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `idcategory` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `price1` int(12) NOT NULL,
  `price2` int(12) NOT NULL,
  `madein` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `madeby` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `style` int(11) NOT NULL,
  `canvas` int(11) NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopc_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=31 ;

--
-- Dumping data for table `shopc_resource`
--

INSERT INTO `shopc_resource` (`id`, `idsupplier`, `idcategory`, `name`, `code`, `price1`, `price2`, `madein`, `madeby`, `type`, `style`, `canvas`, `note`, `key`) VALUES
(27, 9, 12, 'Chuột mitsumi', '', 25000, 40000, 'Trung Quốc', 0, 0, 0, 0, '', 'chuot-mitsumi-1396972405'),
(28, 9, 13, 'Loa mini xí ngầu', '', 60000, 90000, 'Trung Quốc', 0, 0, 0, 0, '', 'loa-mini-xi-ngau-1396972446'),
(29, 9, 14, '1 Năm bảo trì máy tính', '', 0, 95000, 'Việt Nam', 0, 0, 0, 0, '', '1-nam-bao-tri-may-tinh-1396972596'),
(30, 9, 15, 'phụ vụ tận nơi', '', 0, 50000, 'Việt Nam', 0, 0, 0, 0, '', 'phu-vu-tan-noi-1396972645');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_save`
--

CREATE TABLE IF NOT EXISTS `shopc_save` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date1` date NOT NULL,
  `date2` date NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `shopc_save`
--

INSERT INTO `shopc_save` (`id`, `name`, `date1`, `date2`, `key`) VALUES
(1, 'Khuyến mãi tháng 3', '2014-03-27', '2014-03-31', 'khuyen-mai-thang-3');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_save_resource`
--

CREATE TABLE IF NOT EXISTS `shopc_save_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsave` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsave` (`idsave`),
  KEY `idresource` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `shopc_save_resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `shopc_slide`
--

CREATE TABLE IF NOT EXISTS `shopc_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idpresentation` int(11) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `shopc_slide`
--

INSERT INTO `shopc_slide` (`id`, `idpresentation`, `name`, `order`, `note`, `url`) VALUES
(1, 1, 'Hàng mới về', 1, 'Hàng mới về 2013', 'https://lh6.googleusercontent.com/-W0SWkx8AL24/Uy-irrEgv_I/AAAAAAAAA8Y/5bTIDivghLQ/s800/slider1.png'),
(2, 1, 'Bán chạy nhất', 2, 'Những hàng bán chạy nhất', 'https://lh4.googleusercontent.com/-jpsjoG4wL64/Uy-iw16t3lI/AAAAAAAAA8o/jlcuqg24ktY/s800/slider2.png'),
(3, 1, 'Bộ sưu tập mùa hè', 1, 'Bộ sưu tập mùa hè năm nay', 'https://lh6.googleusercontent.com/-yU_HBeMIY18/Uy-iu1GHBmI/AAAAAAAAA8g/efaDupRHia8/s800/slider3.png'),
(4, 2, 'Hang khuyen mai', 1, '', 'http://img.trananh.vn/trananh/2014/03/27/pop.png');

-- --------------------------------------------------------

--
-- Table structure for table `shopc_supplier`
--

CREATE TABLE IF NOT EXISTS `shopc_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `shopc_supplier`
--

INSERT INTO `shopc_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(9, 'Nhà cung cấp 1', '0919 22 44 33', 'Q4 TPHCM', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_tracking`
--

CREATE TABLE IF NOT EXISTS `shopc_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `shopc_tracking`
--

INSERT INTO `shopc_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(17, '2014-03-01', '2014-03-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(18, '2014-04-01', '2014-04-30', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `shopc_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `ticket1` bigint(20) NOT NULL,
  `ticket2` bigint(20) NOT NULL,
  `paid1` bigint(20) NOT NULL,
  `paid2` bigint(20) NOT NULL,
  `debt` bigint(20) NOT NULL,
  `paid1_remain` bigint(11) NOT NULL,
  `paid2_remain` bigint(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=206 ;

--
-- Dumping data for table `shopc_tracking_daily`
--

INSERT INTO `shopc_tracking_daily` (`id`, `id_tracking`, `date`, `ticket1`, `ticket2`, `paid1`, `paid2`, `debt`, `paid1_remain`, `paid2_remain`) VALUES
(147, 16, '2014-02-01', 0, 0, 0, 0, 0, 0, 0),
(148, 16, '2014-02-02', 0, 0, 0, 0, 0, 0, 0),
(149, 16, '2014-02-03', 0, 0, 0, 0, 0, 0, 0),
(150, 16, '2014-02-04', 0, 0, 0, 0, 0, 0, 0),
(151, 16, '2014-02-05', 0, 0, 0, 0, 0, 0, 0),
(152, 16, '2014-02-06', 0, 0, 0, 0, 0, 0, 0),
(153, 16, '2014-02-07', 0, 0, 0, 0, 0, 0, 0),
(154, 16, '2014-02-08', 0, 0, 0, 0, 0, 0, 0),
(155, 16, '2014-02-09', 0, 0, 0, 0, 0, 0, 0),
(156, 16, '2014-02-10', 0, 0, 0, 0, 0, 0, 0),
(157, 16, '2014-02-11', 0, 0, 0, 0, 0, 0, 0),
(158, 16, '2014-02-12', 0, 0, 0, 0, 0, 0, 0),
(159, 16, '2014-02-13', 0, 0, 0, 0, 0, 0, 0),
(160, 16, '2014-02-14', 0, 0, 0, 0, 0, 0, 0),
(161, 16, '2014-02-15', 0, 0, 0, 0, 0, 0, 0),
(162, 16, '2014-02-16', 0, 0, 0, 0, 0, 0, 0),
(163, 16, '2014-02-17', 0, 0, 0, 0, 0, 0, 0),
(164, 16, '2014-02-18', 0, 0, 0, 0, 0, 0, 0),
(165, 16, '2014-02-19', 0, 0, 0, 0, 0, 0, 0),
(166, 16, '2014-02-20', 0, 0, 0, 0, 0, 0, 0),
(167, 16, '2014-02-21', 0, 0, 0, 0, 0, 0, 0),
(168, 16, '2014-02-22', 0, 0, 0, 0, 0, 0, 0),
(169, 16, '2014-02-23', 0, 0, 0, 0, 0, 0, 0),
(170, 16, '2014-02-24', 0, 0, 0, 0, 0, 0, 0),
(171, 16, '2014-02-25', 0, 0, 0, 0, 0, 0, 0),
(172, 16, '2014-02-26', 0, 0, 0, 0, 0, 0, 0),
(173, 16, '2014-02-27', 56000, 0, 0, 0, 0, 0, 0),
(174, 16, '2014-02-28', 0, 0, 0, 0, 0, 0, 0),
(175, 17, '2014-03-01', 0, 0, 0, 0, 0, 0, 0),
(176, 17, '2014-03-02', 0, 0, 0, 0, 0, 0, 0),
(177, 17, '2014-03-03', 0, 0, 0, 0, 0, 0, 0),
(178, 17, '2014-03-04', 0, 0, 0, 0, 0, 0, 0),
(179, 17, '2014-03-05', 0, 0, 0, 0, 0, 0, 0),
(180, 17, '2014-03-06', 0, 0, 0, 0, 0, 0, 0),
(181, 17, '2014-03-07', 0, 0, 0, 0, 0, 0, 0),
(182, 17, '2014-03-08', 0, 0, 0, 0, 0, 0, 0),
(183, 17, '2014-03-09', 0, 0, 0, 0, 0, 0, 0),
(184, 17, '2014-03-10', 0, 0, 0, 0, 0, 0, 0),
(185, 17, '2014-03-11', 0, 0, 0, 0, 0, 0, 0),
(186, 17, '2014-03-12', 0, 0, 0, 0, 0, 0, 0),
(187, 17, '2014-03-13', 500, 15, 3490000, 50000, 3000000, 875000, 3950000),
(188, 17, '2014-03-14', 500, 30, 3400000, 950000, 0, 1705000, 3000000),
(189, 17, '2014-03-15', 6040, 0, 2000000, 0, 0, 52360000, 0),
(190, 17, '2014-03-16', 0, 0, 0, 0, 0, 0, 0),
(191, 17, '2014-03-17', 0, 0, 0, 0, 0, 0, 0),
(192, 17, '2014-03-18', 0, 0, 0, 0, 0, 0, 0),
(193, 17, '2014-03-19', 0, 0, 0, 0, 0, 0, 0),
(194, 17, '2014-03-20', 0, 0, 0, 0, 0, 0, 0),
(195, 17, '2014-03-21', 0, 0, 0, 0, 0, 0, 0),
(196, 17, '2014-03-22', 0, 0, 0, 0, 0, 0, 0),
(197, 17, '2014-03-23', 0, 0, 0, 0, 0, 0, 0),
(198, 17, '2014-03-24', 0, 0, 0, 0, 0, 0, 0),
(199, 17, '2014-03-25', 0, 0, 0, 0, 0, 0, 0),
(200, 17, '2014-03-26', 0, 0, 0, 0, 0, 0, 0),
(201, 17, '2014-03-27', 0, 0, 0, 0, 0, 0, 0),
(202, 17, '2014-03-28', 0, 0, 0, 0, 0, 0, 0),
(203, 17, '2014-03-29', 0, 0, 0, 0, 0, 0, 0),
(204, 17, '2014-03-30', 0, 0, 0, 0, 0, 0, 0),
(205, 17, '2014-03-31', 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopc_user`
--

CREATE TABLE IF NOT EXISTS `shopc_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `shopc_user`
--

INSERT INTO `shopc_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `shopc_category1`
--
ALTER TABLE `shopc_category1`
  ADD CONSTRAINT `shopc_category1_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `shopc_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_image`
--
ALTER TABLE `shopc_image`
  ADD CONSTRAINT `shopc_image_ibfk_1` FOREIGN KEY (`idresource`) REFERENCES `shopc_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_order_import`
--
ALTER TABLE `shopc_order_import`
  ADD CONSTRAINT `shopc_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `shopc_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_order_import_detail`
--
ALTER TABLE `shopc_order_import_detail`
  ADD CONSTRAINT `shopc_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `shopc_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `shopc_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `shopc_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_resource`
--
ALTER TABLE `shopc_resource`
  ADD CONSTRAINT `shopc_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `shopc_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopc_save_resource`
--
ALTER TABLE `shopc_save_resource`
  ADD CONSTRAINT `shopc_save_resource_ibfk_2` FOREIGN KEY (`idresource`) REFERENCES `shopc_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `shopc_save_resource_ibfk_1` FOREIGN KEY (`idsave`) REFERENCES `shopc_save` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
