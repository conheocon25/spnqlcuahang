-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 13, 2013 at 06:07 AM
-- Server version: 5.5.33-31.1
-- PHP Version: 5.3.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spngroup_cuahang_baduc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `picture`) VALUES
(1, 'Linh Tinh', NULL),
(2, 'Mỹ Phẩm', NULL),
(3, 'KEM', NULL),
(4, 'NƯỚC GIẢI KHÁT', NULL),
(5, 'THUỐC HÚT', NULL),
(6, 'THỨC ĂN', NULL),
(7, 'KHÁC', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_general`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_collect_general`
--

INSERT INTO `tbl_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(1, 2, '2013-10-01', 11, 'a1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'GUEST_VISIT', '13'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'THEME', 'grey'),
(8, 'EVERY_5_MINUTES', '2000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'KHÁCH VÃNG LAI', 0, '', '', '', '', 0),
(2, 'LÊ HỒNG ĐỨC', 0, '', '0918585203', 'Tân Hòa - An Nhơn - Châu Thành - Đồng Tháp', '', 0),
(3, 'NGUYỄN THÀNH TÀI', 0, '', '01636472769', 'Tân Hòa - An Nhơn - Châu Thành - Đồng Tháp', '', 0),
(4, 'CHUNG HOÀNG HÀ', 0, '', '', 'Tân Hòa - An Nhơn - Châu Thành - Đồng Tháp', '', 0),
(5, 'NGUYỄN VĂN BẢY', 0, '', '', 'Tân Hòa - An Nhơn - Châu Thành - Đồng Tháp', '', 0),
(6, 'Lê Nguyễn Đông Khoa', 1, '', '0945 030709', '', '', 0),
(7, 'PHẠM VĂN GIÚP', 0, '', '0918074988', '', '', 0),
(8, 'NGUYỄN THANH VŨ', 0, '', '01297909609', 'Tân Hòa - An Nhơn - Châu Thành - Đồng Tháp', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_customer_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_customer` int(11) NOT NULL,
  `id_domain` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_customer` (`id_customer`),
  KEY `id_domain` (`id_domain`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_customer_domain`
--

INSERT INTO `tbl_customer_domain` (`id`, `id_customer`, `id_domain`) VALUES
(3, 2, 1),
(4, 2, 2),
(6, 4, 1),
(7, 6, 2),
(8, 6, 1),
(9, 7, 1),
(10, 3, 1),
(11, 5, 1),
(12, 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_customer_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_customer` int(11) NOT NULL,
  `id_domain` int(11) NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_customer` (`id_customer`),
  KEY `id_domain` (`id_domain`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_customer_tracking`
--

INSERT INTO `tbl_customer_tracking` (`id`, `id_customer`, `id_domain`, `date_start`, `date_end`, `note`) VALUES
(1, 2, 1, '2013-11-01', '2013-12-31', 'AO SỐ 1 - Hùn với ? ? ? '),
(2, 2, 1, '2013-10-01', '2013-10-31', 'AO SỐ 2 - Hùn với ? ? ?'),
(4, 2, 1, '2013-11-11', '2013-11-11', 'AO SỐ 3 - Hùn với  ? ? ?'),
(5, 3, 1, '2013-11-11', '2013-11-11', 'Hùn với ? ? ?');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(1, 'Thủy sản'),
(2, 'Thú y');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`) VALUES
(1, 'Lý Văn Thạnh', 'Bán hàng', 0, '0989 111 2221', 'TP HCM', 2000000),
(2, 'Bùi Thanh Tuấn', 'Bán hàng', 0, '0996 333 444', 'Đồng Tháp', 2000000),
(3, 'Nguyễn Thanh Bảo', 'Bảo vệ', 0, '', 'Vĩnh Long', 1800000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(2, '192.168.1.3', '1382425867', '1382429467', '192.168.1.3');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_export`
--

CREATE TABLE IF NOT EXISTS `tbl_order_export` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tracking` (`id_tracking`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_order_export`
--

INSERT INTO `tbl_order_export` (`id`, `id_tracking`, `date`, `note`) VALUES
(13, 1, '2013-11-10', 'Chúng ta đang thử nghiệm'),
(14, 4, '2013-11-11', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_export_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_export_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `tbl_order_export_detail`
--

INSERT INTO `tbl_order_export_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(1, 1, 6, 2, 50000),
(9, 2, 6, 1, 48000),
(10, 2, 4, 1, 35000),
(11, 3, 214, 3, 30000),
(12, 3, 198, 1, 45000),
(13, 3, 210, 3, 25000),
(14, 3, 196, 1, 32000),
(15, 4, 198, 2, 45000),
(16, 4, 210, 3, 25000),
(17, 4, 204, 1, 30000),
(18, 5, 199, 2, 45000),
(19, 5, 198, 1, 45000),
(20, 5, 196, 1, 32000),
(21, 5, 200, 1, 45000),
(22, 5, 214, 5, 30000),
(23, 6, 196, 2, 32000),
(24, 6, 206, 2, 28000),
(26, 7, 276, 2, 63000),
(30, 8, 1044, 1, 7000),
(31, 9, 1, 1, 42000),
(32, 9, 2, 2, 40000),
(33, 10, 2, 1, 40000),
(34, 11, 276, 4, 63000),
(35, 11, 277, 1, 70000),
(36, 11, 278, 1, 70000),
(37, 11, 279, 1, 78000),
(38, 11, 280, 1, 63000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_detail_1` (`idorder`),
  KEY `tbl_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_general`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_paid_general`
--

INSERT INTO `tbl_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(1, 6, '2013-08-07', 1000000, 'Tiền điện'),
(2, 6, '2013-08-15', 200000, 'Tiền nước');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idemployee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_pay_roll_1` (`idemployee`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_paid_pay_roll`
--

INSERT INTO `tbl_paid_pay_roll` (`id`, `idemployee`, `date`, `value_base`, `value_sub`, `value_pre`, `note`) VALUES
(1, 1, '2013-04-30', 2500000, 500000, 1000000, ''),
(2, 2, '2013-05-31', 2500000, 0, 3000000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_paid_supplier`
--

INSERT INTO `tbl_paid_supplier` (`id`, `idsupplier`, `date`, `value`, `note`) VALUES
(4, 6, '2012-09-19', 1000000, 'Thử nè được không đó !');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_r2t`
--

CREATE TABLE IF NOT EXISTS `tbl_r2t` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_resource` int(11) NOT NULL,
  `id_tag` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_resource` (`id_resource`),
  KEY `id_tag` (`id_tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE IF NOT EXISTS `tbl_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `name_short` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `price_import` int(11) NOT NULL,
  `price_export` int(11) NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `barcode` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=128 ;

--
-- Dumping data for table `tbl_resource`
--

INSERT INTO `tbl_resource` (`id`, `idsupplier`, `name`, `name_short`, `unit`, `price_import`, `price_export`, `description`, `barcode`) VALUES
(2, 4, 'PRO IODINE', 'PRO IODINE', '1 Lít', 140000, 175000, '', ''),
(3, 4, 'NT BKC', 'NT BKC', '1 Lít', 75200, 94000, '', ''),
(4, 4, 'YUCCANIC', 'YUCCANIC', '1 Lít', 232000, 290000, '', ''),
(5, 4, 'YUCCANIC', 'YUCCANIC', 'Bao 10 Kg', 280000, 350000, '', ''),
(6, 4, 'NT GANO', 'NT GANO', 'Gói 1 Kg', 416000, 520000, '', ''),
(7, 4, 'NT FA', 'NT FA', 'Gói 1 Kg', 350400, 438000, '', ''),
(8, 4, 'NT DIO', 'NT DIO', 'Gói 1 Kg', 368000, 460000, '', ''),
(9, 4, 'NT AA', 'NT AA', 'Gói 1 Kg', 294400, 368000, '', ''),
(10, 4, 'NT FR7000', 'NT FR7000', '1 Lít', 180000, 225000, '', ''),
(11, 4, 'VITAMIN C', 'VITAMIN C', 'Gói 1 Kg', 84000, 105000, '', ''),
(12, 4, 'VITALEC FISH', 'VITALEC FISH', 'Gói 1 Kg', 57600, 72000, '', ''),
(13, 4, 'PRO MEN', 'PRO MEN', 'Gói 1 Kg', 40000, 50000, '', ''),
(14, 4, 'PRO BEST', 'PRO BEST', 'Gói 1 Kg', 73600, 92000, '', ''),
(15, 4, 'FENDORY', 'FENDORY', 'Gói 1 Kg', 68800, 86000, '', ''),
(16, 4, 'PRAZIQUANTEL', 'PRAZIQUANTEL', 'Gói 1 Kg', 128000, 160000, '', ''),
(17, 4, 'SULFATRIME', 'SULFATRIME', 'Gói 1 Kg', 120000, 150000, '', ''),
(18, 4, 'MOXINE', 'MOXINE', 'Gói 1 Kg', 249600, 312000, '', ''),
(19, 4, 'FACINE', 'FACINE', 'Gói 1 Kg', 268000, 335000, '', ''),
(20, 4, 'GENCINE', 'GENCINE', 'Gói 1 Kg', 204000, 255000, '', ''),
(21, 4, 'C-E-N', 'C-E-N', 'Gói 1 Kg', 312000, 390000, '', ''),
(22, 4, 'FLODO', 'FLODO', 'Gói 1 Kg', 400000, 500000, '', ''),
(23, 5, 'PROTEX', 'PROTEX', '1 Lít', 120000, 150000, '', ''),
(24, 5, 'WATER', 'WATER', 'Gói 1 Kg', 138400, 173000, '', ''),
(25, 5, 'BKC', 'BKC', '1 Lít', 92000, 115000, '', ''),
(26, 5, 'BKC', 'BKC', '5 Lít', 452000, 565000, '', ''),
(27, 5, 'SOLCO', 'SOLCO', '1 Lít', 138400, 173000, '', ''),
(28, 5, 'YUCCA', 'YUCCA', 'Xô 21 Kg', 261600, 327000, '', ''),
(29, 5, 'CAP', 'CAP', 'Gói 2 Kg', 68000, 85000, '', ''),
(30, 5, 'VITAMIN C', 'VITAMIN C', 'Gói 1 Kg', 60000, 75000, '', ''),
(31, 5, 'GLUCAMIN', 'GLUCAMIN', 'Gói 1 Kg', 88000, 110000, '', ''),
(32, 5, 'GROWN', 'GROWN', 'Gói 1 Kg', 64800, 81000, '', ''),
(33, 5, 'C - TẠT', 'C - TẠT', 'Xô 7 Kg', 232800, 291000, '', ''),
(34, 5, 'VITAMIN', 'VITAMIN', 'Gói 1 Kg', 60000, 75000, '', ''),
(35, 5, 'SOTOL', 'SOTOL', '1 Kg', 180000, 225000, '', ''),
(36, 5, 'GIẢI ĐỘC GAN', 'GIẢI ĐỘC GAN', 'Gói 1 Kg', 96800, 121000, '', ''),
(37, 6, 'MEBI PRAZI - ONE', 'MEBI PRAZI - ONE', 'Gói 1 Kg', 224000, 280000, '', ''),
(38, 6, 'AQUA CLEAN', 'AQUA CLEAN', 'Gói 1 Kg', 96000, 120000, '', ''),
(39, 6, 'CẮT TẢO', 'CẮT TẢO', 'Gói 1 Kg', 124000, 155000, '', ''),
(40, 6, 'MEBI - BKC 80', 'MEBI - BKC 80', 'Chai 1 Lít', 92000, 115000, '', ''),
(41, 6, 'MEBI - BKC 80', 'MEBI - BKC 80', 'Can 5 Lít', 440000, 550000, '', ''),
(42, 6, 'MEBI - ALLCIDE', 'MEBI - ALLCIDE', 'Chai 1 Lít', 92000, 115000, '', ''),
(43, 6, 'MEBI - BZ', 'MEBI - BZ', 'Gói 1 Kg', 264000, 330000, '', ''),
(44, 6, 'MEBI YUCA ZEO', 'MEBI YUCA ZEO', 'Xô 5 Kg', 108000, 135000, '', ''),
(45, 6, 'MEBI - GROWN ONE', 'MEBI - GROWN ONE', 'Gói 1 Kg', 108000, 135000, '', ''),
(46, 6, 'MEBIVITA', 'MEBIVITA', 'Gói 1 Kg', 48000, 60000, '', ''),
(47, 6, 'MEBI - OBIMIN', 'MEBI - OBIMIN', 'Gói 1 Kg', 76000, 95000, '', ''),
(48, 6, 'β - GLUCAN', 'β - GLUCAN', 'Gói 1 Kg', 96000, 120000, '', ''),
(49, 6, 'MEBI AQUA C 15%', 'MEBI AQUA C 15%', 'Gói 1 Kg', 64000, 80000, '', ''),
(50, 6, 'HEPASOL - B12', 'HEPASOL - B12', 'Chai 1 Lít', 136000, 142000, '', ''),
(51, 7, 'PRO IODINE', 'PRO IODINE', '1 Lít', 145000, 175000, '', ''),
(52, 7, 'YUCCANIC', 'YUCCANIC', '1 Lít', 232000, 290000, '', ''),
(53, 7, 'YUCCANIC', 'YUCCANIC', 'Bao 10 Kg', 280000, 350000, '', ''),
(54, 7, 'NT GANO', 'NT GANO', 'Gói 1 Kg', 416000, 520000, '', ''),
(55, 7, 'NT DIO', 'NT DIO', 'Gói 1 Kg', 368000, 460000, '', ''),
(56, 7, 'NT AA', 'NT AA', 'Gói 1 Kg', 294400, 368000, '', ''),
(57, 7, 'NT FR7000', 'NT FR7000', '1 Lít', 180000, 225000, '', ''),
(58, 7, 'VITAMIN C', 'VITAMIN C', 'Gói 1 Kg', 84000, 105000, '', ''),
(59, 7, 'VITAMIN C', 'VITAMIN C', 'Xô 5 Kg', 420000, 525000, '', ''),
(60, 7, 'PRO MEN', 'PRO MEN', 'Gói 1 Kg', 40000, 50000, '', ''),
(61, 7, 'PRO BEST', 'PRO BEST', 'Gói 1 Kg', 73600, 92000, '', ''),
(62, 7, 'FENDORY', 'FENDORY', 'Gói 1 Kg', 128000, 160000, '', ''),
(63, 7, 'PRAZIQUANTEL', 'PRAZIQUANTEL', 'Gói 1 Kg', 212000, 265000, '', ''),
(64, 7, 'SULFATRIME', 'SULFATRIME', 'Gói 1 Kg', 120000, 150000, '', ''),
(65, 7, 'MOXINE', 'MOXINE', 'Gói 1 Kg', 249600, 312000, '', ''),
(66, 7, 'FACINE', 'FACINE', 'Gói 1 Kg', 268000, 335000, '', ''),
(67, 7, 'GENCINE', 'GENCINE', 'Gói 1 Kg', 204000, 255000, '', ''),
(68, 7, 'C-E-N', 'C-E-N', 'Gói 1 Kg', 312000, 390000, '', ''),
(69, 7, 'FLODO', 'FLODO', 'Gói 1 Kg', 400000, 500000, '', ''),
(70, 8, 'BKS - 80 FLORLINE', 'BKS - 80 FLORLINE', '1 Lít', 92000, 115000, '', ''),
(71, 8, 'GLU - RV', 'GLU - RV', '1 Lít', 201600, 252000, '', ''),
(72, 8, 'TOMI COPPER', 'TOMI COPPER', '5 Lít', 232000, 290000, '', ''),
(73, 8, 'GOAL', 'GOAL', '500 Gr', 128800, 161000, '', ''),
(74, 8, 'GOAL', 'GOAL', '1 Kg', 252800, 316000, '', ''),
(75, 8, 'EXTRA', 'EXTRA', '5 Lít', 344000, 430000, '', ''),
(76, 8, 'UV 200', 'UV 200', '5 Lít', 404800, 506000, '', ''),
(77, 8, 'HEPATIC', 'HEPATIC', '1 Lít', 112000, 140000, '', ''),
(78, 8, 'C-S', 'C-S', 'Xô 10 Kg', 616800, 771000, '', ''),
(79, 8, 'FOLIC', 'FOLIC', 'Gói 1 Kg', 86400, 108000, '', ''),
(80, 8, 'VITAGLUCAN - B12', 'VITAGLUCAN - B12', 'Gói 1 Kg', 89600, 112000, '', ''),
(81, 8, 'VICIN', 'VICIN', 'Gói 1 Kg', 298400, 373000, '', ''),
(82, 8, 'A-C', 'A-C', 'Gói 1 Kg', 272000, 340000, '', ''),
(83, 8, 'SULFA', 'SULFA', 'Gói 1 Kg', 160000, 200000, '', ''),
(84, 8, 'LOFE', 'LOFE', 'Gói 1 Kg', 332000, 415000, '', ''),
(85, 8, 'THIAM', 'THIAM', 'Gói 1 Kg', 317600, 397000, '', ''),
(86, 8, 'THIDOLIN', 'THIDOLIN', 'Gói 1 Kg', 364800, 456000, '', ''),
(87, 8, 'OMICIN', 'OMICIN', 'Gói 1 Kg', 144800, 181000, '', ''),
(88, 8, 'RIDOXYNE', 'RIDOXYNE', 'Gói 1 Kg', 547200, 684000, '', ''),
(89, 8, 'THIDOMETHEY', 'THIDOMETHEY', 'Gói 1 Kg', 476800, 596000, '', ''),
(90, 9, 'DMF - 02 - 35 (1.5)', 'DMF - 02 - 35 (1.5)', 'Kg', 15058, 15850, '', ''),
(91, 9, 'DMF - 02 - 35 (2,2 - 2,5)', 'DMF - 02 - 35 (2,2 - 2,5)', 'Kg', 14260, 15010, '', ''),
(92, 9, 'DMF - 03 - 30 (1.5)', 'DMF - 03 - 30 (1.5)', 'Kg', 13538, 14250, '', ''),
(93, 9, 'DMF - 03 - 30 (2,2 - 2,5)', 'DMF - 03 - 30 (2,2 - 2,5)', 'Kg', 12635, 13300, '', ''),
(94, 9, 'DMF - 03 - 30 (3)', 'DMF - 03 - 30 (3)', 'Kg', 12616, 13280, '', ''),
(95, 9, 'DMF - 03 - 30 (4)', 'DMF - 03 - 30 (4)', 'Kg', 12607, 13270, '', ''),
(96, 9, 'DMF - 03 - 30 (5)', 'DMF - 03 - 30 (5)', 'Kg', 12607, 13270, '', ''),
(97, 9, 'DMF - 03 - 30 (6)', 'DMF - 03 - 30 (6)', 'Kg', 12607, 13270, '', ''),
(98, 9, 'DMF - 04 - 28 (1.5)', 'DMF - 04 - 28 (1.5)', 'Kg', 12730, 13400, '', ''),
(99, 9, 'DMF - 04 - 28 (2,2 - 2,5)', 'DMF - 04 - 28 (2,2 - 2,5)', 'Kg', 11714, 12330, '', ''),
(100, 9, 'DMF - 04 - 28 (3)', 'DMF - 04 - 28 (3)', 'Kg', 11695, 12310, '', ''),
(101, 9, 'DMF - 04 - 28 (4)', 'DMF - 04 - 28 (4)', 'Kg', 11685, 12300, '', ''),
(102, 9, 'DMF - 04 - 28 (5 - 6)', 'DMF - 04 - 28 (5 - 6)', 'Kg', 11680, 12295, '', ''),
(103, 9, 'DMF - 05 - 26 (3)', 'DMF - 05 - 26 (3)', 'Kg', 11172, 11760, '', ''),
(104, 9, 'DMF - 05 - 26 (4)', 'DMF - 05 - 26 (4)', 'Kg', 11163, 11750, '', ''),
(105, 9, 'DMF - 05 - 26 (5)', 'DMF - 05 - 26 (5)', 'Kg', 11158, 11745, '', ''),
(106, 9, 'DMF - 05 - 26 (6)', 'DMF - 05 - 26 (6)', 'Kg', 11158, 11745, '', ''),
(107, 9, 'DMF - 05 - 26 (8)', 'DMF - 05 - 26 (8)', 'Kg', 11153, 11740, '', ''),
(108, 9, 'DMF - 05 - 26 (10)', 'DMF - 05 - 26 (10)', 'Kg', 11153, 11740, '', ''),
(109, 9, 'DMF - 05 - 26 (12)', 'DMF - 05 - 26 (12)', 'Kg', 11153, 11740, '', ''),
(110, 9, 'DMF - 06 - 22 (6)', 'DMF - 06 - 22 (6)', 'Kg', 10460, 11010, '', ''),
(111, 9, 'DMF - 06 - 22 (8)', 'DMF - 06 - 22 (8)', 'Kg', 10450, 11000, '', ''),
(112, 9, 'DMF - 06 - 22 (10)', 'DMF - 06 - 22 (10)', 'Kg', 10450, 11000, '', ''),
(113, 9, 'DMF - 06 - 22 (12)', 'DMF - 06 - 22 (12)', 'Kg', 10450, 11000, '', ''),
(114, 9, 'DMF - 07 - 20 (10)', 'DMF - 07 - 20 (10)', 'Kg', 10070, 10600, '', ''),
(115, 9, 'DMF - 07 - 20 (12)', 'DMF - 07 - 20 (12)', 'Kg', 10070, 10600, '', ''),
(116, 10, '203 - 30 (1.5)', '203 - 30 (1.5)', 'Kg', 14370, 13652, '', ''),
(117, 10, '203 - 30 (2)', '203 - 30 (2)', 'Kg', 13770, 13082, '', ''),
(118, 10, '203 - 30 (3)', '203 - 30 (3)', 'Kg', 13520, 12844, '', ''),
(119, 10, '203 - 30 (4 - 5)', '203 - 30 (4 - 5)', 'Kg', 13420, 12749, '', ''),
(120, 10, '204 - 26 (2)', '204 - 26 (2)', 'Kg', 12320, 11704, '', ''),
(121, 10, '204 - 26 (3)', '204 - 26 (3)', 'Kg', 12220, 11609, '', ''),
(122, 10, '204 - 26 (4 - 5)', '204 - 26 (4 - 5)', 'Kg', 12120, 11514, '', ''),
(123, 10, '204 - 26 (6 - 8 - 10)', '204 - 26 (6 - 8 - 10)', 'Kg', 12070, 11467, '', ''),
(124, 10, '205 - 22 (4 - 5)', '205 - 22 (4 - 5)', 'Kg', 11620, 11039, '', ''),
(125, 10, '205 - 22 (6 - 8 - 10)', '205 - 22 (6 - 8 - 10)', 'Kg', 11570, 10992, '', ''),
(126, 10, '206 - 18 (4 - 5)', '206 - 18 (4 - 5)', 'Kg', 11270, 10707, '', ''),
(127, 10, '206 - 18 (6 - 8 - 10)', '206 - 18 (6 - 8 - 10)		', 'Kg', 11220, 10659, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(4, 'THUỐC ĐÌNH HƯNG (NAM THÁI)', '', '', '', 0),
(5, 'THUỐC LVS', '', '', 'Cung cấp thuốc', 0),
(6, 'THUỐC MEBIPHA', '', '', '', 0),
(7, 'THUỐC NAM THÁI', '', '', '', 0),
(8, 'THUỐC UYÊN VI', '', '', '', 0),
(9, 'THỨC ĂN DOMYFEED', '', '', '', 0),
(10, 'THỨC ĂN THỦY SẢN MEKONG', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_supplier` int(11) NOT NULL,
  `id_domain` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_supplier` (`id_supplier`),
  KEY `id_domain` (`id_domain`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_supplier_domain`
--

INSERT INTO `tbl_supplier_domain` (`id`, `id_supplier`, `id_domain`) VALUES
(1, 4, 2),
(2, 4, 1),
(3, 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tag`
--

CREATE TABLE IF NOT EXISTS `tbl_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=49 ;

--
-- Dumping data for table `tbl_tag`
--

INSERT INTO `tbl_tag` (`id`, `name`) VALUES
(1, 'độ đạm 20%'),
(2, 'dạng viên'),
(3, 'độ đạm 10% '),
(5, 'độ đạm 15% '),
(6, 'gốc kháng sinh'),
(7, 'dạng bột'),
(8, 'mức nguy hiểm - có độc'),
(9, 'gốc dinh dưỡng'),
(10, 'dạng nước'),
(11, 'vỏ bao - bao mới'),
(12, 'độ đạm 30 %'),
(13, 'mức nguy hiểm - cực độc'),
(14, 'vỏ bao - dùng bao cũ'),
(38, 'dạng viên - 5mm'),
(39, 'mức nguy hiểm - không độc'),
(47, 'độ đạm 25%'),
(48, 'dạng viên - 3mm');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tag_selected`
--

CREATE TABLE IF NOT EXISTS `tbl_tag_selected` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtag` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_tag_selected`
--

INSERT INTO `tbl_tag_selected` (`id`, `idtag`) VALUES
(1, 21),
(2, 18),
(3, 43),
(4, 25),
(5, 17),
(6, 42);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_collect`
--

CREATE TABLE IF NOT EXISTS `tbl_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_term_collect`
--

INSERT INTO `tbl_term_collect` (`id`, `name`) VALUES
(1, 'Phụ Phẩm'),
(2, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_paid`
--

CREATE TABLE IF NOT EXISTS `tbl_term_paid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_term_paid`
--

INSERT INTO `tbl_term_paid` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(4, 'Lương Nhân Viên', 0),
(5, 'Tiền Ăn Nhân Viên', 0),
(6, 'CP Khác', 0),
(7, 'Tiền Phụ Cấp Nhân viên', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `estate_rate` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`, `estate_rate`) VALUES
(3, '2013-09-01', '2013-09-30', 0),
(5, '2013-08-01', '2013-08-31', 0),
(6, '2013-10-01', '2013-10-31', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_store`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=28 ;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`id`, `name`) VALUES
(1, '1 Lít'),
(2, 'Xô 21 Kg'),
(3, '5 Lít'),
(4, 'Xô 7 Kg'),
(5, 'Xô 5 Kg'),
(6, 'Can 5 Lít'),
(7, 'Xô 10 Kg'),
(9, 'Gói 5 Kg'),
(10, 'Gói 1 Kg'),
(11, 'Chai 1 Lít'),
(12, '500 Gr'),
(13, '1 Kg'),
(14, 'Bao 20Kg'),
(18, 'Bao 25Kg'),
(25, 'Bao 10 Kg'),
(26, 'Gói 2 Kg'),
(27, 'Kg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'Bùi Thanh Tuấn', 'tuanbuithanh@gmail.com', 'admin123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(2, 'Lê Nguyễn Đông Khoa', 'lekhoa.bdc@gmail.com', 'lenguyen0945030709...', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '1');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_collect_customer`
--
ALTER TABLE `tbl_collect_customer`
  ADD CONSTRAINT `tbl_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_collect_general`
--
ALTER TABLE `tbl_collect_general`
  ADD CONSTRAINT `tbl_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD CONSTRAINT `tbl_course_1` FOREIGN KEY (`idcategory`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_customer_domain`
--
ALTER TABLE `tbl_customer_domain`
  ADD CONSTRAINT `tbl_customer_domain_ibfk_1` FOREIGN KEY (`id_customer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_customer_domain_ibfk_2` FOREIGN KEY (`id_domain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_customer_tracking`
--
ALTER TABLE `tbl_customer_tracking`
  ADD CONSTRAINT `tbl_customer_tracking_ibfk_1` FOREIGN KEY (`id_customer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_customer_tracking_ibfk_2` FOREIGN KEY (`id_domain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_export`
--
ALTER TABLE `tbl_order_export`
  ADD CONSTRAINT `tbl_order_export_ibfk_1` FOREIGN KEY (`id_tracking`) REFERENCES `tbl_customer_tracking` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import`
--
ALTER TABLE `tbl_order_import`
  ADD CONSTRAINT `tbl_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import_detail`
--
ALTER TABLE `tbl_order_import_detail`
  ADD CONSTRAINT `tbl_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_customer`
--
ALTER TABLE `tbl_paid_customer`
  ADD CONSTRAINT `tbl_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_general`
--
ALTER TABLE `tbl_paid_general`
  ADD CONSTRAINT `tbl_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_paid` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_pay_roll`
--
ALTER TABLE `tbl_paid_pay_roll`
  ADD CONSTRAINT `tbl_paid_pay_roll_1` FOREIGN KEY (`idemployee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_supplier`
--
ALTER TABLE `tbl_paid_supplier`
  ADD CONSTRAINT `tbl_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_r2t`
--
ALTER TABLE `tbl_r2t`
  ADD CONSTRAINT `tbl_r2t_ibfk_1` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_r2t_ibfk_2` FOREIGN KEY (`id_tag`) REFERENCES `tbl_tag` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD CONSTRAINT `tbl_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_supplier_domain`
--
ALTER TABLE `tbl_supplier_domain`
  ADD CONSTRAINT `tbl_supplier_domain_ibfk_1` FOREIGN KEY (`id_supplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_supplier_domain_ibfk_2` FOREIGN KEY (`id_domain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
